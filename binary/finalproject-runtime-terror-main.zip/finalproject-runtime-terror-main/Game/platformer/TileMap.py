import terror_core

class TileType(terror_core.TileTypeDefiner):
    def __init__(self):
        super().__init__()
    def GetTilePos(self, tile_number, tile_width, tile_height):
        pos = terror_core.Position()
        pos.x = 7 * 16
        pos.y = 0 * 16
        return pos

typeDefiner = TileType()

class TileMap(terror_core.TileMapObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__( \
                object_id, \
                config.GetString('texture'), \
                config.GetString('tile_map'), \
                config.GetString('camera_component'), \
                typeDefiner, \
                config.GetInt('rows'), \
                config.GetInt('cols'), \
                config.GetInt('tile_width'), \
                config.GetInt('tile_height'), \
                config.GetInt('dest_tile_width'), \
                config.GetInt('dest_tile_height'), \
                config.GetInt('map_x'), \
                config.GetInt('map_y'))

