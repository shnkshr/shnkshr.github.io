import terror_core

class Paddle(terror_core.GameObject):
    def __init__(self, object_id, position, velocity):
        super().__init__(object_id)
        self.position = position
        self.velocity = velocity
        self.spriteComponent = terror_core.SpriteComponent(self, "Game/start_idle.png", 64, 64, 1, 32, 32, 20, 0, 0, False)
        self.config = terror_core.PhysicsBodyConfig()
        self.config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_STATIC
        self.config.pos_x = 10.0
        self.config.SetShapeAsBox(5.0, 5.0)
        self.physicsComponent = terror_core.PhysicsComponent(self, self.config, 1.0, 1.0)
        self.AddComponent(self.spriteComponent)
        self.AddComponent(self.physicsComponent)

    def Render(self):
        super(Paddle, self).Render()
        print("rendering")

    def Update(self, delta_time):
        super(Paddle, self).Update(delta_time)
        print("updating")
        pos = self.physicsComponent.GetBodyPosition()
        print("Position is " + str(pos.x) +", " + str(pos.y))