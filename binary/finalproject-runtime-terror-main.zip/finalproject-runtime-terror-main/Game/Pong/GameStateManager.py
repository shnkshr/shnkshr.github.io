import terror_core
import datetime


class GameStateManager(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.pauseTimeStamp = datetime.datetime.now()
        self.textColor = terror_core.GraphicsColor()
        self.textColor.r = 255
        self.textColor.g = 255
        self.textColor.b = 255
        self.textColor.a = 255
        self.text_rect = terror_core.Rect2D(360, 540, 100, 80)
        self.renderPauseText = False
        self.pauseTextComponent = terror_core.TextComponent(self, "Game/Pacman/Assets/Fonts/score_font.ttf", 35,
                                                            self.textColor, self.text_rect)
        self.AddComponent(self.pauseTextComponent)

    def Init(self):
        super(GameStateManager, self).Init()
        self.pauseTextComponent.UpdateText("Game Paused !")

    def UpdateFromEvent(self, event):
        currTime = datetime.datetime.now()
        timeDiff = currTime - self.pauseTimeStamp
        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_ESC and (timeDiff.seconds >= 1)):
            gamePaused = not terror_core.GameRunner.GetInstance().IsPause()
            self.pauseTimeStamp = datetime.datetime.now()
            terror_core.GameRunner.GetInstance().PauseGame(gamePaused)
        super(GameStateManager, self).UpdateFromEvent(event)

    def OnPause(self):
        super(GameStateManager, self).OnPause()
        self.renderPauseText = True

    def OnResume(self):
        super(GameStateManager, self).OnResume()
        self.renderPauseText = False

    def Render(self):
        if (self.renderPauseText == True):
            super(GameStateManager, self).Render()
