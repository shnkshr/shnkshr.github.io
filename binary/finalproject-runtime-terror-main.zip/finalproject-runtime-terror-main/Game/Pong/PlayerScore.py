import terror_core


class PlayerScore(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig):
        super().__init__(object_id)
        self.score = 0
        self.position = config.GetPosition("position")
        self.color = config.GetColor("color")
        self.text_rect = terror_core.Rect2D(self.position.x, self.position.y, 50, 40)
        self.textComponent = terror_core.TextComponent(self, "Game/Pong/Assets/Fonts/score_font.ttf", 30, self.color,
                                                       self.text_rect)
        self.AddComponent(self.textComponent)

    def UpdateScoreBy(self, amount):
        self.score += amount
        if self.score < 0:
            self.score = 0

    def Update(self, delta_time):
        super(PlayerScore, self).Update(delta_time)
        self.textComponent.UpdateText(str(self.score))

    def Render(self):
        super(PlayerScore, self).Render()
