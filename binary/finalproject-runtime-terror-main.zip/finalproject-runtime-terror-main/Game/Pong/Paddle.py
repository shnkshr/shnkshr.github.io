import terror_core

screen_width = 1080
screen_height = 720

class Paddle(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.position = config.GetPosition("position")
        self.velocity = config.GetVector("velocity")
        self.color = config.GetColor("color")
        self.player_wasd = config.GetBoolean("control_wasd")
        self.paddle_height = 120
        self.paddle_width = 20
        self.AssignSprites()
        self.transformComponent = terror_core.TransformComponent(self, self.position, 0, 0)
        self.controllerComponent = terror_core.ControllerComponent(self, self.velocity.x, self.velocity.y)
        # create physics component
        physics_config = terror_core.PhysicsBodyConfig()
        physics_config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_DYNAMIC
        physics_config.SetShapeAsBox(self.paddle_width, self.paddle_height)
        physics_config.pos_x = self.position.x
        physics_config.pos_y = self.position.y
        physics_config.width = self.paddle_width
        physics_config.height = self.paddle_height
        physics_config.density = 10.0
        physics_config.friction = 0.3
        self.physicsComponent = terror_core.PhysicsComponent(self, physics_config)
        self.AddComponent(self.transformComponent)
        self.AddComponent(self.controllerComponent)
        self.AddComponent(self.spriteComponent)
        self.AddComponent(self.physicsComponent)

    def ProcessCollisionStart(self, collided_with_object_id):
        terror_core.SoundController.PlaySoundEffect("Game/Pong/Assets/Sound/paddle.wav")
        print("Collision start with Paddle " + self.GetObjectId() + " and " + collided_with_object_id)

    def ProcessCollisionEnd(self, collided_with_object_id):
        print("Collision end with Paddle " + self.GetObjectId() + " and " + collided_with_object_id)

    def AssignSprites(self):
        if (self.player_wasd):
            srcX = 15
        else:
            srcX = 65
        self.spriteComponent = terror_core.SpriteComponent(self, "Game/Pong/Assets/Sprites/sprites.bmp", 20, 120, 1, 20,
                                                               120, 0, 0, 0, srcX, 15, True, True)

    def UpdateFromEvent(self, event: terror_core.Event):
        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_D):
            terror_core.GameRunner.GetInstance().FindGameObject("score_left").UpdateScoreBy(1)
        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_A):
            terror_core.GameRunner.GetInstance().FindGameObject("score_left").UpdateScoreBy(-1)

        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_RIGHT):
            terror_core.GameRunner.GetInstance().FindGameObject("score_right").UpdateScoreBy(1)
        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_LEFT):
            terror_core.GameRunner.GetInstance().FindGameObject("score_right").UpdateScoreBy(-1)

        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_SPACE):
            return
        if (self.player_wasd):
            if (
                    event.GetKeyEvent() == terror_core.SupportedKey.KEY_UP or event.GetKeyEvent() == terror_core.SupportedKey.KEY_DOWN):
                return
        else:
            if (
                    event.GetKeyEvent() == terror_core.SupportedKey.KEY_W or event.GetKeyEvent() == terror_core.SupportedKey.KEY_S):
                return
        super(Paddle, self).UpdateFromEvent(event)

    def Update(self, delta_time):
        super(Paddle, self).Update(delta_time)
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        if self.controllerComponent.GetYVelocity() > 0 and self.position.y + self.paddle_height < screen_height:
            self.physicsComponent.MoveBody(terror_core.PHYSICS_BODY_MOVEMENT_DOWN(), self.velocity)
        elif self.controllerComponent.GetYVelocity() < 0 and self.position.y > 0:
            self.physicsComponent.MoveBody(terror_core.PHYSICS_BODY_MOVEMENT_UP(), self.velocity)
        else:
            self.physicsComponent.MoveBody(terror_core.PHYSICS_BODY_MOVEMENT_STOP(), self.velocity)

    def Render(self):
        super(Paddle, self).Render()
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)
