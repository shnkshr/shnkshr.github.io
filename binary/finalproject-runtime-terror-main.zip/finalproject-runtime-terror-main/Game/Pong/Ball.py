import terror_core

screen_width = 1080
screen_height = 720

class Ball(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.velocity = config.GetVector("velocity")
        self.position = config.GetPosition("position")
        self.ballRadius = config.GetInt("radius")
        self.color = config.GetColor("color")
        self.ballInMotion = False
        self.transformComponent = terror_core.TransformComponent(self, self.position, 0, 0)
        self.spriteComponent = terror_core.SpriteComponent(self, "Game/Pong/Assets/Sprites/sprites.bmp", 40, 40, 1, 30,
                                                           30, 0, 0, 0, 111, 6, True, True)
        self.AddComponent(self.transformComponent)
        self.AddComponent(self.spriteComponent)

        physics_config = terror_core.PhysicsBodyConfig()
        physics_config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_DYNAMIC
        physics_config.density = 0.1
        physics_config.SetShapeAsBox(self.ballRadius * 2, self.ballRadius * 2)
        physics_config.pos_x = self.position.x
        physics_config.pos_y = self.position.y
        physics_config.width = self.ballRadius * 2
        physics_config.height = self.ballRadius * 2
        physics_config.friction = 0.3
        physics_config.restitution = 1.0
        self.physicsComponent = terror_core.PhysicsComponent(self, physics_config)
        self.AddComponent(self.physicsComponent)

    def InitializeBall(self):
        self.color.r = 0
        self.color.g = 255
        self.color.b = 255
        self.color.a = 255
        self.position.x = int(screen_width / 2 - self.ballRadius)
        self.position.y = int(screen_height / 2 - self.ballRadius)

    def UpdateFromEvent(self, event: terror_core.Event):
        super(Ball, self).UpdateFromEvent(event)
        if (event.GetKeyEvent() == terror_core.SupportedKey.KEY_SPACE and not self.ballInMotion):
            self.ballInMotion = True
            self.physicsComponent.MoveBody(terror_core.PHYSICS_BODY_MOVEMENT_LEFT(), terror_core.Vector2D(4.0, 4.0))

    def Render(self):
        super(Ball, self).Render()

    def Update(self, delta_time):
        super(Ball, self).Update(delta_time)
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)
        vel = self.physicsComponent.GetBodyVelocity()
        if self.position.y <= 0 or self.position.y + 2 * self.ballRadius >= screen_height:
            vel.y = -vel.y
            self.physicsComponent.SetBodyVelocity(vel)
