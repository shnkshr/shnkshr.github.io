import terror_core

screen_width = 1080
screen_height = 720


class Net(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.color = config.GetColor("color")

    def InitializeNet(self):
        self.color.r = 255
        self.color.g = 0
        self.color.b = 0
        self.color.a = 255

    def Render(self):
        super(Net, self).Render()
        i = 0
        while i < screen_height:
            terror_core.BasicShapes.RenderPoint(int(screen_width / 2), i, self.color)
            i += 5
