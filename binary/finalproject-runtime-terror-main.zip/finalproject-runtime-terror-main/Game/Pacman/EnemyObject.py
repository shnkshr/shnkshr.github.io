import terror_core
import random
import Game.Pacman.GameStateManager

class EnemyObject(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.position = config.GetPosition('Position')
        self.velocity = config.GetVector('velocity')
        self.AssignSprite(object_id)
        self.transformComponent = terror_core.TransformComponent(self, self.position, 0, 0)
        physics_config = terror_core.PhysicsBodyConfig()
        physics_config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_DYNAMIC
        physics_config.SetShapeAsCircle(15)
        physics_config.pos_x = self.position.x
        physics_config.pos_y = self.position.y
        physics_config.width = 28
        physics_config.height = 28
        physics_config.density = 10.0
        physics_config.friction = 0.0
        self.physicsComponent = terror_core.PhysicsComponent(self, physics_config)

        self.AddComponent(self.spriteComponent)
        self.AddComponent(self.transformComponent)
        self.AddComponent(self.physicsComponent)

        self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_DOWN()
        self.previous_direction = self.move_direction
        vel = terror_core.Vector2D(0, 0)
        vel.y = -self.velocity.y
        self.physicsComponent.SetBodyVelocity(vel)

    def AssignSprite(self, objectId):
        if (objectId == "enemy1"):
            self.spriteComponent = terror_core.SpriteComponent(self,
                                                               "Game/Pacman/Assets/Sprites/redGhost.png", 16, 16, 8, 28,
                                                               28, 30,
                                                               self.position.x, self.position.y, 0, 0, False, True)
        elif (objectId == "enemy2"):
            self.spriteComponent = terror_core.SpriteComponent(self,
                                                               "Game/Pacman/Assets/Sprites/orangeGhost.png", 16, 16, 8, 28,
                                                               28, 30,
                                                               self.position.x, self.position.y, 0, 0, False, True)
        elif (objectId == "enemy3"):
            self.spriteComponent = terror_core.SpriteComponent(self,
                                                               "Game/Pacman/Assets/Sprites/greenGhost.png", 16, 16, 8, 28,
                                                               28, 30,
                                                               self.position.x, self.position.y, 0, 0, False, True)
        elif (objectId == "enemy4"):
            self.spriteComponent = terror_core.SpriteComponent(self,
                                                               "Game/Pacman/Assets/Sprites/yellowGhost.png", 16, 16, 8, 28,
                                                               28, 30,
                                                               self.position.x, self.position.y, 0, 0, False, True)

    def Update(self, delta_time):
        super(EnemyObject, self).Update(delta_time)
        vel = terror_core.Vector2D(0, 0)
        cur_vel = self.physicsComponent.GetBodyVelocity()
        if not (cur_vel.x == 0 and cur_vel.y == 0):
            self.previous_direction = self.move_direction
            if self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_RIGHT():
                vel.x = self.velocity.x
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_LEFT():
                vel.x = -self.velocity.x
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_DOWN():
                vel.y = -self.velocity.y
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_UP():
                vel.y = self.velocity.y
                self.physicsComponent.SetBodyVelocity(vel)
        else:
            invalid_count = 2
            while True:
                new_direction = random.randint(0, 4)
                if new_direction == 0:
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_RIGHT():
                        continue
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_LEFT() and invalid_count > 0:
                        invalid_count -= 1
                        continue
                    self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_RIGHT()
                    vel.x = self.velocity.x
                    self.physicsComponent.SetBodyVelocity(vel)
                elif new_direction == 1:
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_LEFT():
                        continue
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_RIGHT() and invalid_count > 0:
                        invalid_count -= 1
                        continue
                    self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_LEFT()
                    vel.x = -self.velocity.x
                    self.physicsComponent.SetBodyVelocity(vel)
                elif new_direction == 2:
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_DOWN():
                        continue
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_UP() and invalid_count > 0:
                        invalid_count -= 1
                        continue
                    self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_DOWN()
                    vel.y = -self.velocity.y
                    self.physicsComponent.SetBodyVelocity(vel)
                elif new_direction == 3:
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_UP():
                        continue
                    if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_DOWN() and invalid_count > 0:
                        invalid_count -= 1
                        continue
                    self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_UP()
                    vel.y = self.velocity.y
                    self.physicsComponent.SetBodyVelocity(vel)
                break

    def Render(self):
        super(EnemyObject, self).Render()
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)

    def CollideWithEnemy(self):
        vel = terror_core.Vector2D(0, 0)
        if self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_RIGHT():
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_LEFT()
            vel.x = -self.velocity.x
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_LEFT():
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_RIGHT()
            vel.x = self.velocity.x
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_DOWN():
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_UP()
            vel.y = self.velocity.y
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.previous_direction == terror_core.PHYSICS_BODY_MOVEMENT_UP():
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_DOWN()
            vel.y = -self.velocity.y
            self.physicsComponent.SetBodyVelocity(vel)

    def ProcessCollisionStart(self, collided_with_id):
        if collided_with_id.find('enemy') == 0:
            self.CollideWithEnemy()
            terror_core.GameRunner.GetInstance().FindGameObject(collided_with_id).CollideWithEnemy()
        elif collided_with_id.find('dot') == 0:
            terror_core.GameRunner.GetInstance().FindGameObject(collided_with_id).MarkObjectForDestruction()
        elif collided_with_id == 'player':
            terror_core.SoundController.PlaySoundEffect("Game/Pacman/Assets/Sounds/pacman_death.wav")
            terror_core.GameRunner.GetInstance().FindGameObject("game_state_manager").GameOver()
            terror_core.GameRunner.GetInstance().FindGameObject(collided_with_id).MarkObjectForDestruction()
