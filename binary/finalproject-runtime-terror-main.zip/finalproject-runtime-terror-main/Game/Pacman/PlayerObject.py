import terror_core


class PlayerObject(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig):
        super().__init__(object_id)
        self.position = config.GetPosition('Position')
        self.velocity = config.GetVector('velocity')
        self.color = config.GetColor('Color')
        self.spriteComponent = terror_core.SpriteComponent(self,
                "Game/Pacman/Assets/Sprites/PacMan.png", 16, 16, 8, 28, 28, 30,
                self.position.x, self.position.y, 0, 0, False, True)
        self.transformComponent = terror_core.TransformComponent(self, self.position, 0, 0)
        self.controllerComponent = terror_core.ControllerComponent(self, self.velocity.x, self.velocity.y)

        physics_config = terror_core.PhysicsBodyConfig()
        physics_config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_DYNAMIC
        physics_config.SetShapeAsCircle(15)
        physics_config.pos_x = self.position.x
        physics_config.pos_y = self.position.y
        physics_config.width = 28
        physics_config.height = 28
        physics_config.density = 10.0
        physics_config.friction = 0.0
        physics_config.restitution = 0.0
        self.physicsComponent = terror_core.PhysicsComponent(self, physics_config)
        self.AddComponent(self.transformComponent)
        self.AddComponent(self.controllerComponent)
        self.AddComponent(self.spriteComponent)
        self.AddComponent(self.physicsComponent)

        self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_STOP()

    def UpdateFromEvent(self, event):
        super(PlayerObject, self).UpdateFromEvent(event)

    def Update(self, delta_time):
        super(PlayerObject, self).Update(delta_time)
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        vel = terror_core.Vector2D(0, 0)
        if self.controllerComponent.GetXVelocity() > 0:
            self.spriteComponent.SetSpriteRotateAngle(0)
            self.spriteComponent.SetHorizontalFlip(False)
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_RIGHT()
            vel.x = self.velocity.x
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.controllerComponent.GetXVelocity() < 0:
            self.spriteComponent.SetSpriteRotateAngle(0)
            self.spriteComponent.SetHorizontalFlip(True)
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_LEFT()
            vel.x = -self.velocity.x
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.controllerComponent.GetYVelocity() > 0:
            if (self.spriteComponent.IsHorizontalFlip() == True):
                self.spriteComponent.SetSpriteRotateAngle(270)
            else:
                self.spriteComponent.SetSpriteRotateAngle(90)
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_DOWN()
            vel.y = -self.velocity.y
            self.physicsComponent.SetBodyVelocity(vel)
        elif self.controllerComponent.GetYVelocity() < 0:
            if (self.spriteComponent.IsHorizontalFlip() == True):
                self.spriteComponent.SetSpriteRotateAngle(90)
            else:
                self.spriteComponent.SetSpriteRotateAngle(270)
            self.move_direction = terror_core.PHYSICS_BODY_MOVEMENT_UP()
            vel.y = self.velocity.y
            self.physicsComponent.SetBodyVelocity(vel)

        self.AdjustSpriteFpsBasedOnSpeed(self.physicsComponent.GetBodySpeed())
        cur_vel = self.physicsComponent.GetBodyVelocity()
        if vel.x == 0 and vel.y == 0 and not (cur_vel.x == 0 and cur_vel.y == 0):
            if self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_RIGHT():
                vel.x = self.velocity.x
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_LEFT():
                vel.x = -self.velocity.x
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_DOWN():
                vel.y = -self.velocity.y
                self.physicsComponent.SetBodyVelocity(vel)
            elif self.move_direction == terror_core.PHYSICS_BODY_MOVEMENT_UP():
                vel.y = self.velocity.y
                self.physicsComponent.SetBodyVelocity(vel)

    def AdjustSpriteFpsBasedOnSpeed(self, speed: float):
        if (speed < 1.5):
            self.spriteComponent.SetSpriteTargetFps(0)
        else:
            self.spriteComponent.SetSpriteTargetFps(30)

    def Render(self):
        super(PlayerObject, self).Render()
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)

    def ProcessCollisionStart(self, collided_with_id):
        # if (not collided_with_id.startswith("tilemap_")):
        #     terror_core.GameRunner.GetInstance().FindGameObject(collided_with_id).MarkObjectForDestruction()
        # else:
        #     # collision with tile map
        #     print("X velocity = " + str(self.controllerComponent.GetXVelocity()) + ", Y velocity = " + str(self.controllerComponent.GetYVelocity()))
        #     if (not (self.controllerComponent.GetXVelocity() == 0 and self.controllerComponent.GetYVelocity() == 0)):
        #         # the pacman did not completely stop
        #
        #         if (abs(self.controllerComponent.GetXVelocity()) > abs(self.controllerComponent.GetYVelocity())):
        #             # preferred movement along x
        #             pass
        #         else:
        #             # preferred movement along y
        #             pass
        #     pass
        if (not collided_with_id.startswith("tilemap_")) and collided_with_id.find('enemy') != 0:
            terror_core.GameRunner.GetInstance().FindGameObject(collided_with_id).MarkObjectForDestruction()
        elif collided_with_id.find('enemy'):
            self.MarkObjectForDestruction()
