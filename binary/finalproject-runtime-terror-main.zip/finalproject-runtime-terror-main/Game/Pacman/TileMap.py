import terror_core


class MyTileDefiner(terror_core.TileTypeDefiner):
    def __init__(self):
        super().__init__()

    def GetTilePos(self, tile_number, tile_width, tile_height):
        pos = terror_core.Position()
        pos.x = 7 * 16
        pos.y = 1 * 16
        return pos


tile_definer = MyTileDefiner()


class TileMap(terror_core.TileMapObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id,
                         config.GetString("texture_res"),
                         config.GetString("tile_map_res"),
                         "test",
                         tile_definer,
                         config.GetInt("rows"),
                         config.GetInt("cols"),
                         config.GetInt("tile_width"),
                         config.GetInt("tile_height"),
                         config.GetInt("dest_tile_width"),
                         config.GetInt("dest_tile_height"),
                         config.GetInt("map_x"),
                         config.GetInt("map_y"))

    def Init(self):
        super(TileMap, self).Init()
        #self.CreateDummyObject()

    def OnPause(self):
        super(TileMap, self).OnPause()
        print("OnPause tilemap")

    def OnResume(self):
        super(TileMap, self).OnResume()
        print("OnResume tilemap")

    # Sample code to create Dummy object dynamically, properties still need to be passed using the Object Config class
    def CreateDummyObject(self):
        dot1Config = terror_core.ObjectConfig()
        pos = terror_core.Position()
        pos.x = 32
        pos.y = 140
        dot1Config.SetPosition("Position", pos)
        terror_core.GameRunner.GetInstance().AddGameObjectFromScript("dot2", "Game.Pacman.DotObject", "DotObject",
                                                                     dot1Config)
