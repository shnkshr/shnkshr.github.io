import terror_core

class DotObject(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.position = config.GetPosition('Position')
        self.spriteComponent = terror_core.SpriteComponent(self,
                                                           "Game/Pacman/Assets/Sprites/Coin.png", 16, 16, 8, 28, 28, 10,
                                                           self.position.x, self.position.y, 0, 0, False, False)
        self.transformComponent = terror_core.TransformComponent(self, self.position, 0, 0)
        physics_config = terror_core.PhysicsBodyConfig()
        physics_config.type = terror_core.PhysicsBodyType.PHYSICS_BODY_DYNAMIC
        physics_config.SetShapeAsBox(28, 28)
        physics_config.pos_x = self.position.x
        physics_config.pos_y = self.position.y
        physics_config.width = 28
        physics_config.height = 28
        physics_config.density = 0.0
        physics_config.friction = 0.0
        self.physicsComponent = terror_core.PhysicsComponent(self, physics_config)

        self.AddComponent(self.spriteComponent)
        self.AddComponent(self.transformComponent)
        self.AddComponent(self.physicsComponent)

    def Update(self, delta_time):
        super(DotObject, self).Update(delta_time)
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)

    def Render(self):
        super(DotObject, self).Render()
        pos = self.physicsComponent.GetBodyPosition()
        self.position.x = int(pos.x)
        self.position.y = int(pos.y)
        self.transformComponent.UpdateTransformPosition(self.position.x, self.position.y)

    def ProcessCollisionStart(self, object_collided_with):
        if object_collided_with == 'player':
            terror_core.SoundController.PlaySoundEffect("Game/Pacman/Assets/Sounds/pacman_chomp.wav")
            terror_core.GameRunner.GetInstance().FindGameObject('score').UpdateScoreBy(1)
            self.MarkObjectForDestruction()
        if object_collided_with.find('enemy') == 0:
            self.MarkObjectForDestruction()

class DotCreator(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.tile_width = config.GetInt('tile_width')
        self.tile_height = config.GetInt('tile_height')
        self.rows = config.GetInt('rows')
        self.cols = config.GetInt('cols')
        self.tile_id = config.GetString('tile_id')

    def Init(self):
        arr = terror_core.GameRunner.GetInstance().FindGameObject(self.tile_id).GetTileMapLayout()
        dot_count = 0
        for i in range(2, self.rows):
            for j in range(self.cols):
                if arr[i * self.cols + j] > 0:
                    continue
                pos = terror_core.Position()
                pos.x = j * self.tile_width + 2
                pos.y = i * self.tile_height + 2
                dot_config = terror_core.ObjectConfig()
                dot_config.SetPosition("Position", pos)
                terror_core.GameRunner.GetInstance().AddGameObjectFromScript('dot_{}_{}'.format(i, j), 'Game.Pacman.DotObject', 'DotObject', dot_config)
                dot_count += 1
        self.MarkObjectForDestruction()

