import terror_core

class GameText(terror_core.GameObject):
    def __init__(self, object_id, config: terror_core.ObjectConfig = None):
        super().__init__(object_id)
        self.color = config.GetColor('color')
        self.boundary = config.GetRect('text_boundary')
        self.font_res = config.GetString('font_res')
        self.text = config.GetString('text')
        self.font_size = config.GetInt('font_size')
        self.textComponent = terror_core.TextComponent(self, self.font_res, self.font_size, self.color,
                                                       self.boundary)
        self.textComponent.UpdateText(self.text)
        self.AddComponent(self.textComponent)

    def Init(self):
        super(GameText, self).Init()