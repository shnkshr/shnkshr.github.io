import terror_core
import physics

config = physics.PhysicsBodyConfig()
config.type = physics.PhysicsBodyType.PHYSICS_BODY_STATIC
config.pos_x = 10.0
config.SetShapeAsBox(5.0, 5.0)

game_obj = terror_core.GameObject("obj1")

phy = physics.PhysicsComponent(game_obj, config, 1.0, 1.0)

pos = phy.GetBodyPosition()

print(pos)

