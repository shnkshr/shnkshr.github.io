//
// Created by psx95 on 4/17/21.
//
#define CATCH_CONFIG_MAIN // need only be in one of the test files
#include "catch.hpp"
#include <api/ObjectConfig.hpp>
#include <api/GlobalConfig.hpp>

std::string GetFileContentAsString(std::string &path_to_file) {
  std::ifstream i(path_to_file);
  nlohmann::json j;
  i >> j;
  std::cout << j.dump() << std::endl;
  return j.dump();
}

TEST_CASE("DUMMY CASE") {
  int a = 4;
  REQUIRE (a == 4);
}

TEST_CASE("Test Parsing from String") {
  std::string file_path = "Engine/test/json_test.json";
  ObjectConfig object_config("sample", GetFileContentAsString(file_path));
  Position position_in_file = object_config.GetPosition("Position");
  GraphicsColor color_in_file = object_config.GetColor("Color");
  Vector2D vector_in_file = object_config.GetVector("Vector2D");
  Rect2D rect_in_file = object_config.GetRect("Rect2D");
  REQUIRE(position_in_file.x == 10);
  REQUIRE(position_in_file.y == 20);
  REQUIRE(vector_in_file.x == 0.0f);
  REQUIRE(vector_in_file.y == 0.3f);
  REQUIRE(color_in_file.r == 255);
  REQUIRE(color_in_file.g == 254);
  REQUIRE(color_in_file.b == 253);
  REQUIRE(color_in_file.a == 252);
  REQUIRE(rect_in_file.GetXPos() == 10);
  REQUIRE(rect_in_file.GetYPos() == 20);
  REQUIRE(rect_in_file.GetWidth() == 30);
  REQUIRE(rect_in_file.GetHeight() == 40);
}

TEST_CASE("Test Parse simple types") {
  std::string file_path = "Engine/test/json_test.json";
  ObjectConfig object_config("sample", GetFileContentAsString(file_path));
  float float_val = object_config.GetFloat("Float");
  int int_val = object_config.GetInt("Integer");
  bool bool_val_false = object_config.GetBoolean("Boolean");
  bool bool_val_true = object_config.GetBoolean("Boolean_True");
  std::string string_val = object_config.GetString("String");
  REQUIRE(float_val == 2.67f);
  REQUIRE(int_val == 3);
  REQUIRE(bool_val_true);
  REQUIRE_FALSE(bool_val_false);
  REQUIRE(string_val == "blah");
}

TEST_CASE("Test Parse Global Config") {
  std::string file_path = "Engine/test/global_config_test.json";
  GlobalConfig global_config(GetFileContentAsString(file_path));
  REQUIRE(global_config.GetGravity() == 2);
  // color
  REQUIRE(global_config.GetBackgroundColor().r == 0);
  REQUIRE(global_config.GetBackgroundColor().g == 0);
  REQUIRE(global_config.GetBackgroundColor().b == 0);
  REQUIRE(global_config.GetBackgroundColor().a == 0);
  // screen dimensions
  REQUIRE(global_config.GetScreenWidth() == 1200);
  REQUIRE(global_config.GetScreenHeight() == 800);
  // background
  REQUIRE(global_config.GetBackgroundImageRes()
              == "/home/psx95/Projects/C++/CS-5850/finalproject-runtime-terror/media/mvp.png");
  REQUIRE(global_config.GetBackgroundMusicRes()
              == "/home/psx95/Projects/C++/CS-5850/finalproject-runtime-terror/media/wav.mp3");
  REQUIRE(global_config.GetCameraFollowsObject() == "test_object");
}

TEST_CASE("Test Parse Global Config Defaults") {
  std::string file_path = "Engine/test/global_config_defaults.json";
  GlobalConfig global_config(GetFileContentAsString(file_path));
  REQUIRE(global_config.GetGravity() == 0.0f); // default gravity
  // color
  REQUIRE(global_config.GetBackgroundColor().r == 10);
  REQUIRE(global_config.GetBackgroundColor().g == 0);
  REQUIRE(global_config.GetBackgroundColor().b == 0);
  REQUIRE(global_config.GetBackgroundColor().a == 0);
  // screen dimensions
  REQUIRE(global_config.GetScreenWidth() == 1200);
  REQUIRE(global_config.GetScreenHeight() == 800);
  // background
  REQUIRE(global_config.GetBackgroundImageRes().empty());
  REQUIRE(global_config.GetBackgroundMusicRes().empty());
  REQUIRE(global_config.GetCameraFollowsObject().empty());
}

TEST_CASE("Json creation API") {
  ObjectConfig object_config("test_object");
  REQUIRE(object_config.ToString() == "null");
  object_config.SetPosition("position", Position{10,20});
  std::cout << std::to_string(object_config.GetPosition("position").x) << std::endl;
  REQUIRE(object_config.GetPosition("position").x == 10);
  REQUIRE(object_config.GetPosition("position").y == 20);
}
