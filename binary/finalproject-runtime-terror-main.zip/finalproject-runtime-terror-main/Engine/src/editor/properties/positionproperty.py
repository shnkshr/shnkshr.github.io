class PositionProperty:
    def __init__(self, x=0, y=0):
        self.x = 0
        self.y = 0

    def setX(self, x):
        self.x = x

    def setY(self, y):
        self.y = y
