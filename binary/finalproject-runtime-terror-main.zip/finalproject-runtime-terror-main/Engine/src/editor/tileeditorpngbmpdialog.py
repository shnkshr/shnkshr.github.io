from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction, QMessageBox
import os

QDialogUi = uic.loadUiType("Engine/src/editor/tileeditorpngbmpdialog.ui")[0]


class TileEditorFilePathPopUpDialog(QtWidgets.QDialog, QDialogUi):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(603, 172)
        self.setupUi(self)
        self.bmp_path = None
        self.png_path = None
        self.saveButton.clicked.connect(self.storeFilePaths)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    def validateFilePaths(self):
        if not self.bmp_path and not self.png_path:
            QMessageBox.warning(self, "", "Please provide one of the file paths! Try again.")
            return False
        if self.bmp_path:
            bmp_res = os.path.isfile(self.bmp_path)
            if not bmp_res:
                QMessageBox.warning(self, "", "Incorrect BMP path! Try again.")
                return False
        if self.png_path:
            png_res = os.path.isfile(self.png_path)
            if not png_res:
                QMessageBox.warning(self, "", "Incorrect PNG path! Try again.")
                return False
        return True

    @QtCore.pyqtSlot()
    def storeFilePaths(self):
        self.bmp_path = self.bmpLineEdit.text()
        self.png_path = self.pngLineEdit.text()
        if not self.validateFilePaths():
            return
        self.accept()
