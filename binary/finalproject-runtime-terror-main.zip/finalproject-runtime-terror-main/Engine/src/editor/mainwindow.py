from PyQt5 import QtCore, QtGui, QtWidgets, uic
from PyQt5.QtCore import pyqtSlot, QPoint, QSize
from PyQt5.QtGui import QKeySequence, QBrush, QPixmap, QColor
from PyQt5.QtWidgets import QFrame, QAction, QMessageBox, QGraphicsPixmapItem, QGraphicsRectItem, QGraphicsScene, \
    QGraphicsTextItem, QGraphicsView, QStatusBar
from Engine.src.editor.gameobject import GameObjectItem
from Engine.src.editor.gameobjectnamepopup import GameObjectNamePopUpDialog
from Engine.src.editor.gameobjectpropertieswindow import GameObjectProperties
from Engine.src.editor.globalconfigwindow import GlobalConfigWindow
from Engine.src.editor.globalconfig import GlobalConfig
from Engine.src.editor.tileeditorpngbmpdialog import TileEditorFilePathPopUpDialog
from Engine.src.editor.loadcontextfilepopup import ProjectPathPopUpDialog
from copy import deepcopy
from pathlib import Path
import os
import json
import terror_core
import tile_editor
from multiprocessing import Process

qtcreator_file = "Engine/src/editor/mainwindow.ui"
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtcreator_file)

GAME_OBJECT_WIDTH = 32
GAME_OBJECT_HEIGHT = 32

POSITION_KEY = 'PREVIEW_POSITION'
COLOR_KEY = 'PREVIEW_COLOR'
DIMENSIONS_KEY = 'PREVIEW_DIMENSIONS'
SPRITE_KEY = 'PREVIEW_SPRITE'

EDITOR_GAME_STATUS = {
    "NOT_SAVED": "Game configuration not saved",
    "SAVED": "Game configuration saved at ",
    "GAME_ACTIVE": "Game is currently running",
    "TILE_EDITOR_ACTIVE": "Tile editor is currently running"
}

CONFIG_PATH = "GAME_CONFIG/game_objects_config.json"


class MainWindow(QFrame, Ui_MainWindow):
    def __init__(self, parent=None):
        QFrame.__init__(self, parent)
        self.setFixedSize(1525, 757)
        self.isGameRunning = False
        self.isTileEditorRunning = False
        self.gameStatus = EDITOR_GAME_STATUS["NOT_SAVED"]
        self.config_file_path = CONFIG_PATH
        self.gameObjectCount = 1
        self.gameObjects = {}
        self.gameConfig = GlobalConfig("dummy_level")
        self.displayObjects = {}
        self.setupUi(self)
        self.initButtons()
        self.initStatusPanel()
        self.initSpinBoxes()
        self.nameLineEdit.setReadOnly(True)
        self.configureGameObjectList()
        self.graphicsScene = QGraphicsScene()
        self.graphicsView.setScene(self.graphicsScene)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    def exit_app(self):
        self.close()

    def initButtons(self):
        self.openButton.clicked.connect(self.loadContext)
        self.createGameObjectButton.clicked.connect(self.addGameObject)
        self.runButton.clicked.connect(self.configureRunButton)
        self.saveButton.clicked.connect(self.writeToConfigJson)
        self.duplicateButton.clicked.connect(self.duplicateGameObject)
        self.deleteButton.clicked.connect(self.deleteGameObject)
        self.globalConfigButton.clicked.connect(self.configButtonWindow)
        self.gameObjectClassNameUpdateButton.clicked.connect(self.updateGameObjectClassName)
        self.gameObjectModuleNameUpdateButton.clicked.connect(self.updateGameObjectModuleName)
        self.tileEditorButton.clicked.connect(self.openTileEditor)
        self.previewButton.clicked.connect(self.previewGameObject)

    def initStatusPanel(self):
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: red")
        self.editorStatus.setToolTip(self.editorStatus.text())

    def initSpinBoxes(self):
        self.spinBoxR.setRange(0, 255)
        self.spinBoxG.setRange(0, 255)
        self.spinBoxB.setRange(0, 255)
        self.spinBoxA.setRange(0, 255)

    def populateContext(self, context_json):
        self.gameObjectsLists.clear()
        self.gameObjects = {}
        self.gameConfig.updateTreeViewConfigs(context_json['global-config'])
        for game_obj, props in context_json.items():
            if game_obj != 'global-config':
                new_game_obj = GameObjectItem(game_obj)
                new_game_obj.copyGameObject(props)
                self.gameObjectsLists.addItem(game_obj)
                self.gameObjects[game_obj] = new_game_obj

                if POSITION_KEY in new_game_obj.properties:
                    self.displayObjects[game_obj] = {}
                    self.displayObjects[game_obj][POSITION_KEY] = new_game_obj.properties[POSITION_KEY]
                    self.displayObjects[game_obj][COLOR_KEY] = new_game_obj.properties[COLOR_KEY]
                    self.displayObjects[game_obj][DIMENSIONS_KEY] = new_game_obj.properties[DIMENSIONS_KEY]
                    self.updateGameObjectRect(game_obj)
                    if SPRITE_KEY in new_game_obj.properties:
                        self.displayObjects[game_obj][SPRITE_KEY] = new_game_obj.properties[SPRITE_KEY]
                        if new_game_obj.properties[SPRITE_KEY]:
                            self.updateGameObjectSprite(game_obj)

    def validatePreviewFields(self):
        try:
            if self.spritePathLineEdit.text():
                if not os.path.exists(self.spritePathLineEdit.text()):
                    QMessageBox.warning(self, "",
                                        "Invalid Sprite path specified! Try again.")
                    return False
            x, y = int(self.positionXLineEdit.text()), int(self.positionYLineEdit.text())
            if x < 0 or y < 0:
                QMessageBox.warning(self, "", "Sprite Position should be greater than equal to 0! Try again.")
                return False
            w, h = int(self.spriteWidthLineEdit.text()), int(self.spriteHeightLineEdit.text())
            if w < 0 or h < 0:
                QMessageBox.warning(self, "", "Sprite width and height should be greater than equal to 0! Try again.")
                return False

        except ValueError:
            QMessageBox.warning(self, "", "Invalid preview configuration values! Try again.")
            return False
        return True

    @pyqtSlot()
    def previewGameObject(self):
        item = self.gameObjectsLists.currentItem()
        if not item:
            QMessageBox.warning(self, "",
                                "You have not selected any game object! Try again.")
            return
        gameObject = self.gameObjects[item.text()]
        if not self.validatePreviewFields():
            return
        pos_x = self.positionXLineEdit.text()
        pos_y = self.positionYLineEdit.text()
        sprite_w = self.spriteWidthLineEdit.text()
        sprite_h = self.spriteHeightLineEdit.text()
        sprite_file = self.spritePathLineEdit.text()
        color_r = self.spinBoxR.value()
        color_g = self.spinBoxG.value()
        color_b = self.spinBoxB.value()
        color_a = self.spinBoxA.value()
        if not item.text() in self.displayObjects:
            self.displayObjects[item.text()] = {}
        position_dict = {'x': pos_x, 'y': pos_y}
        color_dict = {'r': str(color_r), 'g': str(color_g), 'b': str(color_b), 'a': str(color_a)}
        dimensions_dict = {'w': sprite_w, 'h': sprite_h}
        self.displayObjects[item.text()][POSITION_KEY] = position_dict
        self.displayObjects[item.text()][COLOR_KEY] = color_dict
        self.displayObjects[item.text()][DIMENSIONS_KEY] = dimensions_dict
        if sprite_file:
            image = QtGui.QImage(sprite_file)
            if image.isNull():
                QMessageBox.warning(self, "",
                                    "Image Viewer", "Cannot load %s." % sprite_file)
                return
            else:
                self.displayObjects[item.text()][SPRITE_KEY] = sprite_file
                self.updateGameObjectSprite(item.text())
                gameObject.properties[SPRITE_KEY] = sprite_file
        else:
            self.displayObjects[item.text()][SPRITE_KEY] = ""
            gameObject.properties[SPRITE_KEY] = ""

            if 'sprite' in self.displayObjects[item.text()] and self.displayObjects[item.text()]['sprite']:
                self.graphicsScene.removeItem(self.displayObjects[item.text()]['sprite'])
                self.displayObjects[item.text()]['sprite'] = None
            else:
                self.displayObjects[item.text()]['sprite'] = None

        if not sprite_file:
            self.updateGameObjectRect(item.text())
        gameObject.properties[POSITION_KEY] = position_dict
        gameObject.properties[COLOR_KEY] = color_dict
        gameObject.properties[DIMENSIONS_KEY] = dimensions_dict

    @pyqtSlot()
    def loadContext(self):
        ex = ProjectPathPopUpDialog()
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            self.config_file_path = ex.path
            with open(self.config_file_path) as f:
                context_json = json.load(f)
                self.populateContext(context_json)

    @pyqtSlot()
    def configureRunButton(self):
        if self.isGameRunning:
            print("Game is already running")
            return
        self.isGameRunning = True
        self.disableRunButton()
        self.gameStatus = EDITOR_GAME_STATUS["GAME_ACTIVE"]
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: green")
        self.editorStatus.setToolTip(self.editorStatus.text())
        self.editorStatus.repaint()
        self.writeToConfigJson()
        self.runGame(self.config_file_path)
        self.gameStatus = EDITOR_GAME_STATUS["SAVED"] + str(self.config_file_path)
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: darkgreen")
        self.editorStatus.setToolTip(self.editorStatus.text())
        self.enableRunButton()

    @pyqtSlot()
    def openTileEditor(self):
        if self.isTileEditorRunning:
            print("Tile editor is already running")
            return
        self.isTileEditorRunning = True
        self.disableTileEditorButton()
        self.gameStatus = EDITOR_GAME_STATUS["TILE_EDITOR_ACTIVE"]
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: blue")
        self.editorStatus.setToolTip(self.editorStatus.text())
        ex = TileEditorFilePathPopUpDialog()
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            bmp_path = ex.bmp_path
            png_path = ex.png_path
            self.launchTileEditor(int(self.gameConfig.configs["Screen Dimensions"]["screen-width"]),
                                  int(self.gameConfig.configs["Screen Dimensions"]["screen-height"]), bmp_path,
                                  png_path)
        self.isTileEditorRunning = False
        self.enableTileEditorButton()
        self.gameStatus = EDITOR_GAME_STATUS["SAVED"] + str(self.config_file_path)
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: darkgreen")
        self.editorStatus.setToolTip(self.editorStatus.text())

    @pyqtSlot()
    def deleteGameObject(self):
        for ix in self.gameObjectsLists.selectedIndexes():
            if ix.data() in self.displayObjects:
                display_object = self.displayObjects[ix.data()]
                del self.displayObjects[ix.data()]
                if 'rect' in display_object:
                    self.graphicsScene.removeItem(display_object['rect'])
                if display_object['sprite']:
                    self.graphicsScene.removeItem(display_object['sprite'])
            del self.gameObjects[ix.data()]
            self.gameObjectsLists.takeItem(ix.row())

    def eventFilter(self, obj, event):
        if event.type() == QtCore.QEvent.MouseButtonPress:
            if event.button() == QtCore.Qt.LeftButton:
                return -1
            elif event.button() == QtCore.Qt.RightButton:
                return 1
            elif event.button() == QtCore.Qt.MiddleButton:
                return 0
        return -2

    def configureGameObjectList(self):
        self.gameObjectsLists.itemClicked.connect(self.configureGameObjectListOnCLick)
        self.gameObjectsLists.itemDoubleClicked.connect(self.propertyWindow)

    def configureGameObjectListOnCLick(self, item):
        game_object_item = self.gameObjects[item.text()]
        self.populateDefaultFields(game_object_item)

    def enableRunButton(self):
        self.runButton.show()

    def disableRunButton(self):
        self.runButton.hide()

    def enableTileEditorButton(self):
        self.tileEditorButton.show()

    def disableTileEditorButton(self):
        self.tileEditorButton.hide()

    @pyqtSlot()
    def configButtonWindow(self):
        ex = GlobalConfigWindow(self.gameConfig.getConfig())
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            self.gameConfig.updateTreeViewConfigs(ex.treeViewDict)

    def validateCameraFollowsObjectId(self):
        config = self.gameConfig.getConfig()
        for key, val in config.items():
            if key == "Camera Follows":
                if val not in self.gameObjects.keys():
                    return False
        return True

    @pyqtSlot()
    def writeToConfigJson(self):
        config = {}
        for gameObjectId, gameObject in self.gameObjects.items():
            if not gameObject.class_name or not gameObject.module_name:
                QMessageBox.warning(self, "", "All Game Objects should have class name and module name! Please check "
                                              "and try again.")
                return 0
            config[gameObject.object_id] = gameObject.getConfigJSONDict()
        if not self.validateCameraFollowsObjectId():
            QMessageBox.warning(self, "", "Camera component is attached to an invalid game object! Please check and "
                                          "try again.")
            return 0

        config["global-config"] = self.gameConfig.getConfig()
        config_json = json.dumps(config)
        directory_split = self.config_file_path.split('/')
        directory = "/".join(directory_split[:-1])
        file = directory_split[-1]
        p = Path(directory)
        p.mkdir(parents=True, exist_ok=True)
        (p / file).open("w").write(config_json)

        self.gameStatus = EDITOR_GAME_STATUS["SAVED"] + str(self.config_file_path)
        self.editorStatus.setText(self.gameStatus)
        self.editorStatus.setStyleSheet("color: darkgreen")
        self.editorStatus.setToolTip(self.editorStatus.text())
        return 1

    def updateGameObjectRect(self, object_name):
        display_object = self.displayObjects[object_name]
        if 'sprite' in display_object and display_object['sprite']:
            return

        if 'rect' in display_object:
            self.graphicsScene.removeItem(display_object['rect'])
        pos_x = int(display_object[POSITION_KEY]['x'])
        pos_y = int(display_object[POSITION_KEY]['y'])
        width = int(display_object[DIMENSIONS_KEY]['w'])
        height = int(display_object[DIMENSIONS_KEY]['h'])
        display_object['rect'] = QGraphicsRectItem(pos_x, pos_y, width, height)
        display_object['rect'].setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
        if COLOR_KEY in display_object:
            color = display_object[COLOR_KEY]
            display_object['rect'].setBrush(
                QBrush(QColor(int(color['r']), int(color['g']), int(color['b']), int(color['a']))))
        self.graphicsScene.addItem(display_object['rect'])

    def updateGameObjectSprite(self, object_name):
        display_object = self.displayObjects[object_name]
        if 'rect' in display_object:
            self.graphicsScene.removeItem(display_object['rect'])
        if 'sprite' in display_object and display_object['sprite']:
            self.graphicsScene.removeItem(display_object['sprite'])
        image = QtGui.QImage(display_object[SPRITE_KEY])
        pix_image = QPixmap.fromImage(image)
        width = int(display_object[DIMENSIONS_KEY]['w'])
        height = int(display_object[DIMENSIONS_KEY]['h'])
        pix_image_scaled = pix_image.scaled(width, height)
        display_object['sprite'] = QGraphicsPixmapItem(pix_image_scaled)
        display_object['sprite'].setFlag(QtWidgets.QGraphicsItem.ItemIsMovable, True)
        self.graphicsScene.addItem(display_object['sprite'])

    @pyqtSlot()
    def duplicateGameObject(self):
        item = self.gameObjectsLists.currentItem()
        gameObject = self.gameObjects[item.text()]
        ex = GameObjectNamePopUpDialog(self.gameObjectCount)
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        game_object_id = None
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            game_object_id = ex.gameObjectName
            if not game_object_id:
                game_object_id = "game_object_" + str(self.gameObjectCount)
                self.gameObjectCount += 1
        if game_object_id:
            if self.checkIfDuplicateGameObjectName(game_object_id):
                return
            gameObject = deepcopy(gameObject)
            gameObject.object_id = game_object_id
            self.gameObjects[game_object_id] = gameObject
            self.gameObjectsLists.addItem(game_object_id)
            if POSITION_KEY in gameObject.properties:
                self.displayObjects[game_object_id] = {}
                self.displayObjects[game_object_id][POSITION_KEY] = gameObject.properties[POSITION_KEY]
                self.displayObjects[game_object_id][COLOR_KEY] = gameObject.properties[COLOR_KEY]
                self.displayObjects[game_object_id][DIMENSIONS_KEY] = gameObject.properties[DIMENSIONS_KEY]
                self.updateGameObjectRect(game_object_id)
                if SPRITE_KEY in gameObject.properties:
                    self.displayObjects[game_object_id][SPRITE_KEY] = gameObject.properties[SPRITE_KEY]
                    if gameObject.properties[SPRITE_KEY]:
                        self.updateGameObjectSprite(game_object_id)

    @pyqtSlot()
    def propertyWindow(self):
        item = self.gameObjectsLists.currentItem()
        initProperties = None
        if item.text() in self.gameObjects:
            initProperties = self.gameObjects[item.text()].getPropertiesDict()
            if POSITION_KEY in initProperties:
                del initProperties[POSITION_KEY]
            if SPRITE_KEY in initProperties:
                del initProperties[SPRITE_KEY]
            if COLOR_KEY in initProperties:
                del initProperties[COLOR_KEY]
            if DIMENSIONS_KEY in initProperties:
                del initProperties[DIMENSIONS_KEY]

        ex = GameObjectProperties(initProperties)
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            self.gameObjects[item.text()].updateTreeViewProperties(ex.treeViewDict)
            if POSITION_KEY in ex.treeViewDict:
                if not item.text() in self.displayObjects:
                    self.displayObjects[item.text()] = {}
                self.displayObjects[item.text()][POSITION_KEY] = ex.treeViewDict[POSITION_KEY]
                if COLOR_KEY in ex.treeViewDict:
                    self.displayObjects[item.text()][COLOR_KEY] = ex.treeViewDict[COLOR_KEY]
                self.updateGameObjectRect(item.text())

    def checkIfDuplicateGameObjectName(self, game_object_name):
        if game_object_name in self.gameObjects.keys():
            QMessageBox.warning(self, "", "Duplicate game object names! Try again.")
            return True
        if game_object_name == 'global-config':
            QMessageBox.warning(self, "", "Game object name cannot be the keyword global-config ! Try again.")
            return True
        if game_object_name[:8] == 'tilemap_':
            QMessageBox.warning(self, "", "Game object name cannot start with tilemap_ ! Try again.")
            return True
        return False

    @pyqtSlot()
    def addGameObject(self):
        ex = GameObjectNamePopUpDialog(self.gameObjectCount)
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        game_object_id = None
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            game_object_id = ex.gameObjectName
            if not game_object_id:
                game_object_id = "game_object_" + str(self.gameObjectCount)
                self.gameObjectCount += 1
        if game_object_id:
            if self.checkIfDuplicateGameObjectName(game_object_id):
                return
            self.gameObjects[game_object_id] = GameObjectItem(game_object_id)
            self.gameObjectsLists.addItem(game_object_id)

    def populateDefaultFields(self, game_object_item):
        self.nameLineEdit.setText(game_object_item.object_id)
        self.classNameLineEdit.setText(game_object_item.class_name)
        self.moduleNameLineEdit.setText(game_object_item.module_name)
        if POSITION_KEY in game_object_item.properties:
            self.positionXLineEdit.setText(game_object_item.properties[POSITION_KEY]['x'])
            self.positionYLineEdit.setText(game_object_item.properties[POSITION_KEY]['y'])
            self.spriteWidthLineEdit.setText(game_object_item.properties[DIMENSIONS_KEY]['w'])
            self.spriteHeightLineEdit.setText(game_object_item.properties[DIMENSIONS_KEY]['h'])
            self.spinBoxR.setValue(int(game_object_item.properties[COLOR_KEY]['r']))
            self.spinBoxG.setValue(int(game_object_item.properties[COLOR_KEY]['g']))
            self.spinBoxB.setValue(int(game_object_item.properties[COLOR_KEY]['b']))
            self.spinBoxA.setValue(int(game_object_item.properties[COLOR_KEY]['a']))
            if SPRITE_KEY in game_object_item.properties:
                self.spritePathLineEdit.setText(game_object_item.properties[SPRITE_KEY])

    @pyqtSlot()
    def updateGameObjectClassName(self):
        game_object_item = self.gameObjects[self.gameObjectsLists.currentItem().text()]
        game_object_item.set_class_name(self.classNameLineEdit.text())

    @pyqtSlot()
    def updateGameObjectModuleName(self):
        game_object_item = self.gameObjects[self.gameObjectsLists.currentItem().text()]
        game_object_item.set_module_name(self.moduleNameLineEdit.text())

    def cloneGameObjectItem(self, game_object_item):
        new_game_object_item = GameObjectItem(game_object_item.object_id)
        new_game_object_item.set_class_name(game_object_item.class_name)
        new_game_object_item.set_sprite_path(game_object_item.sprite_path)
        return new_game_object_item

    def launchGameFromCpp(self, path_to_config):
        terror_core.GameRunner.GetInstance().InitializeGraphicsSubSystem(path_to_config)
        terror_core.GameRunner.GetInstance().Start()
        terror_core.GameRunner.GetInstance().MainGameLoop()
        terror_core.GameRunner.GetInstance().Shutdown()

    def runGame(self, config_path):
        # Instantiate the Game runner object here.
        # Call all the methods
        res = self.writeToConfigJson()
        if not res:
            return
        p = Process(target=self.launchGameFromCpp, args=(config_path,))
        p.start()
        p.join()
        self.isGameRunning = False

    # Support for BMP as well as PNG - If PNG, a path to a DIRECTORY with all PNG tiles named as 1.png, 2.png,
    # etc. required If BMP - a path to specific BMP file is required.
    def launchTileEditor(self, window_width, window_height, tiles_bmp_img_res, tile_png_directory):
        tile_editor.TileEditorRunner.RunApp(window_width, window_height, tiles_bmp_img_res, tile_png_directory)
        self.isTileEditorRunning = False
