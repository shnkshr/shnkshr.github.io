from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction, QMessageBox
import os
QDialogUi = uic.loadUiType("Engine/src/editor/loadcontextfilepopup.ui")[0]


class ProjectPathPopUpDialog(QtWidgets.QDialog, QDialogUi):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(454, 141)
        self.setupUi(self)
        self.path = None
        self.saveButton.clicked.connect(self.loadContext)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    @QtCore.pyqtSlot()
    def loadContext(self):
        self.path = self.projectPathLineEdit.text()
        if not os.path.isfile(self.path):
            QMessageBox.warning(self, "", "You have specified an invalid file path! Try again.")
            return
        self.accept()
