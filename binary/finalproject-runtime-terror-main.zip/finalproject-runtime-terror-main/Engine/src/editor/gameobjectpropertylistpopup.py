from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction
QFrmaeUi = uic.loadUiType("Engine/src/editor/gameobjectpropertylistpopup.ui")[0]


class GameObjectPropertiesPopUpDialog(QtWidgets.QDialog, QFrmaeUi):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.setFixedSize(640, 472)
        self.propertyListView.addItem("Position")
        self.propertyListView.addItem("Vector2D")
        self.propertyListView.addItem("Color")
        self.propertyListView.addItem("Rect2D")
        self.propertyListView.addItem("Integer")
        self.propertyListView.addItem("Float")
        self.propertyListView.addItem("Boolean")
        self.propertyListView.addItem("String")
        self.selectedProperty = None
        self.propertyListView.itemDoubleClicked.connect(self.addPropertyToObject)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    @QtCore.pyqtSlot()
    def addPropertyToObject(self):
        for ix in self.propertyListView.selectedIndexes():
            self.selectedProperty = ix.data()
        self.accept()
