from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction

QDialogUi = uic.loadUiType("Engine/src/editor/gameobjectnamepopup.ui")[0]


class GameObjectNamePopUpDialog(QtWidgets.QDialog, QDialogUi):
    def __init__(self, id, parent=None):
        super().__init__(parent)
        self.setFixedSize(454, 141)
        self.gameObjectName = "Game Object " + str(id)
        self.setupUi(self)
        self.saveButton.clicked.connect(self.storeObjectName)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    @QtCore.pyqtSlot()
    def storeObjectName(self):
        self.gameObjectName = self.gmeObjectNameLineEdit.text()
        self.accept()
