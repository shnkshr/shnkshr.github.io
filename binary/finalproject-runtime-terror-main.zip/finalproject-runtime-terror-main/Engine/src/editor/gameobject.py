from copy import deepcopy


class GameObjectItem:
    def __init__(self, object_id):
        self.object_id = object_id
        self.class_name = ""
        self.module_name = ""
        self.sprite_path = ""
        self.properties = {}

    def copyGameObject(self, game_object_dict):
        for obj_property_key, val in game_object_dict.items():
            if obj_property_key == 'class_name':
                self.class_name = val
            elif obj_property_key == 'module_name':
                self.module_name = val
            else:
                self.properties[obj_property_key] = val

    def set_object_id(self, object_id: str):
        self.object_id = object_id

    def set_class_name(self, class_name: str):
        self.class_name = class_name

    def set_module_name(self, module_name: str):
        self.module_name = module_name

    def set_sprite_path(self, sprite_path: str):
        self.sprite_path = sprite_path

    def addProperty(self, property_key, property_value):
        self.properties[property_key] = property_value

    def getProperty(self, property_key):
        if property_key in self.properties:
            return self.properties[property_key]
        return None

    def updateTreeViewProperties(self, tree_view_dict):
        self.properties = {}
        for property_key, d in tree_view_dict.items():
            self.properties[property_key] = d
        return

    def getConfigJSONDict(self):
        res = deepcopy(self.properties)
        res["class_name"] = self.class_name
        res["module_name"] = self.module_name
        return res

    def getPropertiesDict(self):
        return self.properties

    def toString(self):
        print("--------------------------------------------------------------------------")
        print(self.object_id)
        print(self.class_name)
        print(self.sprite_path)
        print()
