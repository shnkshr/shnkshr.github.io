from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence, QStandardItemModel, QStandardItem, QFont, QColor
from PyQt5.QtWidgets import QAction, QMessageBox
from Engine.src.editor.gameobjectpropertylistpopup import GameObjectPropertiesPopUpDialog

QWidgetUi = uic.loadUiType("Engine/src/editor/gameobjectpropertieswindow.ui")[0]


class StandardEditableItem(QStandardItem):
    def __init__(self, txt='', font_size=12, set_bold=False, color=QColor(0, 0, 0)):
        super().__init__()

        fnt = QFont('Open Sans', font_size)
        fnt.setBold(set_bold)

        self.setEditable(True)
        self.setForeground(color)
        self.setFont(fnt)
        self.setText(txt)


class StandardUnEditableItem(QStandardItem):
    def __init__(self, txt='', font_size=12, set_bold=False, color=QColor(0, 0, 0)):
        super().__init__()

        fnt = QFont('Open Sans', font_size)
        fnt.setBold(set_bold)

        self.setEditable(False)
        self.setForeground(color)
        self.setFont(fnt)
        self.setText(txt)


class GameObjectProperties(QtWidgets.QDialog, QWidgetUi):
    def __init__(self, initProperties, parent=None):
        super().__init__(parent)
        self.setFixedSize(640, 493)
        self.setupUi(self)
        self.initButtons()
        self.treeModel = QStandardItemModel()
        self.rootNode = self.treeModel.invisibleRootItem()
        self.gameObjectPropertiesTreeView.setHeaderHidden(True)
        self.gameObjectPropertiesTreeView.setModel(self.treeModel)
        self.addedProperties = set()
        if initProperties:
            self.fillModelFromJson(self.rootNode, initProperties)
            for property_key, _ in initProperties.items():
                self.addedProperties.add(property_key)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)
        self.treeViewDict = None
        self.mapping = {
            "Position": self.addPositionPropertyButtonAction,
            "Vector2D": self.addVector2DPropertyButtonAction,
            "Color": self.addColorPropertyButtonAction,
            "Rect2D": self.addRect2DPropertyButtonAction,
            "String": self.addStringPropertyButtonAction,
            "Integer": self.addIntegerPropertyButtonAction,
            "Float": self.addFloatPropertyButtonAction,
            "Boolean": self.addBooleanPropertyButtonAction,
        }

    def initButtons(self):
        self.addPropertyButton.clicked.connect(self.displayPropertyListPopUp)
        self.savePropertyButton.clicked.connect(self.savePropertyData)
        self.deletePropertyButton.clicked.connect(self.deletePropertyData)

    def fillModelFromJson(self, parent, d):
        if isinstance(d, dict):
            for k, v in d.items():
                child = StandardUnEditableItem(str(k))
                if parent == self.rootNode:
                    child = StandardEditableItem(str(k))
                parent.appendRow(child)
                self.fillModelFromJson(child, v)
        elif isinstance(d, list):
            for v in d:
                self.fillModelFromJson(parent, v)
        else:
            parent.appendRow(StandardEditableItem(str(d)))

    def fillDictFromModel(self, parent_index, d):
        v = {}
        for i in range(self.treeModel.rowCount(parent_index)):
            ix = self.treeModel.index(i, 0, parent_index)
            if self.treeModel.rowCount(ix) == 0:
                d[parent_index.data()] = ix.data()
                return
            self.fillDictFromModel(ix, v)
        d[parent_index.data()] = v

    def checkForDuplicatePropertyKeys(self):
        unique_keys = set()
        for i in range(self.treeModel.rowCount()):
            ix = self.treeModel.index(i, 0)
            if ix.data() in unique_keys:
                return True
            unique_keys.add(ix.data())
        return False

    def modelToDict(self):
        if self.checkForDuplicatePropertyKeys():
            QMessageBox.warning(self, "", "Looks like you have duplicate property keys! Try again.")
            return {}, -1
        d = dict()
        for i in range(self.treeModel.rowCount()):
            ix = self.treeModel.index(i, 0)
            self.fillDictFromModel(ix, d)
        return d, 0

    def checkIfPropertyExists(self, currentProperty):
        if currentProperty in self.addedProperties:
            return True
        return False

    @QtCore.pyqtSlot()
    def displayPropertyListPopUp(self):
        ex = GameObjectPropertiesPopUpDialog()
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        propertySelected = None
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            propertySelected = ex.selectedProperty
        if propertySelected:
            self.mapping[propertySelected]()

    @QtCore.pyqtSlot()
    def savePropertyData(self):
        self.treeViewDict, flag = self.modelToDict()
        if flag == -1:
            return
        if not self.individualFieldValidityChecker(self.treeViewDict):
            return
        self.accept()

    @QtCore.pyqtSlot()
    def deletePropertyData(self):
        for ix in self.gameObjectPropertiesTreeView.selectedIndexes():
            self.treeModel.removeRow(ix.row(), ix.parent())
            self.addedProperties.remove(ix.data()) if ix.data() and ix.data() != "None" else None

    def individualFieldValidityChecker(self, tree_dict):
        for property_key, property_val in tree_dict.items():
            if property_key in {"class_name", "module_name", "object_id"}:
                QMessageBox.warning(self, "", "You have named one of the properties as class_name or module_name or "
                                              "object_id! These are reserved so please try again.")
                return False
            if "x-vec" in property_val and "y-vec" in property_val:
                try:
                    x, y = int(property_val["x-vec"]), int(property_val["y-vec"])
                    if x < 0 or y < 0:
                        QMessageBox.warning(self, "", "Vector2D values should be greater than equal to 0! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Vector2D values! Try again.")
                    return False
            elif "x" in property_val and "y" in property_val:
                try:
                    x, y = float(property_val["x"]), float(property_val["y"])
                    if x < 0 or y < 0:
                        QMessageBox.warning(self, "", "Position values should be greater than equal to 0! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Position values! Try again.")
                    return False
            elif "a" in property_val and "r" in property_val and "g" in property_val and "b" in property_val:
                try:
                    a, r, g, b = int(property_val["a"]), int(property_val["r"]), int(property_val["g"]), int(
                        property_val["b"])
                    if not ((0 <= a <= 255) and (0 <= r <= 255) and (0 <= g <= 255) and (0 <= b <= 255)):
                        QMessageBox.warning(self, "", "Color values should be between 0 and 255! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Color values! Try again.")
                    return False
            elif "x" in property_val and "y" in property_val and "w" in property_val and "h" in property_val:
                try:
                    x, y, w, h = int(property_val["x"]), int(property_val["y"]), int(property_val["w"]), int(
                        property_val["h"])
                    if x < 0 or y < 0 or w < 0 or h < 0:
                        QMessageBox.warning(self, "", "Rect2D parameters should be greater than 0! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Rect2D parameters! Try again.")
                    return False
            elif "integer_val" in property_val:
                try:
                    x = int(property_val["integer_val"])
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Integer value! Try again.")
                    return False
            elif "float_val" in property_val:
                try:
                    x = float(property_val["float_val"])
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Float value! Try again.")
                    return False
            elif "boolean_val" in property_val:
                if property_val["boolean_val"] not in ["True", "False"]:
                    QMessageBox.warning(self, "", "Invalid Boolean value! Type in 'True' or 'False'. Try again.")
                    return False
        return True

    @QtCore.pyqtSlot()
    def addVector2DPropertyButtonAction(self):
        vector2d = StandardEditableItem('Vector2D')
        x_vec_label = StandardUnEditableItem("x-vec")
        x_vec = StandardEditableItem(str(0))
        y_vec_label = StandardUnEditableItem("y-vec")
        y_vec = StandardEditableItem(str(0))
        x_vec_label.appendRow(x_vec)
        y_vec_label.appendRow(y_vec)
        vector2d.appendRow(x_vec_label)
        vector2d.appendRow(y_vec_label)
        self.rootNode.appendRow(vector2d)

    @QtCore.pyqtSlot()
    def addPositionPropertyButtonAction(self):
        position = StandardEditableItem('Position')
        x_label = StandardUnEditableItem("x")
        y_label = StandardUnEditableItem("y")
        x = StandardEditableItem(str(0))
        y = StandardEditableItem(str(0))
        x_label.appendRow(x)
        y_label.appendRow(y)
        position.appendRow(x_label)
        position.appendRow(y_label)
        self.rootNode.appendRow(position)

    @QtCore.pyqtSlot()
    def addColorPropertyButtonAction(self):
        color = StandardEditableItem('Color')
        a_label = StandardUnEditableItem("a")
        r_label = StandardUnEditableItem("r")
        g_label = StandardUnEditableItem("g")
        b_label = StandardUnEditableItem("b")
        r = StandardEditableItem(str(0))
        g = StandardEditableItem(str(0))
        b = StandardEditableItem(str(0))
        a = StandardEditableItem(str(0))
        a_label.appendRow(a)
        r_label.appendRow(r)
        g_label.appendRow(g)
        b_label.appendRow(b)
        color.appendRow(a_label)
        color.appendRow(r_label)
        color.appendRow(g_label)
        color.appendRow(b_label)
        self.rootNode.appendRow(color)

    @QtCore.pyqtSlot()
    def addRect2DPropertyButtonAction(self):
        rect2d = StandardEditableItem('Rect2D')
        x_rect_label = StandardUnEditableItem("x")
        y_rect_label = StandardUnEditableItem("y")
        w_rect_label = StandardUnEditableItem("w")
        h_rect_label = StandardUnEditableItem("h")
        x_rect = StandardEditableItem(str(0))
        y_rect = StandardEditableItem(str(0))
        w_rect = StandardEditableItem(str(0))
        h_rect = StandardEditableItem(str(0))
        x_rect_label.appendRow(x_rect)
        y_rect_label.appendRow(y_rect)
        w_rect_label.appendRow(w_rect)
        h_rect_label.appendRow(h_rect)
        rect2d.appendRow(x_rect_label)
        rect2d.appendRow(y_rect_label)
        rect2d.appendRow(w_rect_label)
        rect2d.appendRow(h_rect_label)
        self.rootNode.appendRow(rect2d)

    @QtCore.pyqtSlot()
    def addStringPropertyButtonAction(self):
        string_prop = StandardEditableItem('String')
        val_label = StandardUnEditableItem("string_val")
        val = StandardEditableItem("click to edit")
        val_label.appendRow(val)
        string_prop.appendRow(val_label)
        self.rootNode.appendRow(string_prop)

    @QtCore.pyqtSlot()
    def addIntegerPropertyButtonAction(self):
        string_prop = StandardEditableItem('Integer')
        val_label = StandardUnEditableItem("integer_val")
        val = StandardEditableItem("click to edit")
        val_label.appendRow(val)
        string_prop.appendRow(val_label)
        self.rootNode.appendRow(string_prop)

    @QtCore.pyqtSlot()
    def addFloatPropertyButtonAction(self):
        string_prop = StandardEditableItem('Float')
        val_label = StandardUnEditableItem("float_val")
        val = StandardEditableItem("click to edit")
        val_label.appendRow(val)
        string_prop.appendRow(val_label)
        self.rootNode.appendRow(string_prop)

    @QtCore.pyqtSlot()
    def addBooleanPropertyButtonAction(self):
        string_prop = StandardEditableItem('Boolean')
        val_label = StandardUnEditableItem("boolean_val")
        val = StandardEditableItem("click to edit")
        val_label.appendRow(val)
        string_prop.appendRow(val_label)
        self.rootNode.appendRow(string_prop)