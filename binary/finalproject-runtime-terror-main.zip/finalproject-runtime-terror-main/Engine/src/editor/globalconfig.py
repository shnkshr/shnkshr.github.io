class GlobalConfig:
    def __init__(self, level_id):
        self.level_id = level_id
        self.configs = {"Screen Dimensions": {}, "Background Color": {}}
        self.configs["Screen Dimensions"]["screen-width"] = "1200"
        self.configs["Screen Dimensions"]["screen-height"] = "800"
        self.configs["Background Color"]["a"] = "0"
        self.configs["Background Color"]["r"] = "0"
        self.configs["Background Color"]["g"] = "0"
        self.configs["Background Color"]["b"] = "0"

    def addConfig(self, config_key, config_value):
        self.configs[config_key] = config_value

    def getConfig(self, config_key):
        if config_key in self.configs:
            return self.configs[config_key]
        return None

    def updateTreeViewConfigs(self, tree_view_dict):
        self.configs = {}
        for config_key, d in tree_view_dict.items():
            self.configs[config_key] = d
        return

    def getConfig(self):
        return self.configs

    def toString(self):
        print("--------------------------------------------------------------")
        print(self.configs)