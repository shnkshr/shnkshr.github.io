from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence
from PyQt5.QtWidgets import QAction
QFrmaeUi = uic.loadUiType("Engine/src/editor/globalconfiglistpopup.ui")[0]


class GlobalConfigPopUpDialog(QtWidgets.QDialog, QFrmaeUi):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setupUi(self)
        self.setFixedSize(640, 472)
        self.configListView.addItem("Background Image")
        self.configListView.addItem("Background Music")
        self.configListView.addItem("Gravity")
        self.configListView.addItem("Camera Follows")
        self.selectedConfig = None
        self.configListView.itemDoubleClicked.connect(self.addConfig)
        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)

    @QtCore.pyqtSlot()
    def addConfig(self):
        for ix in self.configListView.selectedIndexes():
            self.selectedConfig = ix.data()
        self.accept()
