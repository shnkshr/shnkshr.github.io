from PyQt5 import QtWidgets, QtCore
from PyQt5 import uic
from PyQt5.QtGui import QKeySequence, QStandardItemModel, QStandardItem, QFont, QColor
from PyQt5.QtWidgets import QAction, QMessageBox
from Engine.src.editor.globalconfiglistpopup import GlobalConfigPopUpDialog
import os

QWidgetUi = uic.loadUiType("Engine/src/editor/globalconfigwindow.ui")[0]


class StandardEditableItem(QStandardItem):
    def __init__(self, txt='', font_size=12, set_bold=False, color=QColor(0, 0, 0)):
        super().__init__()

        fnt = QFont('Open Sans', font_size)
        fnt.setBold(set_bold)

        self.setEditable(True)
        self.setForeground(color)
        self.setFont(fnt)
        self.setText(txt)


class StandardUnEditableItem(QStandardItem):
    def __init__(self, txt='', font_size=12, set_bold=False, color=QColor(0, 0, 0)):
        super().__init__()

        fnt = QFont('Open Sans', font_size)
        fnt.setBold(set_bold)

        self.setEditable(False)
        self.setForeground(color)
        self.setFont(fnt)
        self.setText(txt)


class GlobalConfigWindow(QtWidgets.QDialog, QWidgetUi):
    def __init__(self, initConfig, parent=None):
        super().__init__(parent)
        self.setFixedSize(640, 493)
        self.setupUi(self)
        self.initButtons()
        self.treeModel = QStandardItemModel()
        self.rootNode = self.treeModel.invisibleRootItem()
        self.globalConfigTreeView.setHeaderHidden(True)
        self.globalConfigTreeView.setModel(self.treeModel)
        self.addedConfig = set()
        self.camera_attached_object_id = None
        if initConfig:
            self.fillModelFromJson(self.rootNode, initConfig)
            for property_key, _ in initConfig.items():
                self.addedConfig.add(property_key)

        self.exit = QAction("Exit Application", shortcut=QKeySequence("Ctrl+q"), triggered=lambda: self.exit_app)
        self.addAction(self.exit)
        self.treeViewDict = None
        self.mapping = {
            "Screen Dimensions": self.addScreenDimButtonAction,
            "Background Color": self.addBackgroundColorButtonAction,
            "Background Image": self.addBackgroundImageButtonAction,
            "Background Music": self.addBackgroundMusicButtonAction,
            "Gravity": self.addGravityButtonAction,
            "Camera Follows": self.attachCameraButtonAction
        }

    def initButtons(self):
        self.addConfigButton.clicked.connect(self.displayConfigListPopUp)
        self.saveConfigButton.clicked.connect(self.saveConfigData)
        self.deleteConfigButton.clicked.connect(self.deleteConfigData)

    def fillModelFromJson(self, parent, d):
        if isinstance(d, dict):
            for k, v in d.items():
                child = StandardUnEditableItem(str(k))
                if parent == self.rootNode:
                    child = StandardUnEditableItem(str(k))
                parent.appendRow(child)
                self.fillModelFromJson(child, v)
        elif isinstance(d, list):
            for v in d:
                self.fillModelFromJson(parent, v)
        else:
            parent.appendRow(StandardEditableItem(str(d)))

    def fillDictFromModel(self, parent_index, d):
        v = {}
        for i in range(self.treeModel.rowCount(parent_index)):
            ix = self.treeModel.index(i, 0, parent_index)
            if self.treeModel.rowCount(ix) == 0:
                d[parent_index.data()] = ix.data()
                return
            self.fillDictFromModel(ix, v)
        d[parent_index.data()] = v

    def checkForDuplicateConfigKeys(self):
        unique_keys = set()
        for i in range(self.treeModel.rowCount()):
            ix = self.treeModel.index(i, 0)
            if ix.data() in unique_keys:
                return True
            unique_keys.add(ix.data())
        return False

    def modelToDict(self):
        if self.checkForDuplicateConfigKeys():
            QMessageBox.warning(self, "", "Looks like you have duplicate config keys! Try again.")
            return {}, -1
        d = dict()
        for i in range(self.treeModel.rowCount()):
            ix = self.treeModel.index(i, 0)
            self.fillDictFromModel(ix, d)
        print(d)
        return d, 0

    @QtCore.pyqtSlot()
    def displayConfigListPopUp(self):
        ex = GlobalConfigPopUpDialog()
        ex.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        configSelected = None
        if ex.exec_() == QtWidgets.QDialog.Accepted:
            configSelected = ex.selectedConfig
        if configSelected:
            self.mapping[configSelected]()

    @QtCore.pyqtSlot()
    def deleteConfigData(self):
        for ix in self.globalConfigTreeView.selectedIndexes():
            if ix.data() == "Screen Dimensions" or ix.data() == "Background Color":
                QMessageBox.warning(self, "", "These configurations cannot be deleted!")
                return
            if ix.data() in self.mapping:
                self.treeModel.removeRow(ix.row(), ix.parent())
                self.addedConfig.remove(ix.data()) if ix.data() and ix.data() != "None" else None

    def individualFieldValidityChecker(self, tree_dict):
        for config_key, config_val in tree_dict.items():
            if config_key == "Screen Dimensions":
                try:
                    x, y = int(config_val["screen-width"]), int(config_val["screen-height"])
                    if x <= 0 or y <= 0:
                        QMessageBox.warning(self, "", "Screen Dimensions should be greater than 0! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Screen Dimensions! Try again.")
                    return False
            elif "a" in config_val and "r" in config_val and "g" in config_val and "b" in config_val:
                try:
                    a, r, g, b = int(config_val["a"]), int(config_val["r"]), int(config_val["g"]), int(
                        config_val["b"])
                    if not ((0 <= a <= 255) and (0 <= r <= 255) and (0 <= g <= 255) and (0 <= b <= 255)):
                        QMessageBox.warning(self, "", "Color values should be between 0 and 255! Try again.")
                        return False
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Color values! Try again.")
                    return False
            elif config_key == "Background Music":
                if not os.path.isfile(config_val):
                    QMessageBox.warning(self, "", "Invalid path! Try again.")
                    return False
            elif config_key == "Background Image":
                print(config_val)
                if not os.path.exists(config_val):
                    QMessageBox.warning(self, "", "Invalid path! Try again.")
                    return False
            elif config_key == "Gravity":
                try:
                    x = float(config_val)
                except ValueError:
                    QMessageBox.warning(self, "", "Invalid Gravity value! Try again.")
                    return False
        return True

    @QtCore.pyqtSlot()
    def saveConfigData(self):
        self.treeViewDict, flag = self.modelToDict()
        if flag == -1:
            return
        if not self.individualFieldValidityChecker(self.treeViewDict):
            return
        self.accept()

    @QtCore.pyqtSlot()
    def addScreenDimButtonAction(self):
        screen_dim = StandardUnEditableItem('Screen Dimensions')
        width_label = StandardUnEditableItem("screen-width")
        height_label = StandardUnEditableItem("screen-height")
        width = StandardEditableItem(str(1200))
        height = StandardEditableItem(str(800))
        width_label.appendRow(width)
        height_label.appendRow(height)
        screen_dim.appendRow(width_label)
        screen_dim.appendRow(height_label)
        self.rootNode.appendRow(screen_dim)

    @QtCore.pyqtSlot()
    def addBackgroundColorButtonAction(self):
        color = StandardUnEditableItem('Background Color')
        a_label = StandardUnEditableItem("a")
        r_label = StandardUnEditableItem("r")
        g_label = StandardUnEditableItem("g")
        b_label = StandardUnEditableItem("b")
        r = StandardEditableItem(str(0))
        g = StandardEditableItem(str(0))
        b = StandardEditableItem(str(0))
        a = StandardEditableItem(str(0))
        a_label.appendRow(a)
        r_label.appendRow(r)
        g_label.appendRow(g)
        b_label.appendRow(b)
        color.appendRow(a_label)
        color.appendRow(r_label)
        color.appendRow(g_label)
        color.appendRow(b_label)
        self.rootNode.appendRow(color)

    @QtCore.pyqtSlot()
    def addBackgroundImageButtonAction(self):
        background_image = StandardUnEditableItem('Background Image')
        image_path = StandardEditableItem("Click to edit")
        background_image.appendRow(image_path)
        self.rootNode.appendRow(background_image)

    @QtCore.pyqtSlot()
    def attachCameraButtonAction(self):
        camera = StandardUnEditableItem('Camera Follows')
        object_attached = StandardEditableItem("Click to edit")
        camera.appendRow(object_attached)
        self.rootNode.appendRow(camera)

    @QtCore.pyqtSlot()
    def addBackgroundMusicButtonAction(self):
        background_music = StandardUnEditableItem('Background Music')
        music_path = StandardEditableItem("Click to edit")
        background_music.appendRow(music_path)
        self.rootNode.appendRow(background_music)

    @QtCore.pyqtSlot()
    def addGravityButtonAction(self):
        gravity_label = StandardUnEditableItem('Gravity')
        gravity = StandardEditableItem("Click to edit")
        gravity_label.appendRow(gravity)
        self.rootNode.appendRow(gravity_label)