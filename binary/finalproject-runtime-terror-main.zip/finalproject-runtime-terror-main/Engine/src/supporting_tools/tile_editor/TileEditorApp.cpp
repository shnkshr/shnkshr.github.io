//
// Created by psx95 on 4/22/21.
//

#include "supporting_tools/tile_editor/TileEditorApp.hpp"
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include <SDL_mouse.h>
#include <SDL_keyboard.h>
#include <supporting_tools/tile_editor/TileRenderer.hpp>
#include <supporting_tools/tile_editor/TileMap.hpp>
#include <api/ResourceManager.hpp>

#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) ((a) < (b) ? (b) : (a))
#endif

#define NK_INCLUDE_FIXED_TYPES
#define NK_INCLUDE_STANDARD_IO
#define NK_INCLUDE_STANDARD_VARARGS
#define NK_INCLUDE_DEFAULT_ALLOCATOR
#define NK_IMPLEMENTATION
#define NK_INCLUDE_FONT_BAKING
#define NK_INCLUDE_DEFAULT_FONT
#define NK_INCLUDE_SOFTWARE_FONT
#include "nuklear.h"
#define NK_SDLSURFACE_IMPLEMENTATION
#include "sdl2surface_rawfb.h"

struct nk_colorf bg{};
struct nk_color clear = {0, 100, 0, 255};
char bmp_config[4][64];
int bmp_config_len[4];

bool ValidateSaveFileName(char *file_name) {
  if (strlen(file_name) >= 4 && strcmp(file_name + strlen(file_name) - 4, ".txt") == 0) {
    return true;
  }
  return false;
}

bool ValidateBMPConfig() {
  return bmp_config_len[0] != 0 && bmp_config_len[1] != 0 && bmp_config_len[2] != 0 && bmp_config_len[3] != 0;
}

void UpdateTileRenderWithBMPConfig(TileRenderer *tile_renderer) {
  unsigned long src_tile_height = strtoul(bmp_config[0], nullptr, 10);
  unsigned long src_tile_width = strtoul(bmp_config[1], nullptr, 10);
  unsigned long dest_tile_height = strtoul(bmp_config[2], nullptr, 10);
  unsigned long dest_tile_width = strtoul(bmp_config[3], nullptr, 10);
  tile_renderer->SetTileWidth(static_cast<int>(src_tile_width));
  tile_renderer->SetTileHeight(static_cast<int>(src_tile_height));
  tile_renderer->SetTileDestHeight(static_cast<int>(dest_tile_height));
  tile_renderer->SetTileDestWidth(static_cast<int>(dest_tile_width));
}

void
grid_demo(struct nk_context *ctx) {
  static char text[3][64];
  static int text_len[3];
  static const char *items[] = {"Item 0", "item 1", "item 2"};
  static int selected_item = 0;
  static int check = 1;

  int i;
  if (nk_begin(ctx, "Grid Demo", nk_rect(600, 350, 275, 250),
               NK_WINDOW_TITLE | NK_WINDOW_BORDER | NK_WINDOW_MOVABLE |
                   NK_WINDOW_NO_SCROLLBAR)) {
    nk_layout_row_dynamic(ctx, 30, 2);
    nk_label(ctx, "Floating point:", NK_TEXT_RIGHT);
    nk_edit_string(ctx, NK_EDIT_FIELD, text[0], &text_len[0], 64, nk_filter_float);
    nk_label(ctx, "Hexadecimal:", NK_TEXT_RIGHT);
    nk_edit_string(ctx, NK_EDIT_FIELD, text[1], &text_len[1], 64, nk_filter_hex);
    nk_label(ctx, "Binary:", NK_TEXT_RIGHT);
    nk_edit_string(ctx, NK_EDIT_FIELD, text[2], &text_len[2], 64, nk_filter_binary);
    nk_label(ctx, "Checkbox:", NK_TEXT_RIGHT);
    nk_checkbox_label(ctx, "Check me", &check);
    nk_label(ctx, "Combobox:", NK_TEXT_RIGHT);
    if (nk_combo_begin_label(ctx, items[selected_item], nk_vec2(nk_widget_width(ctx), 200))) {
      nk_layout_row_dynamic(ctx, 25, 1);
      for (i = 0; i < 3; ++i)
        if (nk_combo_item_label(ctx, items[i], NK_TEXT_LEFT))
          selected_item = i;
      nk_combo_end(ctx);
    }
  }
  nk_end(ctx);
}

void TileEditorApp::Init(int screen_width, int screen_height) {
  app_running = true;
  SDL_Init(SDL_INIT_VIDEO);
  printf("sdl init called...\n");
  SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
  window = SDL_CreateWindow("Tile Editor",
                            SDL_WINDOWPOS_UNDEFINED,
                            SDL_WINDOWPOS_UNDEFINED,
                            screen_width,
                            screen_height,
                            SDL_WINDOW_OPENGL);
  if (!window) {
    printf("can't open window!\n");
    exit(1);
  }

  InitSDLImage();

  renderer = SDL_CreateRenderer(window, -1, 0);
  surface = SDL_CreateRGBSurfaceWithFormat(0, screen_width, screen_height, 32, SDL_PIXELFORMAT_ARGB8888);
  context = nk_sdlsurface_init(surface, 13.0f);
  camera = {0, 0, screen_width - 300, screen_height - 300};
  ResourceManager::GetInstance()->Initialize(renderer);
  tile_renderer = new TileRenderer(5, 10);
}

void TileEditorApp::StartTileEditorApp(int window_width, int window_height) {
  struct nk_vec2 vec{};
  struct nk_rect bounds = {40, 40, 0, 0};
  std::string render_result = "Ready";

  Init(window_width, window_height);
  SDL_SetWindowGrab(window, SDL_FALSE);
  while (app_running) {
    nk_input_begin(&(context->ctx));

    // Handle User Input
    SDL_Event event;
    while (SDL_PollEvent(&event)) {
      HandleUserInputEvents(event, vec);
    }
    UpdateCameraPosition();
    // Render the UI
    bounds.w = 400;
    bounds.h = 400;
    if (nk_begin(&(context->ctx),
                 "Tile Map Configuration",
                 bounds,
                 NK_WINDOW_BORDER | NK_WINDOW_MOVABLE | NK_WINDOW_SCALABLE | NK_WINDOW_TITLE)) {
      static SupportedTileFormats op = PNG;
      static int property = 20;

      // label for tile config
      nk_layout_row_dynamic(&(context->ctx), 20, 1);
      nk_label(&(context->ctx), "Tile Format", NK_TEXT_LEFT);

      nk_layout_row_dynamic(&(context->ctx), 40, 2);
      if (nk_option_label(&(context->ctx), "PNG", op == PNG)) op = PNG;
      if (nk_option_label(&(context->ctx), "BMP", op == BMP)) op = BMP;

      if (op == BMP) {
        SetupBMPTileConfigUI();
      }

      //SetupBackgroundColorSelectionUpdate();
      nk_layout_row_dynamic(&(context->ctx), 20, 1);
      nk_label(&(context->ctx), "Input Tile Map as 2D matrix", NK_TEXT_LEFT);
      nk_layout_row_dynamic(&(context->ctx), (0.4f * (float) bounds.h), 1);
      nk_edit_string_zero_terminated(&(context->ctx), NK_EDIT_BOX | NK_EDIT_EDITOR,
                                     proposed_tile_map,
                                     sizeof(proposed_tile_map),
                                     nk_filter_ascii);//nk_filter_ascii Text Edit accepts text types.
      // render button
      nk_layout_row_static(&(context->ctx), 30, 200, 1);
      if (nk_button_label(&(context->ctx), "Update Config")) {
        printf("button pressed\n");
        int i;
        for (i = 0; i < 2000; i++) {
          if (proposed_tile_map[i] == 0) {
            break;
          }
          if (proposed_tile_map[i] == '\n') {
            std::cout << std::endl;
          } else {
            std::cout << proposed_tile_map[i] << " ";
          }
        }
        std::cout << "num chars " << i << std::endl;
        render_result = tile_renderer->RenderTiles(renderer, surface, proposed_tile_map, op, &camera);
        if (op == BMP) {
          if (ValidateBMPConfig()) {
            selected_format = op;
            UpdateTileRenderWithBMPConfig(tile_renderer);
          } else {
            render_result = "BMP config invalid, provide all values";
          }
        } else if (op == PNG) {
          tile_renderer->SwitchTileConfigToPng();
          selected_format = op;
        }
      }
      nk_layout_row_dynamic(&(context->ctx), (10), 1);
      nk_layout_row_dynamic(&(context->ctx), (0.1f * (float) bounds.h), 1);
      nk_label_colored_wrap(&(context->ctx), render_result.c_str(), nk_rgba(180, 170, 4, 255));
      SetupTileSaveDialogUI(render_result);
    }

    nk_end(&(context->ctx));
    nk_sdlsurface_render(context, clear, 1);
    SDL_UpdateWindowSurface(window);
    texture = SDL_CreateTextureFromSurface(renderer, surface);
    SDL_RenderCopy(renderer, texture, NULL, NULL);
    SDL_SetRenderDrawColor(renderer, 200, 0, 0, 255);
    SDL_RenderDrawRect(renderer, &camera);
    tile_renderer->RenderTiles(renderer, surface, proposed_tile_map, selected_format, &camera);
    SDL_RenderPresent(renderer);
    SDL_DestroyTexture(texture);
    //SDL_DestroyTexture(img_texture);
    nk_input_end(&(context->ctx));
  }

  nk_sdlsurface_shutdown(context);

  SDL_FreeSurface(surface);
  SDL_DestroyRenderer(renderer);
  SDL_DestroyWindow(window);
}

void TileEditorApp::SetupBMPTileConfigUI() {
  nk_layout_row_dynamic(&(context->ctx), 30, 2);
  nk_label(&(context->ctx), "Source Tile Height:", NK_TEXT_LEFT);
  nk_edit_string(&(context->ctx), NK_EDIT_FIELD, bmp_config[0], &bmp_config_len[0], 64, nk_filter_decimal);
  nk_label(&(context->ctx), "Source Tile Width:", NK_TEXT_LEFT);
  nk_edit_string(&(context->ctx), NK_EDIT_FIELD, bmp_config[1], &bmp_config_len[1], 64, nk_filter_decimal);
  nk_label(&(context->ctx), "Destination Tile Height:", NK_TEXT_LEFT);
  nk_edit_string(&(context->ctx), NK_EDIT_FIELD, bmp_config[2], &bmp_config_len[2], 64, nk_filter_decimal);
  nk_label(&(context->ctx), "Destination Tile Width:", NK_TEXT_LEFT);
  nk_edit_string(&(context->ctx), NK_EDIT_FIELD, bmp_config[3], &bmp_config_len[3], 64, nk_filter_decimal);
}

void TileEditorApp::SetupTileSaveDialogUI(std::string &tile_io_result) {
  static int save_popup_active;
  static int load_popup_active;
  static char file_name_text[15];
  static int file_name_length;
  nk_layout_row_dynamic(&(context->ctx), 30, 3);
  if (nk_button_label(&(context->ctx), "Save Tile Map"))
    save_popup_active = 1;
  nk_spacing(&(context->ctx), 1);
  if (nk_button_label(&(context->ctx), "Load Tile Map"))
    load_popup_active = 1;

  if (save_popup_active) {
    static struct nk_rect popup_bounds = {20, 100, 300, 120};
    if (nk_popup_begin(&(context->ctx), NK_POPUP_STATIC, "Save Map", 0, popup_bounds)) {
      nk_layout_row_dynamic(&(context->ctx), 20, 1);
      nk_label(&(context->ctx), "File Name", NK_TEXT_LEFT);
      nk_edit_string(&(context->ctx), NK_EDIT_FIELD, file_name_text, &file_name_length, 60, nk_filter_ascii);
      nk_layout_row_dynamic(&(context->ctx), 25, 2);
      if (nk_button_label(&(context->ctx), "OK")) {
        // validate and save file
        if (!ValidateSaveFileName(file_name_text)) {
          tile_io_result.clear();
          tile_io_result.append("File name for tile map invalid. Must end with .txt.");
        }
        if (tile_renderer->SaveTileMapToAssets(file_name_text)) {
          tile_io_result.clear();
          tile_io_result.append("File saved successfully to Assets");
        } else {
          tile_io_result.clear();
          tile_io_result.append("File save to Assets failed");
        }
        save_popup_active = 0;
        nk_popup_close(&(context->ctx));
      }
      if (nk_button_label(&(context->ctx), "Cancel")) {
        save_popup_active = 0;
        nk_popup_close(&(context->ctx));
      }
      nk_popup_end(&(context->ctx));
    } else save_popup_active = 0;
  }
  if (load_popup_active) {
    static struct nk_rect popup_bounds = {20, 100, 300, 120};
    if (nk_popup_begin(&(context->ctx), NK_POPUP_STATIC, "Load Map", 0, popup_bounds)) {
      nk_layout_row_dynamic(&(context->ctx), 20, 1);
      nk_label(&(context->ctx), "File Name", NK_TEXT_LEFT);
      nk_edit_string(&(context->ctx), NK_EDIT_FIELD, file_name_text, &file_name_length, 60, nk_filter_ascii);
      nk_layout_row_dynamic(&(context->ctx), 25, 2);
      if (nk_button_label(&(context->ctx), "OK")) {
        // validate and save file
        if (!ValidateSaveFileName(file_name_text)) {
          tile_io_result.clear();
          tile_io_result.append("File name for tile map invalid. Must end with .txt.");
        }
        std::string load_res = TileMap::LoadTileMapFromAssets(file_name_text);
        if (!load_res.empty()) {
          std::size_t length = load_res.copy(proposed_tile_map, 2000, 0);
          proposed_tile_map[length] = '\0';
          std::cout << "Loaded map " << std::endl;
          std::cout << proposed_tile_map << std::endl;
          tile_io_result.clear();
          tile_io_result.append("File loaded successfully from Assets");
        } else {
          tile_io_result.clear();
          tile_io_result.append("Unable to load file with given name");
        }
        load_popup_active = 0;
        nk_popup_close(&(context->ctx));
      }
      if (nk_button_label(&(context->ctx), "Cancel")) {
        load_popup_active = 0;
        nk_popup_close(&(context->ctx));
      }
      nk_popup_end(&(context->ctx));
    } else load_popup_active = 0;
  }
}

// enables programmatic shutdown
void TileEditorApp::ShutdownTileEditorApp() {
  this->app_running = false;
}

void TileEditorApp::HandleUserInputEvents(SDL_Event &event, struct nk_vec2 &vec) {
  if (event.type == SDL_QUIT) {
    ShutdownTileEditorApp();
  } else if (event.type == SDL_KEYDOWN) {
    UpdateMovement(event, true);
  } else if (event.type == SDL_KEYUP) {
    UpdateMovement(event, false);
  }
  nk_sdl_handle_event(&event);
}

void TileEditorApp::InitSDLImage() {
//Initialize PNG loading
  std::cout << "Init SDL Image " << std::endl;
  bool success = true;
  int imgFlags = IMG_INIT_PNG;
  if (!(IMG_Init(imgFlags) & imgFlags)) {
    printf("SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError());
    success = false;
  }
  if (!success) {
    exit(1);
  }
}

int TileEditorApp::nk_sdl_handle_event(SDL_Event *evt) {
  struct nk_context *ctx = &(context->ctx);

  /* optional grabbing behavior */
  if (ctx->input.mouse.grab) {
    SDL_SetRelativeMouseMode(SDL_TRUE);
    ctx->input.mouse.grab = 0;
  } else if (ctx->input.mouse.ungrab) {
    int x = (int) ctx->input.mouse.prev.x, y = (int) ctx->input.mouse.prev.y;
    SDL_SetRelativeMouseMode(SDL_FALSE);
    SDL_WarpMouseInWindow(window, x, y);
    ctx->input.mouse.ungrab = 0;
  }
  if (evt->type == SDL_KEYUP || evt->type == SDL_KEYDOWN) {
    /* key events */
    int down = evt->type == SDL_KEYDOWN;
    const Uint8 *state = SDL_GetKeyboardState(0);
    SDL_Keycode sym = evt->key.keysym.sym;
    if (sym == SDLK_RSHIFT || sym == SDLK_LSHIFT)
      nk_input_key(ctx, NK_KEY_SHIFT, down);
    else if (sym == SDLK_DELETE)
      nk_input_key(ctx, NK_KEY_DEL, down);
    else if (sym == SDLK_RETURN)
      nk_input_key(ctx, NK_KEY_ENTER, down);
    else if (sym == SDLK_TAB)
      nk_input_key(ctx, NK_KEY_TAB, down);
    else if (sym == SDLK_BACKSPACE)
      nk_input_key(ctx, NK_KEY_BACKSPACE, down);
    else if (sym == SDLK_HOME) {
      nk_input_key(ctx, NK_KEY_TEXT_START, down);
      nk_input_key(ctx, NK_KEY_SCROLL_START, down);
    } else if (sym == SDLK_END) {
      nk_input_key(ctx, NK_KEY_TEXT_END, down);
      nk_input_key(ctx, NK_KEY_SCROLL_END, down);
    } else if (sym == SDLK_PAGEDOWN) {
      nk_input_key(ctx, NK_KEY_SCROLL_DOWN, down);
    } else if (sym == SDLK_PAGEUP) {
      nk_input_key(ctx, NK_KEY_SCROLL_UP, down);
    } else if (sym == SDLK_z)
      nk_input_key(ctx, NK_KEY_TEXT_UNDO, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_r)
      nk_input_key(ctx, NK_KEY_TEXT_REDO, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_c)
      nk_input_key(ctx, NK_KEY_COPY, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_v)
      nk_input_key(ctx, NK_KEY_PASTE, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_x)
      nk_input_key(ctx, NK_KEY_CUT, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_b)
      nk_input_key(ctx, NK_KEY_TEXT_LINE_START, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_e)
      nk_input_key(ctx, NK_KEY_TEXT_LINE_END, down && state[SDL_SCANCODE_LCTRL]);
    else if (sym == SDLK_UP)
      nk_input_key(ctx, NK_KEY_UP, down);
    else if (sym == SDLK_DOWN)
      nk_input_key(ctx, NK_KEY_DOWN, down);
    else if (sym == SDLK_LEFT) {
      if (state[SDL_SCANCODE_LCTRL])
        nk_input_key(ctx, NK_KEY_TEXT_WORD_LEFT, down);
      else nk_input_key(ctx, NK_KEY_LEFT, down);
    } else if (sym == SDLK_RIGHT) {
      if (state[SDL_SCANCODE_LCTRL])
        nk_input_key(ctx, NK_KEY_TEXT_WORD_RIGHT, down);
      else nk_input_key(ctx, NK_KEY_RIGHT, down);
    } else return 0;
    return 1;
  } else if (evt->type == SDL_MOUSEBUTTONDOWN || evt->type == SDL_MOUSEBUTTONUP) {
    /* mouse button */
    int down = evt->type == SDL_MOUSEBUTTONDOWN;
    const int x = evt->button.x, y = evt->button.y;
    if (evt->button.button == SDL_BUTTON_LEFT) {
      if (evt->button.clicks > 1)
        nk_input_button(ctx, NK_BUTTON_DOUBLE, x, y, down);
      nk_input_button(ctx, NK_BUTTON_LEFT, x, y, down);
    } else if (evt->button.button == SDL_BUTTON_MIDDLE)
      nk_input_button(ctx, NK_BUTTON_MIDDLE, x, y, down);
    else if (evt->button.button == SDL_BUTTON_RIGHT)
      nk_input_button(ctx, NK_BUTTON_RIGHT, x, y, down);
    return 1;
  } else if (evt->type == SDL_MOUSEMOTION) {
    /* mouse motion */
    if (ctx->input.mouse.grabbed) {
      int x = (int) ctx->input.mouse.prev.x, y = (int) ctx->input.mouse.prev.y;
      nk_input_motion(ctx, x + evt->motion.xrel, y + evt->motion.yrel);
    } else nk_input_motion(ctx, evt->motion.x, evt->motion.y);
    return 1;
  } else if (evt->type == SDL_TEXTINPUT) {
    /* text input */
    nk_glyph glyph;
    memcpy(glyph, evt->text.text, NK_UTF_SIZE);
    nk_input_glyph(ctx, glyph);
    return 1;
  } else if (evt->type == SDL_MOUSEWHEEL) {
    /* mouse wheel */
    nk_input_scroll(ctx, nk_vec2((float) evt->wheel.x, (float) evt->wheel.y));
    return 1;
  }
  return 0;
}

void TileEditorApp::SetupBackgroundColorSelectionUpdate() {
  nk_layout_row_dynamic(&(context->ctx), 20, 1);
  nk_label(&(context->ctx), "background:", NK_TEXT_LEFT);
  nk_layout_row_dynamic(&(context->ctx), 25, 1);
  if (nk_combo_begin_color(&(context->ctx), nk_rgb_cf(bg), nk_vec2(nk_widget_width(&(context->ctx)), 400))) {
    nk_layout_row_dynamic(&(context->ctx), 120, 1);
    bg = nk_color_picker(&(context->ctx), nk_color_cf(clear), NK_RGBA);
    nk_layout_row_dynamic(&(context->ctx), 25, 1);
    bg.r = nk_propertyf(&(context->ctx), "#R:", 0, bg.r, 1.0f, 0.01f, 0.005f);
    bg.g = nk_propertyf(&(context->ctx), "#G:", 0, bg.g, 1.0f, 0.01f, 0.005f);
    bg.b = nk_propertyf(&(context->ctx), "#B:", 0, bg.b, 1.0f, 0.01f, 0.005f);
    bg.a = nk_propertyf(&(context->ctx), "#A:", 0, bg.a, 1.0f, 0.01f, 0.005f);
    nk_combo_end(&(context->ctx));
  }
}

void TileEditorApp::UpdateMovement(SDL_Event &event, bool keydown) {
  if (event.key.keysym.sym == SDLK_LEFT) {
    move_left = keydown;
  }
  if (event.key.keysym.sym == SDLK_RIGHT) {
    move_right = keydown;
  }
  if (event.key.keysym.sym == SDLK_UP) {
    move_up = keydown;
  }
  if (event.key.keysym.sym == SDLK_DOWN) {
    move_down = keydown;
  }
}

void TileEditorApp::UpdateCameraPosition() {
  // update position of character
  if (move_right || move_left) {
    int move_dir_coefficient = move_right ? 10 : -10;
    camera.x += move_dir_coefficient;
    if ((camera.x < 0)) {
      //Move back
      camera.x -= move_dir_coefficient;
    }
  }

  if (move_down || move_up) {
    int move_dir_coefficient = move_down ? 10 : -10;
    camera.y += move_dir_coefficient;
    if ((camera.y < 0)) {
      //Move back
      camera.y -= move_dir_coefficient;
    }
  }
}

TileEditorApp::~TileEditorApp() {
  if (this->app_running) {
    std::cerr << "Missed call to ShutdownTileEditor, may not be a clean shutdown " << std::endl;
  }
  if (context != nullptr) {
    context = nullptr;
  }
  if (surface != nullptr) {
    surface = nullptr;
  }
  if (renderer != nullptr) {
    renderer = nullptr;
  }
  if (window != nullptr) {
    window = nullptr;
  }
  delete tile_renderer;
}
