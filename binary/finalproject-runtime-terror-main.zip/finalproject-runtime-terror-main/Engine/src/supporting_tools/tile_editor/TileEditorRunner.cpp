//
// Created by psx95 on 4/22/21.
//

#include <supporting_tools/tile_editor/TileEditorApp.hpp>
#include <api/ResourceManager.hpp>
#include "supporting_tools/tile_editor/TileEditorRunner.hpp"

std::string TileEditorRunner::png_tiles_location;
std::string TileEditorRunner::bmp_tile_map_location;

void TileEditorRunner::RunApp(int screen_width, int screen_height, const std::string &bmp_tile_map,
                              const std::string &png_tiles_location_path) {
  TileEditorRunner::bmp_tile_map_location = bmp_tile_map;
  TileEditorRunner::png_tiles_location = png_tiles_location_path;
  TileEditorApp tile_editor_app;
  tile_editor_app.StartTileEditorApp(screen_width, screen_height);
  ResourceManager::GetInstance()->Shutdown();
}

const std::string &TileEditorRunner::GetPngTilesLocation() {
  return TileEditorRunner::png_tiles_location;
}

const std::string &TileEditorRunner::GetBmpTileMapLocation() {
  return TileEditorRunner::bmp_tile_map_location;
}
