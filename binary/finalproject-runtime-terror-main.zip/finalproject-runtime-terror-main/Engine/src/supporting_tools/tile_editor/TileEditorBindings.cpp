//
// Created by psx95 on 4/22/21.
//
#include <supporting_tools/tile_editor/TileEditorRunner.hpp>
#include "pybind11/pybind11.h"
namespace py = pybind11;

PYBIND11_MODULE(tile_editor, editor_lib) {
  editor_lib.doc() = "Library that provides access to run this application from python";

  py::class_<TileEditorRunner>(editor_lib, "TileEditorRunner")
      .def_static("RunApp",
                  &TileEditorRunner::RunApp,
                  py::arg("screen_width"),
                  py::arg("screen_height"),
                  py::arg("bmp_tile_map"),
                  py::arg("png_tiles_location_path"))
      .def_static("GetPngTilesLocation", &TileEditorRunner::GetPngTilesLocation)
      .def_static("GetBmpTileMapLocation", &TileEditorRunner::GetBmpTileMapLocation);
}
