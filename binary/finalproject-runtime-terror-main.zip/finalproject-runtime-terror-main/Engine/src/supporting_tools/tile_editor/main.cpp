//
// Created by psx95 on 4/22/21.
//

#include <supporting_tools/tile_editor/TileEditorRunner.hpp>
/**
 * The main method is only used when running the tile map editor in isolation with rest of the game engine.*/
int main(int argc, char **argv) {
  TileEditorRunner::RunApp(1080, 720, "sample_bmp", "sample_png");
  return 0;
}