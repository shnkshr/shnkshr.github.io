//
// Created by psx95 on 4/22/21.
//

#include "supporting_tools/tile_editor/TileMap.hpp"
#include <iostream>
#include "fstream"
TileMap::TileMap(int num_rows, int num_cols, int *tiles) : num_rows(num_rows), num_cols(num_cols), tiles(tiles) {
}

bool TileMap::SaveTileMapToAssets(const std::string &complete_file_path) {
  std::ofstream tile_map_file(complete_file_path);
  if (tile_map_file.is_open()) {
    for (int i = 0; i < num_rows; i++) {
      for (int j = 0; j < num_cols; j++) {
        tile_map_file << std::to_string(tiles[i * num_cols + j]);
        if (j != num_cols - 1) {
          tile_map_file << " ";
        }
      }
      tile_map_file << "\n";
    }
    tile_map_file.close();
  } else {
    std::cerr << "Unable to Open File with name " << complete_file_path << std::endl;
    return false;
  }
  return true;
}

std::string TileMap::LoadTileMapFromAssets(const std::string &complete_file_path) {
  std::ifstream tile_map_file(complete_file_path.c_str());
  std::string row;
  std::string complete_file;
  if (tile_map_file.is_open()) {
    while (getline(tile_map_file, row)) {
      complete_file.append(row).append("\n");
    }
    tile_map_file.close();
  } else {
    std::cerr << "Unable to Open File with name " << complete_file_path << std::endl;
    return "";
  }
  return complete_file;
}

int TileMap::GetNumRows() const {
  return num_rows;
}

int TileMap::GetNumCols() const {
  return num_cols;
}

int *TileMap::GetTiles() const {
  return tiles;
}
