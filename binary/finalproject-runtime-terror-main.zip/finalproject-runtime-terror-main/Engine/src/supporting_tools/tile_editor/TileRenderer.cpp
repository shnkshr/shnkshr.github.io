//
// Created by psx95 on 4/22/21.
//

#include "supporting_tools/tile_editor/TileRenderer.hpp"

#include <vector>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <supporting_tools/tile_editor/TileMap.hpp>
#include "supporting_tools/tile_editor/TileEditorRunner.hpp"
#include <api/ResourceManager.hpp>

TileRenderer::TileRenderer(int max_tile_rows_visible, int max_tile_columns_visible)
    : max_tile_rows_visible(max_tile_rows_visible), max_tile_columns_visible(max_tile_columns_visible) {
  png_tiles_location = TileEditorRunner::GetPngTilesLocation();
  bmp_tiles_location = TileEditorRunner::GetBmpTileMapLocation();
  bmp_num_cols = 8;
  bmp_num_rows = 8;
  SDL_GetDesktopDisplayMode(0, &dm);
  SwitchTileConfigToPng();
}

TileRenderer::TileRenderer() {
  max_tile_columns_visible = 10;
  max_tile_rows_visible = 10;
  tile_width = 100;
  tile_height = 100;
  tile_dest_width = 100;
  tile_dest_height = 100;
  png_tiles_location = TileEditorRunner::GetPngTilesLocation();
  bmp_tiles_location = TileEditorRunner::GetBmpTileMapLocation();
  bmp_num_cols = 8;
  bmp_num_rows = 8;

}

std::string TileRenderer::RenderTiles(SDL_Renderer *renderer, SDL_Surface *window_surface,
                                      char *proposed_tile_map,
                                      SupportedTileFormats tile_format,
                                      SDL_Rect *camera) {
  this->tiles = nullptr;
  std::string message;
  if (!VerifyTileMapFormatOK(proposed_tile_map, message)) {
    // verification failed
    std::cout << "verification failed " << std::endl;
    return message;
  } else {
    // verification success, render tiles
    if (tile_format == PNG) {
      RenderTileFromPng(renderer, window_surface, camera);
    } else if (tile_format == BMP) {
      RenderTileFromBmp(renderer, window_surface, camera);
    } else {
      return "Unsupported Tile Format";
    }
  }
  return "ok";
}

bool TileRenderer::VerifyTileMapFormatOK(char *proposed_tile_map, std::string &message) {
  std::stringstream tile_map_stream(proposed_tile_map);
  std::string temp;
  std::vector<std::string> rows;
  while (getline(tile_map_stream, temp, '\n')) {
    rows.push_back(temp);
  }
  num_rows = rows.size();
  max_columns = 0;
  std::vector<std::vector<int>> int_rows;
  for (const std::string &row: rows) {
    std::stringstream row_stream(row);
    std::string column_value;
    std::vector<int> columns;
    while (getline(row_stream, column_value, ' ')) {
      char *endptr;
      int parsed_num = strtol(column_value.c_str(), &endptr, 10);
      if (endptr == column_value.c_str()) {
        // failure
        message = "Unable to parse " + column_value + " as a number";
        return false;
      }
      columns.push_back(parsed_num);
    }
    max_columns = max_columns > columns.size() ? max_columns : columns.size();
    int_rows.push_back(columns);
  }
  this->tiles = new int[num_rows * max_columns];
  for (int i = 0; i < num_rows * max_columns; i++) {
    tiles[i] = -1; // Default value is no tile.
  }
  PopulateTiles(int_rows);
  return true;
}

bool TileRenderer::RenderTileFromPng(SDL_Renderer *renderer, SDL_Surface *window_surface, SDL_Rect *camera) {
  if (renderer == nullptr) {
    SDL_Log("No valid renderer found");
    return false;
  }
  SDL_Rect Dest;
  // camera
  SDL_Rect tiles_on_screen;
  tiles_on_screen.x = camera != nullptr ? camera->w / tile_width + 4 : max_tile_columns_visible;
  tiles_on_screen.y = camera != nullptr ? camera->h / tile_height + 4 : max_tile_rows_visible;

  int start_x = camera != nullptr ? camera->x / tile_width : 0;
  int start_y = camera != nullptr ? camera->y / tile_height : 0;

  for (int y = start_y; y < start_y + tiles_on_screen.y; y++) {
    for (int x = start_x; x < start_x + tiles_on_screen.x; x++) {
      if ((x < max_columns) && (x > -1) && (y < num_rows) && (y > -1)) {
        // Select our Tile
        int currentTile = GetTileType(x, y);
        if (currentTile > -1) {
          std::string tile_id(png_tiles_location);
          tile_id.append(std::to_string(currentTile)).append(".png");
          SDL_Texture
              *img_texture = ResourceManager::GetInstance()->GetImageResourcePNG(tile_id);
          if (img_texture != nullptr) {
            // Render our Tile at this location
            int adj_x = camera != nullptr ? camera->x : 0;
            int adj_y = camera != nullptr ? camera->y : 0;
            Dest.x = x * tile_width - adj_x;
            Dest.y = y * tile_height - adj_y;
            Dest.w = tile_dest_width;
            Dest.h = tile_dest_height;
            SDL_RenderCopy(renderer, img_texture, nullptr, &Dest);
          } else {
            std::cout << "Empty texture " << std::endl;
          }
        }
      }
    }
  }
  return true;
}

bool TileRenderer::RenderTileFromBmp(SDL_Renderer *renderer, SDL_Surface *window_surface, SDL_Rect *camera) {
  static SDL_Texture
      *bmp_tile_map =
      ResourceManager::GetInstance()->GetImageResourceBMP(bmp_tiles_location);
  if (bmp_tile_map == nullptr) {
    return false;
  }
  SDL_Rect Src, Dest;
  // camera
  SDL_Rect tiles_on_screen;
  tiles_on_screen.x = camera != nullptr ? camera->w / tile_width + 4 : max_tile_columns_visible;
  tiles_on_screen.y = camera != nullptr ? camera->h / tile_height + 4 : max_tile_rows_visible;

  int start_x = camera != nullptr ? camera->x / tile_width : 0;
  int start_y = camera != nullptr ? camera->y / tile_height : 0;

  for (int y = start_y; y < start_y + tiles_on_screen.y; y++) {
    for (int x = start_x; x < start_x + tiles_on_screen.x; x++) {
      if ((x < max_columns) && (x > -1) && (y < num_rows) && (y > -1)) {
        // Select our Tile
        int currentTile = GetTileType(x, y);
        if (currentTile > -1) {
          // Reverse lookup, given the tile type
          // and then figuring out how to select it
          // from the texture atlas.
          Src.x = (currentTile % bmp_num_cols) * tile_width; // tile_width
          Src.y = (currentTile / bmp_num_rows) * tile_height; // tile height
          Src.w = tile_width; // tile_width
          Src.h = tile_height; // tile height
          // Render our Tile at this location
          Dest.x = x * tile_dest_width; // tile_width
          Dest.y = y * tile_dest_height; // tile height
          Dest.w = tile_dest_width; // tile_width
          Dest.h = tile_dest_height; // tile height
          SDL_RenderCopy(renderer, bmp_tile_map, &Src, &Dest);
        }
      }
    }
  }
  return true;
}

void TileRenderer::PopulateTiles(std::vector<std::vector<int>> &int_map) {
  for (int y = 0; y < num_rows; y++) {
    std::vector<int> row = int_map.at(y);
    for (int x = 0; x < max_columns; x++) {
      if (x < row.size()) {
        SetTile(x, y, row.at(x));
      } else {
        SetTile(x, y, -1);
      }
    }
  }
}

void TileRenderer::PrintMap() {
  std::cout << "Current Tile Map " << std::endl;
  for (int y = 0; y < num_rows; y++) {
    for (int x = 0; x < max_columns; x++) {
      std::cout << std::setw(3) << GetTileType(x, y);
    }
    std::cout << "\n";
  }
}

void TileRenderer::SetTile(int x, int y, int type) {
  tiles[y * max_columns + x] = type;
}

int TileRenderer::GetTileType(int x, int y) {
  return tiles[y * max_columns + x];
}

bool TileRenderer::SaveTileMapToAssets(const std::string &name) {
  TileMap tile_map(num_rows, max_columns, tiles);
  return tile_map.SaveTileMapToAssets(name);
}

void TileRenderer::SetTileHeight(int updated_tile_height) {
  TileRenderer::tile_height = updated_tile_height;
}

void TileRenderer::SetTileWidth(int updated_tile_width) {
  TileRenderer::tile_width = updated_tile_width;
}

void TileRenderer::SetTileDestHeight(int bmp_dest_height) {
  TileRenderer::tile_dest_height = bmp_dest_height;
}

void TileRenderer::SetTileDestWidth(int bmp_dest_width) {
  TileRenderer::tile_dest_width = bmp_dest_width;
}

void TileRenderer::SwitchTileConfigToPng() {
  this->tile_height = (dm.h - 200) / max_tile_rows_visible;
  this->tile_width = (dm.w - 200) / max_tile_columns_visible;
  this->tile_dest_width = tile_width;
  this->tile_dest_height = tile_height;
}
