//
// Created by psx95 on 4/14/21.
//

#include <iostream>
#include <GameRunner.hpp>
#include <pybind11/embed.h> // everything needed for embedding
namespace py = pybind11;

// Use this only for debugging purposes
int main(int argc, char **argv) {
  std::cout << "Running game from C++" << std::endl;
  py::scoped_interpreter guard{}; // start the interpreter and keep it alive
  GameRunner::GetInstance()->InitializeGraphicsSubSystem("/home/psx95/Projects/C++/CS-5850/finalproject-runtime-terror/Game/Pong/game_objects_config.json");
  GameRunner::GetInstance()->Start();
  GameRunner::GetInstance()->MainGameLoop();
  GameRunner::GetInstance()->Shutdown();
}