//
// Created by psx95 on 4/8/21.
//

#include <api/ResourceManager.hpp>
#include "api/SpriteComponent.hpp"
#include "api/GameObject.hpp"

SpriteComponent::SpriteComponent(GameObject *game_object,
                                 std::string &texture_res,
                                 int src_sprite_width,
                                 int src_sprite_height,
                                 int max_frames,
                                 int sprite_width,
                                 int sprite_height,
                                 int fps,
                                 int sprite_x_start,
                                 int sprite_y_start,
                                 int src_sprite_x_start,
                                 int src_sprite_y_start,
                                 bool src_bmp,
                                 bool sync_position_with_transform)
    : Component(game_object),
      m_xPos(sprite_x_start),
      m_yPos(sprite_y_start),
      sprite_target_fps(fps),
      max_frames(max_frames) {
  this->m_texture = src_bmp ? ResourceManager::GetInstance()->GetImageResourceBMP(texture_res)
                            : ResourceManager::GetInstance()->GetImageResourcePNG(texture_res);
  this->sync_position_with_transform = sync_position_with_transform;
  m_src.x = src_sprite_x_start;
  m_src.y = src_sprite_y_start;
  m_src.w = src_sprite_width;
  m_src.h = src_sprite_height;

  m_dest.x = m_xPos;
  m_dest.y = m_yPos;
  m_dest.w = sprite_width;
  m_dest.h = sprite_height;
}

// Set the sprite position
void SpriteComponent::SetPosition(int x, int y) {
  m_xPos = x;
  m_yPos = y;
}

void SpriteComponent::Render() {
  if (m_texture == nullptr) {
    SDL_Log("No Texture loaded\n");
  }
  m_dest.x = m_xPos;
  m_dest.y = m_yPos;
  SDL_RendererFlip flip = horizontal_flip ? SDL_FLIP_HORIZONTAL : SDL_FLIP_NONE;
  if (vertical_flip) {
    flip = static_cast<SDL_RendererFlip>(flip | SDL_FLIP_VERTICAL);
  }
  SDL_RenderCopyEx(ResourceManager::GetInstance()->GetEngineRenderer(), m_texture, &m_src, &m_dest, sprite_rotate_angle, nullptr, flip);
}

void SpriteComponent::Update(Event &event) {
  // no event based update
}

void SpriteComponent::ProcessUpdate(float delta_time) {
  if (this->game_object_transform == nullptr && sync_position_with_transform) {
    FindAttachedTransformComponent();
  }
  if (this->game_object_transform != nullptr) {
    m_xPos = game_object_transform->GetTransformPosition().x;
    m_yPos = game_object_transform->GetTransformPosition().y;
  }
  if (sprite_target_fps > 0) {
    m_src.x = static_cast<int>(current_frame) * m_src.w;
    UpdateSpriteFrame();
  }
}

ComponentType SpriteComponent::GetComponentType() {
  return SPRITE;
}

ComponentCardinality SpriteComponent::GetComponentCardinality() {
  return MULTIPLE;
}

void SpriteComponent::FindAttachedTransformComponent() {
  auto *transform_component =
      this->GetGameObject()->GetAttachedComponent<TransformComponent *>(ComponentType::TRANSFORM);
  if (transform_component != nullptr) {
    this->game_object_transform = transform_component;
  }
}

void SpriteComponent::Init() {
//  m_spriteSheet = SDL_LoadBMP(sprite_resource_path.c_str());
//  if (nullptr == m_spriteSheet) {
//    SDL_Log("Failed to allocate surface");
//  } else {
//    SDL_Log("Allocated a bunch of memory to create identical game character");
//  }
}

int SpriteComponent::GetSpriteWidth() const {
  return m_dest.w;
}

int SpriteComponent::GetSpriteHeight() const {
  return m_dest.h;
}

void SpriteComponent::UpdateSpriteFrame() {
  auto current_time = std::chrono::high_resolution_clock::now();
  float time_to_update = 1000.0f / static_cast<float>(sprite_target_fps);
  if (std::chrono::duration<float, std::chrono::milliseconds::period>(current_time - last_frame_update).count()
      > time_to_update) {
    current_frame++;
    if (current_frame > (max_frames - 1)) {
      current_frame = 0;
    }
    last_frame_update = current_time;
  }
}

void SpriteComponent::SetHorizontalFlip(bool flip) {
  this->horizontal_flip = flip;
}

void SpriteComponent::SetVerticalFlip(bool flip) {
  this->vertical_flip = flip;
}

unsigned int SpriteComponent::GetMaxFrames() const {
  return max_frames;
}

unsigned int SpriteComponent::GetCurrentFrame() const {
  return current_frame;
}

void SpriteComponent::SetSpriteRotateAngle(float _sprite_rotate_angle) {
  SpriteComponent::sprite_rotate_angle = _sprite_rotate_angle;
}

float SpriteComponent::GetSpriteRotateAngle() const {
  return sprite_rotate_angle;
}

bool SpriteComponent::IsHorizontalFlip() const {
  return horizontal_flip;
}

void SpriteComponent::SetSpriteTargetFps(int sprite_target_fps_) {
  SpriteComponent::sprite_target_fps = sprite_target_fps_;
}
