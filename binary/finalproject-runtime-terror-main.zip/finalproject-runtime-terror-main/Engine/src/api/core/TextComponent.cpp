//
// Created by psx95 on 4/13/21.
//

#include <api/ResourceManager.hpp>
#include <api/Rect2D.hpp>
#include <utility>
#include "api/TextComponent.hpp"

TextComponent::TextComponent(GameObject *game_object,
                             std::string &font_res_path,
                             int font_size,
                             GraphicsColor color,
                             Rect2D destination_rect) : Component(game_object) {
  LoadFontFromRes(font_res_path, font_size);
  SetDestinationRectangle(std::move(destination_rect));
  SetFontColor(color);
}

void TextComponent::Init() {
  InitSurface();
}

void TextComponent::Update(Event &event) {
}

void TextComponent::ProcessUpdate(float delta_time) {
  UpdateComponent();
}

void TextComponent::Render() {
  if (texture == nullptr) {
    InitTexture();
  }
  SDL_RenderCopy(ResourceManager::GetInstance()->GetEngineRenderer(), texture, nullptr, &text_boundary);
}

ComponentCardinality TextComponent::GetComponentCardinality() {
  return MULTIPLE;
}

ComponentType TextComponent::GetComponentType() {
  return TEXT;
}

TextComponent::~TextComponent() {
  FreeMemory();
}

//================================================================================
// Private Helpers
//================================================================================
void TextComponent::LoadFontFromRes(std::string &font_res, int font_size) {
  this->text_font = ResourceManager::GetInstance()->GetFontResource(font_res, font_size);
  if (text_font == nullptr) {
    std::cerr << "Unable to open font from " << font_res << std::endl;
    exit(1);
  }
}

void TextComponent::InitSurface() {
  surface = TTF_RenderText_Solid(text_font, text.c_str(), {text_color.r, text_color.g, text_color.b, text_color.a});
}

void TextComponent::InitTexture() {
  texture = SDL_CreateTextureFromSurface(ResourceManager::GetInstance()->GetEngineRenderer(), surface);
  // get the width and height of the texture
  SDL_QueryTexture(texture, nullptr, nullptr, &text_width, &text_height);
  text_boundary.x = dest.x + dest.w; // score should appear a little right to the image
  text_boundary.y = dest.y;
  text_boundary.w = text_width;
  text_boundary.h = text_height;
}

void TextComponent::FreeMemory() {
  if (surface != nullptr) {
    SDL_FreeSurface(surface);
    surface = nullptr;
  }
  if (texture != nullptr) {
    SDL_DestroyTexture(texture);
    texture = nullptr;
  }
  text_width = 0;
  text_height = 0;
}

void TextComponent::UpdateComponent() {
  FreeMemory();
  InitSurface();
}

void TextComponent::SetDestinationRectangle(Rect2D destination_rect) {
  this->dest.x = destination_rect.GetXPos();
  this->dest.y = destination_rect.GetYPos();
  this->dest.w = destination_rect.GetWidth();
  this->dest.h = destination_rect.GetHeight();
}

void TextComponent::SetFontColor(GraphicsColor graphics_color) {
  this->text_color.r = graphics_color.r;
  this->text_color.g = graphics_color.g;
  this->text_color.b = graphics_color.b;
  this->text_color.a = graphics_color.a;
}

void TextComponent::UpdateText(const std::string &updated_text) {
  this->text = updated_text;
}
