//
// Created by psx95 on 4/23/21.
//

#include <iostream>
#include "api/GlobalConfig.hpp"

GlobalConfig::GlobalConfig(const std::string &global_config_json) : global_config(nlohmann::json::parse(
    global_config_json).at("global-config")) {
  SetScreenDimensions();
  SetBackgroundImageRes();
  SetBackgroundColor();
  SetBackgroundMusicRes();
  SetCameraFollowObject();
  SetGravity();
}

const std::string &GlobalConfig::GetBackgroundImageRes() const {
  return background_image_res;
}

const std::string &GlobalConfig::GetBackgroundMusicRes() const {
  return background_music_res;
}

const std::string &GlobalConfig::GetCameraFollowsObject() const {
  return camera_follows_object;
}

const GraphicsColor &GlobalConfig::GetBackgroundColor() const {
  return background_color;
}

float GlobalConfig::GetGravity() const {
  return gravity;
}

int GlobalConfig::GetScreenWidth() const {
  return screen_width;
}
int GlobalConfig::GetScreenHeight() const {
  return screen_height;
}

//================================================================================
// Private Setters
//================================================================================
void GlobalConfig::SetBackgroundImageRes() {
  background_image_res = global_config.value("Background Image", "");
}

void GlobalConfig::SetBackgroundMusicRes() {
  background_music_res = global_config.value("Background Music", "");
}

void GlobalConfig::SetCameraFollowObject() {
  camera_follows_object = global_config.value("Camera Follows", "");
}

void GlobalConfig::SetBackgroundColor() {
  nlohmann::json color_object = global_config["Background Color"];
  auto color_red = std::stoi(color_object["r"].get<std::string>());
  auto color_green = std::stoi(color_object["g"].get<std::string>());
  auto color_blue = std::stoi(color_object["b"].get<std::string>());
  auto color_alpha = std::stoi(color_object["a"].get<std::string>());
  background_color =
      GraphicsColor{static_cast<Uint8>(color_red), static_cast<Uint8>(color_green), static_cast<Uint8>(color_blue),
                    static_cast<Uint8>(color_alpha)};
}

void GlobalConfig::SetGravity() {
  std::string _gravity = global_config.value("Gravity", "0.0");
  this->gravity = std::stof(_gravity);
}

void GlobalConfig::SetScreenDimensions() {
  nlohmann::json screen_dimension_object = global_config["Screen Dimensions"];
  this->screen_width = std::stoi(screen_dimension_object["screen-width"].get<std::string>());
  this->screen_height = std::stoi(screen_dimension_object["screen-height"].get<std::string>());
}

std::string GlobalConfig::ToString() const {
  return global_config.dump();
}
