//
// Created by psx95 on 4/8/21.
//

#include <fstream>
#include <iostream>
#include <SDL_image.h>
#include "api/ResourceManager.hpp"

ResourceManager *ResourceManager::instance = nullptr;

ResourceManager::ResourceManager() {
  textures_map = new std::map<std::string, SDL_Texture *>;
  resources_map = new std::map<std::string, SDL_Surface *>;
  sound_effects_map = new std::map<std::string, Mix_Chunk *>;
  music_map = new std::map<std::string, Mix_Music *>;
  font_map = new std::map<std::string, TTF_Font *>;
  level_map = new std::map<std::string, LevelData*>;
}

ResourceManager *ResourceManager::GetInstance() {
  if (instance == nullptr) {
    instance = new ResourceManager();
  }
  return instance;
}

void ResourceManager::Initialize(SDL_Renderer *renderer) {
  // Load all resources necessary for game
  SDL_Log("Initializing Resources");
  this->engine_renderer = renderer;
  // Loading Character Sprite
  /*std::string file_location_sprite_character = "./Assets/Platformer/Character/sprite.bmp";
  SDL_Surface *sprite_surface = SDL_LoadBMP(file_location_sprite_character.c_str());
  if (sprite_surface == nullptr) {
    std::cerr << "Unable to load SpriteSheet " << SDL_GetError() << std::endl;
    exit(1);
  } else {
    resources_map->insert(std::make_pair(file_location_sprite_character, sprite_surface));
  }
  // Loading Game Tiles
  std::string file_location_tile = "./Assets/Platformer/Tiles/tiles.bmp";
  SDL_Surface *tile_surface = SDL_LoadBMP(file_location_tile.c_str());
  if (tile_surface == nullptr) {
    std::cerr << "Unable to load Tiles " << SDL_GetError() << std::endl;
    exit(1);
  } else {
    resources_map->insert(std::make_pair(file_location_tile, tile_surface));
  }

  // Loading Default Tiles.bmp - for tile editor
  std::string file_location_tile_editor = "./Assets/Tiles/bmp/Tiles.bmp";
  SDL_Surface *tile_surface_editor = SDL_LoadBMP(file_location_tile_editor.c_str());
  if (tile_surface_editor == nullptr) {
    std::cerr << "Unable to load Tiles " << SDL_GetError() << std::endl;
    exit(1);
  } else {
    resources_map->insert(std::make_pair(file_location_tile_editor, tile_surface_editor));
  }*/
  // load audio resources
  /* SDL_Log("Initializing audio resource");
   std::string loop_music_location = "./Assets/beat.wav";
   Mix_Music *loop_music_bg = Mix_LoadMUS(loop_music_location.c_str());
   if (loop_music_bg == nullptr) {
     std::cerr << "Unable to load music file " << SDL_GetError() << std::endl;
     exit(1);
   } else {
     music_map->insert(std::make_pair(loop_music_location, loop_music_bg));
   }*/
}

SDL_Texture *ResourceManager::GetImageResourceBMP(const std::string &resource_id) {
  auto texture_position = textures_map->find(resource_id);
  if (texture_position == textures_map->end()) {
    auto resource_position = resources_map->find(resource_id);
    if (resource_position != resources_map->end()) {
      SDL_Texture *resource_texture = SDL_CreateTextureFromSurface(engine_renderer, resource_position->second);
      textures_map->insert(std::make_pair(resource_id, resource_texture));
      return resource_texture;
    } else {
      std::cout << "Resource not loaded, Loading..." << std::endl;
      SDL_Surface *sprite_surface = SDL_LoadBMP(resource_id.c_str());
      if (sprite_surface == nullptr) {
        std::cerr << "Unable to load SpriteSheet " << SDL_GetError() << std::endl;
        exit(1);
      } else {
        resources_map->insert(std::make_pair(resource_id, sprite_surface));
        SDL_Texture *resource_texture = SDL_CreateTextureFromSurface(engine_renderer, sprite_surface);
        textures_map->insert(std::make_pair(resource_id, resource_texture));
        return resource_texture;
      }
    }
  }
  return texture_position->second;
}

SDL_Texture *ResourceManager::GetImageResourcePNG(const std::string &resource_id) {
  auto texture_position = textures_map->find(resource_id);
  if (texture_position == textures_map->end()) {
    // png not loaded
    SDL_Texture *resource_texture = IMG_LoadTexture(engine_renderer, resource_id.c_str());
    if (resource_texture == nullptr) {
      std::cerr << "Resource not found " << SDL_GetError() << std::endl;
    } else {
      textures_map->insert(std::make_pair(resource_id, resource_texture));
    }
    return resource_texture;
  }
  return texture_position->second;
}

Mix_Chunk *ResourceManager::GetSoundEffectResource(const std::string &resource_id) {
  auto sound_effect_position = sound_effects_map->find(resource_id);
  if (sound_effect_position == sound_effects_map->end()) {
    // not loaded, load first
    Mix_Chunk *sound_effect = Mix_LoadWAV(resource_id.c_str());
    if (sound_effect == nullptr) {
      std::cerr << "Unable to locate resource " << std::endl;
      exit(1);
    } else {
      sound_effects_map->insert(std::make_pair(resource_id, sound_effect));
      return sound_effect;
    }
  }
  return sound_effect_position->second;
}

Mix_Music *ResourceManager::GetMusicResource(const std::string &resource_id) {
  auto music_position = music_map->find(resource_id);
  if (music_position == music_map->end()) {
    // not loaded, load first
    Mix_Music *music = Mix_LoadMUS(resource_id.c_str());
    if (music == nullptr) {
      std::cerr << "Unable to load resource " << std::endl;
      exit(1);
    } else {
      music_map->insert(std::make_pair(resource_id, music));
      return music;
    }
  }
  return music_position->second;
}

TTF_Font *ResourceManager::GetFontResource(const std::string &resource_id, int font_size) {
  std::string resource_map_id = resource_id + "_" + std::to_string(font_size);
  auto font_position = font_map->find(resource_map_id);
  if (font_position == font_map->end()) {
    TTF_Font *font = TTF_OpenFont(resource_id.c_str(), font_size);
    if (font == nullptr) {
      std::cerr << "Unable to open font  " << TTF_GetError << std::endl;
      exit(1);
    }
    font_map->insert(std::make_pair(resource_map_id, font));
    return font;
  }
  return font_position->second;
}

LevelData *ResourceManager::GetLevelMapResource(const std::string &resource_id, unsigned int row, unsigned int col) {
  auto level_map_position = level_map->find(resource_id);
  if (level_map_position == level_map->end()) {
    std::ifstream in(resource_id, std::ios::in);
    if (in.peek() == EOF) {
      std::cerr << "No such file" <<std::endl;
      return nullptr;
    }
    int *arr = new int [row * col];
    int cur;
    for (int y = 0; y < row; ++y) {
      for (int x = 0; x < col; ++x) {
        if (in.eof()) {
          delete [] arr;
          std::cerr << "Invalid file format" <<std::endl;
          return nullptr;
        }
        in >> cur;
        arr[y * col + x] = cur;
      }
    }
    in.close();
    auto* levelData = new LevelData(arr, static_cast<int>(row), static_cast<int>(col));
    level_map->insert(std::make_pair(resource_id, levelData));
    return levelData;
  }
  return level_map_position->second;
}


void ResourceManager::Shutdown() {
  // destroy the resources
  // free resources from resources map
  for (auto &entry : *resources_map) {
    if (entry.second != nullptr) {
      SDL_FreeSurface(entry.second);
      entry.second = nullptr;
    }
  }
  resources_map = nullptr;
  // destroy textures from textures map
  for (auto &entry: *textures_map) {
    if (entry.second != nullptr) {
      SDL_DestroyTexture(entry.second);
      entry.second = nullptr;
    }
  }
  textures_map = nullptr;

  // destroy music
  for (auto &entry: *music_map) {
    if (entry.second != nullptr) {
      Mix_FreeMusic(entry.second);
      entry.second = nullptr;
    }
  }
  music_map = nullptr;

  // destroy sound effects
  for (auto &entry: *sound_effects_map) {
    if (entry.second != nullptr) {
      Mix_FreeChunk(entry.second);
      entry.second = nullptr;
    }
  }
  sound_effects_map = nullptr;

  // destroy open fonts
  for (auto &entry: *font_map) {
    if (entry.second != nullptr) {
      TTF_CloseFont(entry.second);
      entry.second = nullptr;
    }
  }
  font_map = nullptr;

  // destroy level map
  for (auto &entry: *level_map) {
    if (entry.second != nullptr) {
      delete entry.second;
      entry.second = nullptr;
    }
  }
  level_map = nullptr;

  // set self instance to null;
  instance = nullptr;
}

SDL_Renderer *ResourceManager::GetEngineRenderer() const {
  return engine_renderer;
}
