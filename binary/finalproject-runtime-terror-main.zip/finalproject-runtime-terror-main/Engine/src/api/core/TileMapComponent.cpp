//
// Created by psx95 on 4/19/21.
//

#include <api/ResourceManager.hpp>
#include <algorithm>
#include <api/Camera2D.hpp>
#include "api/TileMapComponent.hpp"

TileMapComponent::TileMapComponent(GameObject *game_object,
                                   const std::string &texture_res,
                                   const std::string &tile_map_res,
                                   const std::string &camera_attached_object,
                                   const TileTypeDefiner *tile_type_definer,
                                   int rows,
                                   int cols,
                                   int tile_width,
                                   int tile_height,
                                   int dest_tile_width,
                                   int dest_tile_height,
                                   int _mapX,
                                   int _mapY) : Component(game_object), tile_type_definer(tile_type_definer) {
  number_rows = rows;
  number_columns = cols;
  m_TileWidth = tile_width;
  m_TileHeight = tile_height;
  this->dest_tile_width = dest_tile_width;
  this->dest_tile_height = dest_tile_height;
  m_MapX = _mapX;
  m_MapY = _mapY;
  m_tiles.resize(m_MapY, std::vector<TileData *>(m_MapX, nullptr));
  m_Texture = ResourceManager::GetInstance()->GetImageResourceBMP(texture_res);
  SetupLevelData(tile_map_res, camera_attached_object);
}

void TileMapComponent::Update(Event &event) {
  // no manual updates needed
}

void TileMapComponent::ProcessUpdate(float delta_time) {
  // re-compute the visible tiles
  std::vector<TileData *> updated_tiles;
  SDL_Rect Src, Dest;
  SDL_Rect tiles_on_screen;
  tiles_on_screen.x =
      Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetWidth() / dest_tile_width + 2 : m_MapX;
  tiles_on_screen.y =
      Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetHeight() / dest_tile_height + 2
                                : m_MapY;

  int start_x = Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetXPos() / dest_tile_width : 0;
  int start_y = Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetYPos() / dest_tile_height : 0;

  for (int y = start_y; y < start_y + tiles_on_screen.y; y++) {
    for (int x = start_x; x < start_x + tiles_on_screen.x; x++) {
      if ((x < m_MapX) && (x > -1) && (y < m_MapY) && (y > -1)) {
        // Select our Tile
//        int currentTile = GetTileType(x, y);
        int currentTile = levelData->GetTileType(x, y);
        Position tile_position{};
        if (currentTile > 0) {
          tile_position = tile_type_definer->GetTilePos(currentTile, m_TileWidth, m_TileHeight);
          // Reverse lookup, given the tile type
          // and then figuring out how to select it
          // from the texture atlas.
          Src.x = tile_position.x;
          Src.y = tile_position.y;
          Src.w = m_TileWidth;
          Src.h = m_TileHeight;
          Dest.x = x * dest_tile_width
              - (Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetXPos() : 0);
          Dest.y = y * dest_tile_height
              - (Camera2D::IsInitialized() ? Camera2D::GetInstance()->GetCameraBounds().GetYPos() : 0);
          Dest.w = dest_tile_width;
          Dest.h = dest_tile_height;
          // updated_tiles.emplace_back(TileData(std::to_string(x).append("_").append(std::to_string(y)), Dest, Src));
          m_tiles[y][x]->SetSrcTileRect(Src);
          m_tiles[y][x]->SetDestTileRect(Dest);
          updated_tiles.emplace_back(m_tiles[y][x]);
        }
      }
    }
  }
  visible_tiles.swap(updated_tiles); // constant time op will only process collisions with visible tiles
}

void TileMapComponent::Render() {
  std::for_each(visible_tiles.begin(), visible_tiles.end(), [this](TileData *tile_data) {
    SDL_RenderCopy(ResourceManager::GetInstance()->GetEngineRenderer(),
                   m_Texture,
                   &tile_data->GetSrcTileRect(),
                   &tile_data->GetDestTileRect());
  });
}

ComponentCardinality TileMapComponent::GetComponentCardinality() {
  return SINGLE;
}

ComponentType TileMapComponent::GetComponentType() {
  return TILE_MAP;
}

const std::vector<TileData *> &TileMapComponent::GetVisibleTiles() const {
  return visible_tiles;
}

TileMapComponent::~TileMapComponent() {
  for (int i = 0; i < m_MapY; ++i) {
    for (int j = 0; j < m_MapX; ++j) {
      if (m_tiles[i][j] != nullptr) {
        delete m_tiles[i][j];
      }
    }
  }
}

//================================================================================
// Private Helpers
//================================================================================
void TileMapComponent::SetupLevelData(const std::string &level_map_res, const std::string &camera_object_id) {
  // Setup the TileMapComponent array
  // This sets each tile to '0'
  m_Tiles = new int[m_MapX * m_MapY];
  for (int i = 0; i < m_MapX * m_MapY; i++) {
    m_Tiles[i] = -1; // Default value is no tile.
  }
  levelData = ResourceManager::GetInstance()->GetLevelMapResource(level_map_res, m_MapY, m_MapX);
  levelData->PrintMap();

  for (int i = 0; i < m_MapY; ++i) {
    for (int j = 0; j < m_MapX; ++j) {
      if (levelData->GetTileType(j, i) > 0) {
        m_tiles[i][j] = new TileData("tilemap_" + std::to_string(i) + "_" + std::to_string(j),
                                     SDL_Rect{j * dest_tile_width, i * dest_tile_height, dest_tile_width, dest_tile_height});
        m_Tiles[i * m_MapX + j] = levelData->GetTileType(j, i);
      }
    }
  }
}

std::vector<int> TileMapComponent::GetMTiles() const {
  std::vector<int> v(m_MapX * m_MapY);
  for (int i = 0; i < m_MapX * m_MapY; i++) {
    v[i] = m_Tiles[i];;
  }
  return v;
}
