//
// Created by psx95 on 4/19/21.
//

#include "api/TileData.hpp"

TileData::TileData(const std::string &object_id, SDL_Rect dest_rect)
    : GameObject(object_id) {
  PhysicsBodyConfig tile_config;
  tile_config.type = PHYSICS_BODY_STATIC;
  tile_config.pos_x = static_cast<float>(dest_rect.x);
  tile_config.pos_y = static_cast<float>(dest_rect.y);
  tile_config.width = static_cast<float>(dest_rect.w);
  tile_config.height = static_cast<float>(dest_rect.h);
  tile_config.SetShapeAsBox(static_cast<float>(dest_rect.w), static_cast<float>(dest_rect.h));
  physics_component = new PhysicsComponent(this, &tile_config);
}

void TileData::Init() {
  AddComponent(physics_component);
}

void TileData::SetDestTileRect(SDL_Rect &dest) {
  dest_tile_rect = dest;
}

void TileData::SetSrcTileRect(SDL_Rect &src) {
  src_tile_rect = src;
}

const SDL_Rect &TileData::GetDestTileRect() const {
  return dest_tile_rect;
}

const SDL_Rect &TileData::GetSrcTileRect() const {
  return src_tile_rect;
}
