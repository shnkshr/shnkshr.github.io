#include "api/TileMapObject.hpp"

TileMapObject::TileMapObject(std::string &object_id,
                             const std::string &texture_res,
                             const std::string &tile_map_res,
                             const std::string &camera_attached_object,
                             const TileTypeDefiner *tile_type_definer,
                             int rows,
                             int cols,
                             int tile_width,
                             int tile_height,
                             int dest_tile_width,
                             int dest_tile_height,
                             int _mapX,
                             int _mapY) : GameObject(object_id) {
  this->tile_map_component = new TileMapComponent(this,
                                                  texture_res,
                                                  tile_map_res,
                                                  camera_attached_object,
                                                  tile_type_definer,
                                                  rows,
                                                  cols,
                                                  tile_width,
                                                  tile_height,
                                                  dest_tile_width,
                                                  dest_tile_height,
                                                  _mapX,
                                                  _mapY);
}

TileMapObject::~TileMapObject() = default;

void TileMapObject::Init() {
  AddComponent(tile_map_component);
}

std::vector<int> TileMapObject::GetTileMapLayout() const {
  if (this->tile_map_component != nullptr) {
    return this->tile_map_component->GetMTiles();
  } else {
    std::cerr << "Tile Map layout in TileMapComponent is null " << std::endl;
    return {};
  }
}

