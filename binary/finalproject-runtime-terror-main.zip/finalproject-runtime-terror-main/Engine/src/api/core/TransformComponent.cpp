//
// Created by psx95 on 4/8/21.
//

#include <iostream>
#include "api/TransformComponent.hpp"

TransformComponent::TransformComponent(GameObject *game_object,
                                       Position position, int x_margin, int y_margin) : Component(game_object) {
  this->position = position;
  this->visual_position = position;
  this->x_boundary_margin = x_margin;
  this->y_boundary_margin = y_margin;
}

void TransformComponent::ProcessUpdate(float delta_time) {
  if(disabled) {
    return;
  }
}

void TransformComponent::Update(Event &event) {
  // no updates based on user events
}

void TransformComponent::Render() {
  // empty -> cannot render a Transform component
}

ComponentType TransformComponent::GetComponentType() {
  return ComponentType::TRANSFORM;
}

ComponentCardinality TransformComponent::GetComponentCardinality() {
  return ComponentCardinality::SINGLE;
}

Position &TransformComponent::GetTransformPosition() {
  return position;
}

Position &TransformComponent::GetVisualPosition() {
  return visual_position;
}

void TransformComponent::UpdateVisualPosition(int x, int y) {
  if (disabled) {
    return;
  }
  this->visual_position.x = x;
  this->visual_position.y = y;
}

void TransformComponent::UpdateTransformPosition(int x, int y) {
  if(disabled) {
    return;
  }
  this->position.x = x;
  this->position.y = y;
}
