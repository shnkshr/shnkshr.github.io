//
// Created by psx95 on 4/8/21.
//

#include "api/Rect2D.hpp"
Rect2D::Rect2D(int x, int y, int w, int h) {
  rect.x = x;
  rect.y = y;
  rect.w = w;
  rect.h = h;
}

int Rect2D::GetXPos() {
  return rect.x;
}

int Rect2D::GetYPos() {
  return rect.y;
}

int Rect2D::GetWidth() {
  return rect.w;
}

int Rect2D::GetHeight() {
  return rect.h;
}
