//
// Created by psx95 on 4/8/21.
//

#include <InternalGraphicsEngineRenderer.hpp>
#include <api/ResourceManager.hpp>
#include <iostream>
#include <chrono>
#include <api/PhysicsManager.hpp>
#include <json.hpp>
#include <fstream>
#include <set>
#include <api/ObjectConfig.hpp>
#include <api/Camera2D.hpp>
#include "GameRunner.hpp"
#include "pybind11/pybind11.h"
#include "pybind11/pytypes.h"

GameRunner *GameRunner::instance = nullptr;

GameRunner *GameRunner::GetInstance() {
  if (instance == nullptr) {
    instance = new GameRunner();
  }
  return instance;
}

void GameRunner::InitializeGraphicsSubSystem(const std::string &object_config_path) {
  std::cout << object_config_path << " received " << std::endl;
  this->object_config_content = GetConfigFileContent(const_cast<std::string &>(object_config_path));
  std::cout << this->object_config_content << std::endl;
  this->global_config = new GlobalConfig(this->object_config_content);
  this->graphics_subsystem =
      new InternalGraphicsEngineRenderer(global_config->GetScreenWidth(), global_config->GetScreenHeight());
  if (graphics_subsystem->GetRenderer() == nullptr) {
    std::cerr << "Unable to initialize Graphics Subsystem, renderer is null " << std::endl;
  }
  InternalGraphicsEngineRenderer::EnableVSync();
  ResourceManager::GetInstance()->Initialize(graphics_subsystem->GetRenderer());
  PhysicsManager::GetInstance()->Initialize(this->global_config->GetGravity());
  quit = false;
  pause = false;
  callOnPause = false;
  callOnResume = false;
}

void GameRunner::PreparePythonGameObjectsFromConfig() {
  nlohmann::json object_config = nlohmann::json::parse(this->object_config_content);
  for (auto it = object_config.begin(); it != object_config.end(); ++it) {
    const std::string &game_object_id = it.key();
    if (game_object_id != "global-config") {
      ObjectConfig game_object_config(game_object_id, this->object_config_content);
      py::module_ required_module = py::module_::import(game_object_config.GetModuleName().data());
      py::object python_game_object = required_module.attr(game_object_config.GetClassName().c_str())(
          game_object_id,
          game_object_config);
      python_game_objects.insert(std::make_pair(game_object_id, python_game_object));
    }
  }
}

void GameRunner::AddGameObjectFromScript(const std::string &object_id,
                                         const std::string &module_name,
                                         const std::string &class_name,
                                         const ObjectConfig &config) {
  py::module_ required_module = py::module_::import(module_name.c_str());
  py::object python_game_object = required_module.attr(class_name.c_str())(object_id, config);
  python_game_objects.insert(std::make_pair(object_id, python_game_object));
}

void GameRunner::Start() {
  InternalGraphicsEngineRenderer::ToggleUserInputAccept(true); // start input
  PreparePythonGameObjectsFromConfig();
  // start playing background music, if necessary
  // TODO: This code needs to be such that the libraries need not be re-built with every change
  // TODO: Setup Game Objects
  InitGameObjects();
  if (!global_config->GetCameraFollowsObject().empty()) {
    Camera2D::GetInstance()->InitializeCamera(global_config->GetCameraFollowsObject());
  }
}

void GameRunner::InitGameObjects() {
  for (auto &python_game_object : python_game_objects) {
    python_game_object.second.attr("Init")();
  }
}

void GameRunner::Input(bool *app_quit) {
  Event user_event{};
  while (graphics_subsystem->PollUserEvents(&user_event)) {
    if (user_event.GetEventType() == Event::APP_QUIT) {
      std::cout << "quit " << std::endl;
      *app_quit = true;
    } else {
      for (auto &python_game_object : python_game_objects) {
        python_game_object.second.attr("UpdateFromEvent")(user_event);
      }
    }
  }
}

void GameRunner::Update(float dt) {
  if (this->pause) {
    if (callOnPause) {
      for (auto &python_game_object : python_game_objects) {
        python_game_object.second.attr("OnPause")();
      }
      callOnPause = false;
    }
    return;
  }
  if (callOnResume) {
    for (auto &python_game_object : python_game_objects) {
      python_game_object.second.attr("OnResume")();
    }
    callOnResume = false;
  }
  for (auto &python_game_object : python_game_objects) {
    python_game_object.second.attr("Update")(dt);
  }
  PhysicsManager::GetInstance()->Update(dt / 1000);
  RemoveObjectsMarkedForDeletion();
}

void GameRunner::Render() {
  // Set the color of the empty framebuffer
  graphics_subsystem->SetRenderDrawColor(global_config->GetBackgroundColor().r,
                                         global_config->GetBackgroundColor().g,
                                         global_config->GetBackgroundColor().b,
                                         global_config->GetBackgroundColor().a);
  // Clear the screen to the color of the empty framebuffer
  graphics_subsystem->RenderClear();

  // TODO: Render game objects
  for (auto &python_game_object : python_game_objects) {
    python_game_object.second.attr("Render")();
  }

  // Flip the buffer to render
  graphics_subsystem->RenderPresent();
}

void GameRunner::MainGameLoop() {
  // v sync enabled, no need for frame capping, right now
  // TODO: Add frame capping
  float dt = 0.0f;
  if (Mix_PlayingMusic() == 0 && !global_config->GetBackgroundMusicRes().empty()) {
    Mix_PlayMusic(ResourceManager::GetInstance()->GetMusicResource(global_config->GetBackgroundMusicRes()), -1);
  }
  while (!quit) {
    auto frame_start_time = std::chrono::high_resolution_clock::now();
    // Get user input
    Input(&quit);
    // If you have time, implement your frame capping code here
    // Otherwise, this is a cheap hack for this lab.
    // Update our scene
    Update(dt);
    // Render using OpenGL
    Render();
    auto frame_stop_time = std::chrono::high_resolution_clock::now();
    dt = std::chrono::duration<float, std::chrono::milliseconds::period>(frame_stop_time - frame_start_time).count();
  }
  if (Mix_PlayingMusic() != 0) {
    Mix_HaltMusic();
  }
  std::cout << "Loop Quit" << std::endl;
  quit = false;
}

void GameRunner::Shutdown() {
  InternalGraphicsEngineRenderer::ToggleUserInputAccept(false);
  python_game_objects.clear();
  Camera2D::GetInstance()->DestroyCamera();
  PhysicsManager::GetInstance()->Shutdown();
  ResourceManager::GetInstance()->Shutdown();
  graphics_subsystem->ShutdownInternalGraphicsRenderer();
  delete global_config;
  instance = nullptr;
  delete graphics_subsystem;
}

GameRunner::~GameRunner() {
  delete graphics_subsystem;
}

std::string GameRunner::GetConfigFileContent(std::string &file_path) {
  std::ifstream i(file_path);
  nlohmann::json j;
  i >> j;
  return j.dump();
}

py::object *GameRunner::FindGameObject(const std::string &object_id) {
  auto game_object_position = python_game_objects.find(object_id);
  if (game_object_position == python_game_objects.end()) {
    return nullptr;
  }
  return &game_object_position->second;
}

void GameRunner::ConveyCollisionStartEvent(const std::string &object_collided_id,
                                           const std::string &object_collided_with) {
  py::object *collided_object = FindGameObject(object_collided_id);
  if (collided_object != nullptr) {
    collided_object->attr("ProcessCollisionStart")(object_collided_with);
  } else {
    std::cerr << "Could not find the colliding object in list of python objects present in Game " << std::endl;
  }
}

void GameRunner::ConveyCollisionEndEvent(const std::string &object_collided_id,
                                         const std::string &object_collided_with) {
  py::object *collided_object = FindGameObject(object_collided_id);
  if (collided_object != nullptr) {
    collided_object->attr("ProcessCollisionEnd")(object_collided_with);
  } else {
    std::cerr << "Could not find the colliding object in list of python objects present in Game " << std::endl;
  }
}

void GameRunner::RemoveObjectsMarkedForDeletion() {
  // there is probably a better way in A2 for this
  // using this for now since runtime complexity is essentially same and this seems safer
  std::set<std::string> objects_to_delete;
  for (auto &python_game_object : python_game_objects) {
    if (python_game_object.second.attr("IsDeleted")().cast<bool>()) {
      std::cout << "Found object marked for deletion " << python_game_object.first << std::endl;
      objects_to_delete.insert(python_game_object.first);
    }
  }
  for (auto &object_id : objects_to_delete) {
    python_game_objects.erase(object_id);
  }
}

void GameRunner::PauseGame(bool pause_) {
  if (this->pause != pause_) {
    // current state being changed
    this->pause = pause_;
    callOnPause = this->pause;
    callOnResume = !this->pause;
  }
}

bool GameRunner::IsPause() const {
  return this->pause;
}
