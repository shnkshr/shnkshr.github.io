//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_COREMODULEPYTHONNBINDINS_CPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_COREMODULEPYTHONNBINDINS_CPP_

// Include the pybindings
#include <api/CoreStructs.hpp>
#include <api/Rect2D.hpp>
#include <api/GameObject.hpp>
#include <api/SpriteComponent.hpp>
#include <api/Vector2D.hpp>
#include "pybind11/pybind11.h"
#include <pybind11/operators.h>
#include <pybind11/stl.h>
#include <GameRunner.hpp>
#include <api/TextComponent.hpp>
#include <api/ObjectConfig.hpp>
#include <api/TileMapObject.hpp>
#include <api/TileTypeDefiner.hpp>
#include <api/LevelData.hpp>
namespace py = pybind11;

void init_physics(py::module &);
void init_input(py::module &);
void init_sound(py::module &);

class PyTileTypeDefiner : TileTypeDefiner {
  using TileTypeDefiner::TileTypeDefiner;
  Position GetTilePos(int tile_number, int tile_width, int tile_height) const override {
    PYBIND11_OVERRIDE_PURE_NAME(
        Position,
        TileTypeDefiner,
        "GetTilePos",
        GetTilePos,
        tile_number,
        tile_width,
        tile_height
    );
  }
};

PYBIND11_MODULE(terror_core, core_lib) {
  core_lib.doc() = "The core APIs for the Terror Engine";

  //================================================================================
  // Bindings for GraphicsColor class
  //================================================================================
  py::class_<GraphicsColor>(core_lib, "GraphicsColor")
      .def(py::init())
      .def_readwrite("r", &GraphicsColor::r)
      .def_readwrite("g", &GraphicsColor::g)
      .def_readwrite("b", &GraphicsColor::b)
      .def_readwrite("a", &GraphicsColor::a);

  //================================================================================
  // Bindings for Positions class
  //================================================================================
  py::class_<Position>(core_lib, "Position")
      .def(py::init())
      .def_readwrite("x", &Position::x)
      .def_readwrite("y", &Position::y);

  //================================================================================
  // Bindings for Rect2D class
  //================================================================================
  py::class_<Rect2D>(core_lib, "Rect2D")
      .def(py::init<int, int, int, int>(),
           py::arg("x"),
           py::arg("y"),
           py::arg("w"),
           py::arg("h"))
      .def("GetXPos", &Rect2D::GetXPos)
      .def("GetYPos", &Rect2D::GetYPos)
      .def("GetWidth", &Rect2D::GetWidth)
      .def("GetHeight", &Rect2D::GetHeight);

  //================================================================================
  // Bindings for GameObject class
  //================================================================================
  py::class_<GameObject>(core_lib, "GameObject")
      .def(py::init<std::string>(), py::arg("object_id"))
      .def("Init", &GameObject::Init)
      .def("UpdateFromEvent", &GameObject::UpdateFromEvent, py::arg("event"))
      .def("Update", &GameObject::Update, py::arg("delta_time"))
      .def("Render", &GameObject::Render)
      .def("AddComponent", &GameObject::AddComponent, py::arg("component"))
      .def("MarkObjectForDestruction", &GameObject::MarkObjectForDestruction)
      .def("OnPause", &GameObject::OnPause)
      .def("OnResume", &GameObject::OnResume)
      .def("ProcessCollisionStart", &GameObject::ProcessCollisionStart, py::arg("collided_with_id"))
      .def("ProcessCollisionEnd", &GameObject::ProcessCollisionEnd, py::arg("collided_with_id"))
      .def("GetObjectId", &GameObject::GetObjectId)
      .def("IsDeleted", &GameObject::IsDeleted);

  //================================================================================
  // Bindings for Component class
  //================================================================================
  py::class_<Component>(core_lib, "Component")
      .def(py::init<GameObject *>());

  //================================================================================
  // Bindings for SpriteComponent class
  //================================================================================
  py::class_<SpriteComponent, Component>(core_lib, "SpriteComponent")
      .def(py::init<GameObject *, std::string &, int, int, int, int, int, int, int, int, int, int, bool, bool>(),
           py::arg("game_object"),
           py::arg("texture_res"),
           py::arg("src_sprite_width"),
           py::arg("src_sprite_height"),
           py::arg("max_frames"),
           py::arg("sprite_width"),
           py::arg("sprite_height"),
           py::arg("fps") = 30,
           py::arg("sprite_x_start") = 0,
           py::arg("sprite_y_start") = 0,
           py::arg("src_sprite_x_start") = 0,
           py::arg("src_sprite_y_start") = 0,
           py::arg("src_bmp") = false,
           py::arg("sync_position_with_transform") = true)
      .def("SetHorizontalFlip", &SpriteComponent::SetHorizontalFlip, py::arg("flip"))
      .def("IsHorizontalFlip", &SpriteComponent::IsHorizontalFlip)
      .def("SetVerticalFlip", &SpriteComponent::SetVerticalFlip, py::arg("flip"))
      .def("SetSpriteRotateAngle", &SpriteComponent::SetSpriteRotateAngle, py::arg("rotate_angle"))
      .def("SetSpriteTargetFps", &SpriteComponent::SetSpriteTargetFps, py::arg("sprite_target_fps"))
      .def("GetSpriteRotateAngle", &SpriteComponent::GetSpriteRotateAngle);

  //================================================================================
  // Bindings for TransformComponent class
  //================================================================================
  py::class_<TransformComponent, Component>(core_lib, "TransformComponent")
      .def(py::init<GameObject *, Position, int, int>(),
           py::arg("game_object"),
           py::arg("position"),
           py::arg("x_margin"),
           py::arg("y_margin"))
      .def("GetTransformPosition", &TransformComponent::GetTransformPosition)
      .def("UpdateTransformPosition", &TransformComponent::UpdateTransformPosition, py::arg("x"), py::arg("y"));

  //================================================================================
  // Bindings for TextComponent class
  //================================================================================
  py::class_<TextComponent, Component>(core_lib, "TextComponent")
      .def(py::init<GameObject *, std::string &, int, GraphicsColor, Rect2D>(),
           py::arg("game_object"),
           py::arg("font_res_path"),
           py::arg("font_size"),
           py::arg("color"),
           py::arg("destination_rect"))
      .def("UpdateText", &TextComponent::UpdateText, py::arg("updated_text"));

  //================================================================================
  // Bindings for ComponentType enum
  //================================================================================
  py::enum_<ComponentType>(core_lib, "ComponentType")
      .value("TRANSFORM", ComponentType::TRANSFORM)
      .value("SPRITE", ComponentType::SPRITE)
      .value("INPUT", ComponentType::INPUT)
      .export_values();

  //================================================================================
  // Bindings for ComponentCardinality enum
  //================================================================================
  py::enum_<ComponentCardinality>(core_lib, "ComponentCardinality")
      .value("SINGLE", ComponentCardinality::SINGLE)
      .value("MULTIPLE", ComponentCardinality::MULTIPLE)
      .export_values();

  //================================================================================
  // Bindings for Vector2D class
  //================================================================================
  py::class_<Vector2D>(core_lib, "Vector2D")
      .def(py::init<float, float>())
      .def(py::init<int, int>())
      .def_readwrite("x", &Vector2D::x)
      .def_readwrite("y", &Vector2D::y)
      .def(py::self += py::self)
      .def(py::self + py::self)
      .def(py::self * float());

  //================================================================================
  // Bindings for GameRunner class
  //================================================================================
  py::class_<GameRunner>(core_lib, "GameRunner")
      .def_static("GetInstance", &GameRunner::GetInstance, py::return_value_policy::reference)
      .def("InitializeGraphicsSubSystem", &GameRunner::InitializeGraphicsSubSystem, py::arg("object_config_path"))
      .def("FindGameObject", &GameRunner::FindGameObject, py::return_value_policy::reference)
      .def("Start", &GameRunner::Start)
      .def("MainGameLoop", &GameRunner::MainGameLoop)
      .def("PauseGame", &GameRunner::PauseGame, py::arg("pause_game"))
      .def("IsPause", &GameRunner::IsPause)
      .def("AddGameObjectFromScript",
           &GameRunner::AddGameObjectFromScript,
           py::arg("object_id"),
           py::arg("module_name"),
           py::arg("class_name"),
           py::arg("object_config"))
      .def("Shutdown", &GameRunner::Shutdown);

  //================================================================================
  // Bindings for BasicShapes class
  //================================================================================
  py::class_<BasicShapes>(core_lib, "BasicShapes")
      .def_static("RenderRectangle",
                  &BasicShapes::RenderRectangle,
                  py::arg("x"),
                  py::arg("y"),
                  py::arg("w"),
                  py::arg("h"),
                  py::arg("color"))
      .def_static("RenderPoint", &BasicShapes::RenderPoint, py::arg("x"), py::arg("y"), py::arg("color"))
      .def_static("RenderCircle",
                  &BasicShapes::RenderCircle,
                  py::arg("radius"),
                  py::arg("cx"),
                  py::arg("cy"),
                  py::arg("color"));

  //================================================================================
  // Bindings for ObjectConfig class
  py::class_<ObjectConfig>(core_lib, "ObjectConfig")
      .def(py::init<std::string, std::string>())
      .def(py::init<>())
      .def("GetPosition", &ObjectConfig::GetPosition, py::arg("key"))
      .def("SetPosition", &ObjectConfig::SetPosition, py::arg("key"), py::arg("position"))
      .def("GetVector", &ObjectConfig::GetVector, py::arg("key"))
      .def("SetVector", &ObjectConfig::SetVector, py::arg("key"), py::arg("vector_2d"))
      .def("GetColor", &ObjectConfig::GetColor, py::arg("key"))
      .def("SetColor", &ObjectConfig::SetColor, py::arg("key"), py::arg("color"))
      .def("GetRect", &ObjectConfig::GetRect, py::arg("key"))
      .def("SetRect", &ObjectConfig::SetRect, py::arg("key"), py::arg("rect_2d"))
      .def("GetInt", &ObjectConfig::GetInt, py::arg("key"))
      .def("SetInt", &ObjectConfig::SetInt, py::arg("key"), py::arg("value"))
      .def("GetFloat", &ObjectConfig::GetFloat, py::arg("key"))
      .def("SetFloat", &ObjectConfig::SetFloat, py::arg("key"), py::arg("value"))
      .def("GetDouble", &ObjectConfig::GetDouble, py::arg("key"))
      .def("SetDouble", &ObjectConfig::SetDouble, py::arg("key"), py::arg("value"))
      .def("GetString", &ObjectConfig::GetString, py::arg("key"))
      .def("SetString", &ObjectConfig::SetString, py::arg("key"), py::arg("value"))
      .def("GetBoolean", &ObjectConfig::GetBoolean, py::arg("key"))
      .def("SetBoolean", &ObjectConfig::SetBoolean, py::arg("key"), py::arg("value"));
  //================================================================================

  //================================================================================
  // Bindings for TileTypeDefiner interface
  //================================================================================
  py::class_<TileTypeDefiner, PyTileTypeDefiner>(core_lib, "TileTypeDefiner")
      .def(py::init<>())
      .def("GetTilePos",
           &TileTypeDefiner::GetTilePos,
           py::arg("tile_number"),
           py::arg("tile_width"),
           py::arg("tile_height"));

  //================================================================================
  // Bindings for TileMapObject class
  //================================================================================
  py::class_<TileMapObject>(core_lib, "TileMapObject")
      .def(py::init<std::string &,
                    const std::string &,
                    const std::string &,
                    const std::string &,
                    const TileTypeDefiner *,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int,
                    int>(),
           py::arg("object_id"),
           py::arg("texture_res"),
           py::arg("tile_map_res"),
           py::arg("camera_attached_object"),
           py::arg("tile_type_definer"),
           py::arg("rows"), py::arg("cols"),
           py::arg("tile_width"),
           py::arg("tile_height"),
           py::arg("dest_tile_width"),
           py::arg("dest_tile_height"),
           py::arg("_mapX"),
           py::arg("_mapY"))
      .def("Init", &TileMapObject::Init)
      .def("UpdateFromEvent", &TileMapObject::UpdateFromEvent)
      .def("Update", &TileMapObject::Update, py::arg("delta_time"))
      .def("IsDeleted", &TileMapObject::IsDeleted)
      .def("Render", &TileMapObject::Render)
      .def("OnPause", &TileMapObject::OnPause)
      .def("OnResume", &TileMapObject::OnResume)
      .def("GetTileMapLayout", &TileMapObject::GetTileMapLayout);

  init_physics(core_lib);
  init_input(core_lib);
  init_sound(core_lib);
};

#endif