//
// Created by psx95 on 4/16/21.
//

#include <GlobalConstants.hpp>
#include <GameRunner.hpp>
#include "api/Camera2D.hpp"

Camera2D *Camera2D::instance = nullptr;

Camera2D *Camera2D::GetInstance() {
  if (instance == nullptr) {
    instance = new Camera2D();
  }
  return instance;
}

void Camera2D::InitializeCamera(const std::string &game_object_to_follow_id) {
  this->object_to_follow =
      reinterpret_cast<GameObject *>(GameRunner::GetInstance()->FindGameObject(game_object_to_follow_id));
  this->camera = {0, 0, SCREEN_WIDTH, SCREEN_HEIGHT};
}

void Camera2D::UpdateCameraPerFrame() {
  if (attached_transform == nullptr) {
    FindAttachedTransform();
  }
  if (attached_transform != nullptr) {
    Position pos = attached_transform->GetTransformPosition();
    camera.x = pos.x - SCREEN_WIDTH / 2;
    camera.y = pos.y - SCREEN_HEIGHT / 2;

    //Keep the camera in bounds
    if (camera.x < 0) {
      camera.x = 0;
    }
    if (camera.y < 0) {
      camera.y = 0;
    }
    if (camera.x > WORLD_WIDTH - camera.w) {
      camera.x = WORLD_WIDTH - camera.w;
    }
    if (camera.y > WORLD_HEIGHT - camera.h) {
      camera.y = WORLD_HEIGHT - camera.h;
    }
    attached_transform->UpdateVisualPosition(pos.x - camera.x, pos.y - camera.y);
  }
}

void Camera2D::FindAttachedTransform() {
  auto *transform_component =
      this->object_to_follow->GetAttachedComponent<TransformComponent *>(ComponentType::TRANSFORM);
  if (transform_component != nullptr) {
    attached_transform = transform_component;
  } else {
    std::cerr << "The GameObject Camera is following does not have a TransformComponent attached to it." << std::endl;
  }
}

Rect2D Camera2D::GetCameraBounds() const {
  Rect2D rect2d{camera.x, camera.y, camera.w, camera.h};
  return rect2d;
}

void Camera2D::UpdateCameraPosition(int x, int y) {
  camera.x = x;
  camera.y = y;
}

void Camera2D::UpdateOffset(Position *position) const {
  if (position == nullptr) {
    return;
  }
  position->x -= camera.x;
  position->y -= camera.y;
}

void Camera2D::DestroyCamera() {
  if (IsInitialized()) {
    this->object_to_follow = nullptr;
    Camera2D::instance = nullptr;
  }
}

bool Camera2D::IsInitialized() {
  return instance != nullptr;
}
