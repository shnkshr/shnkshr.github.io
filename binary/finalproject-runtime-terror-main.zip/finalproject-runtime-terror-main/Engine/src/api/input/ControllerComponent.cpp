//
// Created by psx95 on 4/8/21.
//

#include "api/ControllerComponent.hpp"

ControllerComponent::ControllerComponent(GameObject *game_object, float x_velocity, float y_velocity)
    : Component(game_object), x_velocity(x_velocity), y_velocity(y_velocity) {
}

void ControllerComponent::ProcessUpdate(float delta_time) {
  if (disabled) {
    return;
  }
  // no processing required
}

void ControllerComponent::Render() {
  // cannot render Input component
}

void ControllerComponent::Update(Event &event) {
  if (disabled) {
    return;
  }
  if (event.GetEventType() == Event::KEY_PRESS) {
    UpdateMovement(event, true);
  } else if (event.GetEventType() == Event::KEY_RELEASE) {
    UpdateMovement(event, false);
  }
}

ComponentCardinality ControllerComponent::GetComponentCardinality() {
  return ComponentCardinality::SINGLE;
}

ComponentType ControllerComponent::GetComponentType() {
  return ComponentType::INPUT;
}

void ControllerComponent::UpdateMovement(Event &event, bool keydown) {
  if (event.GetKeyEvent() == Event::KEY_A || event.GetKeyEvent() == Event::KEY_LEFT) {
    move_left = keydown;
  }
  if (event.GetKeyEvent() == Event::KEY_D || event.GetKeyEvent() == Event::KEY_RIGHT) {
    move_right = keydown;
  }
  if (event.GetKeyEvent() == Event::KEY_UP || event.GetKeyEvent() == Event::KEY_SPACE
      || event.GetKeyEvent() == Event::KEY_W) {
    move_up = keydown;
  }
  if (event.GetKeyEvent() == Event::KEY_DOWN || event.GetKeyEvent() == Event::KEY_S) {
    move_down = keydown;
  }
}

float ControllerComponent::GetXVelocity() const {
  if (move_right || move_left) {
    return move_right ? x_velocity : -x_velocity;
  }
  return 0.0f;
}

float ControllerComponent::GetYVelocity() const {
  if (move_up || move_down) {
    return move_down ? y_velocity : -y_velocity;
  }
  return 0.0f;
}