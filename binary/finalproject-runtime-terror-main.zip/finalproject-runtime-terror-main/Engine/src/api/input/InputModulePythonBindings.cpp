//
// Created by psx95 on 4/11/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_INPUTMODULEPYTHONNBINDINS_CPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_INPUTMODULEPYTHONNBINDINS_CPP_

#include <api/Event.hpp>
#include <api/GameObject.hpp>
#include <api/ControllerComponent.hpp>
#include "pybind11/pybind11.h"
namespace py = pybind11;

void init_input(py::module &core) {
  //core.doc() = "APIs to handle user input for the Terror Engine";

  //================================================================================
  // Bindings for SupportedEventType enum
  //================================================================================
  py::enum_<Event::SupportedEventType>(core, "SupportedEvent")
      .value("UNSUPPORTED", Event::SupportedEventType::UNSUPPORTED)
      .value("APP_QUIT", Event::SupportedEventType::APP_QUIT)
      .value("KEY_RELEASE", Event::SupportedEventType::KEY_RELEASE)
      .value("KEY_PRESS", Event::SupportedEventType::KEY_PRESS)
      .export_values();

  //================================================================================
  // Bindings for SupportedKey enum
  //================================================================================
  py::enum_<Event::SupportedKey>(core, "SupportedKey")
      .value("NONE", Event::SupportedKey::NONE)
      .value("KEY_W", Event::SupportedKey::KEY_W)
      .value("KEY_A", Event::SupportedKey::KEY_A)
      .value("KEY_S", Event::SupportedKey::KEY_S)
      .value("KEY_D", Event::SupportedKey::KEY_D)
      .value("KEY_UP", Event::SupportedKey::KEY_UP)
      .value("KEY_DOWN", Event::SupportedKey::KEY_DOWN)
      .value("KEY_LEFT", Event::SupportedKey::KEY_LEFT)
      .value("KEY_RIGHT", Event::SupportedKey::KEY_RIGHT)
      .value("KEY_SPACE", Event::SupportedKey::KEY_SPACE)
      .value("KEY_ESC", Event::SupportedKey::KEY_ESC)
      .export_values();

  //================================================================================
  // Bindings for Event class
  //================================================================================
  py::class_<Event>(core, "Event")
      .def(py::init<Event::SupportedEventType, Event::SupportedKey>(),
           py::arg("event_type"),
           py::arg("event_key"))
      .def("GetKeyEvent", &Event::GetKeyEvent)
      .def("GetEventType", &Event::GetEventType)
      .def_static("GetFromSDLEvent", &Event::GetFromSDLEvent);

  //================================================================================
  // Bindings for ControllerComponent class
  //================================================================================
  py::class_<ControllerComponent, Component>(core, "ControllerComponent")
      .def(py::init<GameObject *, float, float>(),
           py::arg("game_object"),
           py::arg("x_velocity"),
           py::arg("y_velocity"))
      .def("GetXVelocity", &ControllerComponent::GetXVelocity)
      .def("GetYVelocity", &ControllerComponent::GetYVelocity);
};

#endif