//
// Created by psx95 on 4/16/21.
//

#include <SDL_mixer.h>
#include <api/ResourceManager.hpp>
#include "api/SoundController.hpp"

std::chrono::time_point<std::chrono::high_resolution_clock>
    SoundController::last_sound_effect_time = std::chrono::high_resolution_clock::now();

void SoundController::PlayBackgroundMusicTrack(std::string &music_res) {
  if (Mix_PlayingMusic() != 0) {
    Mix_HaltMusic();
  }
  Mix_PlayMusic(ResourceManager::GetInstance()->GetMusicResource(music_res), -1);
}

void SoundController::PlaySoundEffect(std::string &sound_effect_res, int loops) {
  auto current_time = std::chrono::high_resolution_clock::now();
  auto time_diff = current_time - SoundController::last_sound_effect_time;
  if (std::chrono::duration<float, std::chrono::milliseconds::period>(time_diff).count()
      > static_cast<float >(500 * (loops + 1))) {
    Mix_PlayChannel(-1, ResourceManager::GetInstance()->GetSoundEffectResource(sound_effect_res), loops);
    SoundController::last_sound_effect_time = current_time;
  }
}
