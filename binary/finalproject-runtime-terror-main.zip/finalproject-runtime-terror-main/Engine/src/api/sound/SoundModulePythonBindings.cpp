//
// Created by psx95 on 4/16/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_SOUND_SOUNDMODULEPYTHONNBINDINS_CPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_SOUND_SOUNDMODULEPYTHONNBINDINS_CPP_

#include "api/SoundController.hpp"
#include "pybind11/pybind11.h"
namespace py = pybind11;

void init_sound(py::module &core) {

  //================================================================================
  // Bindings for SoundController class
  //================================================================================
  py::class_<SoundController>(core, "SoundController")
      .def_static("PlayBackgroundMusicTrack", &SoundController::PlayBackgroundMusicTrack, py::arg("music_res"))
      .def_static("PlaySoundEffect",
                  &SoundController::PlaySoundEffect,
                  py::arg("sound_effect_res"),
                  py::arg("loops") = 0);
};
#endif