//
// Created by psx95 on 4/8/21.
//

#include "api/Component.hpp"

Component::Component(GameObject *game_object) {
  this->game_object = game_object;
}

void Component::Update(Event &event) {
  // EMPTY IMPLEMENTATION
}

void Component::ProcessUpdate(float delta_time) {
  // EMPTY IMPLEMENTATION
};

void Component::Render() {
  // EMPTY IMPLEMENTATION
}

ComponentType Component::GetComponentType() {
  // EMPTY IMPLEMENTATION
  return static_cast<ComponentType>(NULL);
}

ComponentCardinality Component::GetComponentCardinality() {
  // EMPTY IMPLEMENTATION
  return static_cast<ComponentCardinality>(NULL);
}

GameObject *Component::GetGameObject() {
  return this->game_object;
}

Component::~Component() {
  if (this->game_object != nullptr) {
    this->game_object = nullptr;
  }
}

void Component::Init() {
  // if no initialization required
}