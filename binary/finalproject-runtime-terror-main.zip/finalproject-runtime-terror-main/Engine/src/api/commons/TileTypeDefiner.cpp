//
// Created by psx95 on 4/19/21.
//

#include "api/TileTypeDefiner.hpp"
//TODO : This class can be removed, this is a sample implementation, in the actual game the user will provide this logic
Position TileTypeDefiner::GetTilePos(int tile_number, int tile_width, int tile_height) const {
  Position position{};
  switch (tile_number) {
    //dirt-middle
    case 1:position.x = 7 * tile_width;
      position.y = 1 * tile_height;
      break;
      //grass-middle
    case 2:position.x = 7 * tile_width;
      position.y = 0 * tile_height;
      break;
      //grass-start
    case 3:position.x = 6 * tile_width;
      position.y = 0 * tile_height;
      break;
      //grass-end
    case 4:position.x = 8 * tile_width;
      position.y = 0 * tile_height;
      break;
      //dirt-start
    case 5:position.x = 6 * tile_width;
      position.y = 1 * tile_height;
      break;
      //dirt-end
    case 6:position.x = 8 * tile_width;
      position.y = 1 * tile_height;
      break;
      //brick
    case 7:position.x = 17 * tile_width;
      position.y = 4 * tile_height;
      break;
      //purple-grass start
    case 8:position.x = 6 * tile_width;
      position.y = 8 * tile_height;
      break;
      //purple-grass dirt start
    case 9:position.x = 6 * tile_width;
      position.y = 9 * tile_height;
      break;
      //purple-grass middle
    case 11:position.x = 7 * tile_width;
      position.y = 8 * tile_height;
      break;
      //purple-grass dirt middle
    case 12:position.x = 7 * tile_width;
      position.y = 9 * tile_height;
      break;
      //purple-grass end
    case 13:position.x = 8 * tile_width;
      position.y = 8 * tile_height;
      break;
      //purple-grass dirt end
    case 14:position.x = 8 * tile_width;
      position.y = 9 * tile_height;
      break;
    default:break;
  }
  return position;
}
