//
// Created by psx95 on 4/11/21.
//

#include "api/Event.hpp"
Event::Event(Event::SupportedEventType event_type, SupportedKey event_key)
    : event_type(event_type), key_event(event_key) {

}

Event::SupportedKey Event::GetKeyEvent() const {
  return key_event;
}
Event::SupportedEventType Event::GetEventType() const {
  return event_type;
}

Event::SupportedKey Event::GetMappedKey(SDL_Event &event) {
  if (event.key.keysym.sym == SDLK_w) {
    return KEY_W;
  } else if (event.key.keysym.sym == SDLK_a) {
    return KEY_A;
  } else if (event.key.keysym.sym == SDLK_s) {
    return KEY_S;
  } else if (event.key.keysym.sym == SDLK_d) {
    return KEY_D;
  } else if (event.key.keysym.sym == SDLK_UP) {
    return KEY_UP;
  } else if (event.key.keysym.sym == SDLK_DOWN) {
    return KEY_DOWN;
  } else if (event.key.keysym.sym == SDLK_LEFT) {
    return KEY_LEFT;
  } else if (event.key.keysym.sym == SDLK_RIGHT) {
    return KEY_RIGHT;
  } else if (event.key.keysym.sym == SDLK_SPACE) {
    return KEY_SPACE;
  } else if (event.key.keysym.sym == SDLK_ESCAPE) {
    return KEY_ESC;
  } else {
    return NONE;
  }
}

Event Event::GetFromSDLEvent(SDL_Event &sdl_event) {
  Event user_event{};
  if (sdl_event.type == SDL_KEYDOWN) {
    user_event.event_type = KEY_PRESS;
  } else if (sdl_event.type == SDL_KEYUP) {
    user_event.event_type = KEY_RELEASE;
  } else if (sdl_event.type == SDL_QUIT) {
    user_event.event_type = APP_QUIT;
  }
  user_event.key_event = GetMappedKey(sdl_event);
  return user_event;
}
