//
// Created by psx95 on 4/17/21.
//

#include <iostream>
#include "api/ObjectConfig.hpp"

ObjectConfig::ObjectConfig(const std::string &object_id, const std::string &json_text)
    : json_config(nlohmann::json::parse(
    json_text).at(object_id)) {
}

Position ObjectConfig::GetPosition(const char *key) const {
  nlohmann::json position_object = json_config[key];
  auto position_x = std::stoi(position_object["x"].get<std::string>());
  auto position_y = std::stoi(position_object["y"].get<std::string>());
  Position position{position_x, position_y};
  return position;
}

void ObjectConfig::SetPosition(const char *key, Position position) {
  json_config[key]["x"] = std::to_string(position.x);
  json_config[key]["y"] = std::to_string(position.y);
}

Vector2D ObjectConfig::GetVector(const char *key) const {
  nlohmann::json vector_2d_object = json_config[key];
  auto vector_x = std::stof(vector_2d_object["x-vec"].get<std::string>());
  auto vector_y = std::stof(vector_2d_object["y-vec"].get<std::string>());
  return Vector2D(vector_x, vector_y);
}

void ObjectConfig::SetVector(const char *key, const Vector2D& vector_2d) {
  json_config[key]["x-vec"] = std::to_string(vector_2d.x);
  json_config[key]["y-vec"] = std::to_string(vector_2d.y);
}

GraphicsColor ObjectConfig::GetColor(const char *key) const {
  nlohmann::json color_object = json_config[key];
  auto color_red = std::stoi(color_object["r"].get<std::string>());
  auto color_green = std::stoi(color_object["g"].get<std::string>());
  auto color_blue = std::stoi(color_object["b"].get<std::string>());
  auto color_alpha = std::stoi(color_object["a"].get<std::string>());
  return GraphicsColor{static_cast<Uint8>(color_red), static_cast<Uint8>(color_green), static_cast<Uint8>(color_blue),
                       static_cast<Uint8>(color_alpha)};
}

void ObjectConfig::SetColor(const char *key, GraphicsColor color) {
  json_config[key]["r"] = std::to_string(color.r);
  json_config[key]["g"] = std::to_string(color.g);
  json_config[key]["b"] = std::to_string(color.b);
  json_config[key]["a"] = std::to_string(color.a);
}

Rect2D ObjectConfig::GetRect(const char *key) const {
  nlohmann::json rect_object = json_config[key];
  auto rect_x = std::stoi(rect_object["x"].get<std::string>());
  auto rect_y = std::stoi(rect_object["y"].get<std::string>());
  auto rect_w = std::stoi(rect_object["w"].get<std::string>());
  auto rect_h = std::stoi(rect_object["h"].get<std::string>());
  return Rect2D(rect_x, rect_y, rect_w, rect_h);
}

void ObjectConfig::SetRect(const char *key, Rect2D rect_2d) {
  json_config[key]["x"] = std::to_string(rect_2d.GetXPos());
  json_config[key]["y"] = std::to_string(rect_2d.GetYPos());
  json_config[key]["w"] = std::to_string(rect_2d.GetWidth());
  json_config[key]["h"] = std::to_string(rect_2d.GetHeight());
}

int ObjectConfig::GetInt(const char *key) const {
  return std::stoi(json_config[key]["integer_val"].get<std::string>());
}

void ObjectConfig::SetInt(const char *key, int value) {
  json_config[key]["integer_val"] = std::to_string(value);
}

float ObjectConfig::GetFloat(const char *key) const {
  return std::stof(json_config[key]["float_val"].get<std::string>());
}

void ObjectConfig::SetFloat(const char *key, float value) {
  json_config[key]["float_val"] = std::to_string(value);
}

double ObjectConfig::GetDouble(const char *key) const {
  return std::stod(json_config[key]["double_val"].get<std::string>());
}

void ObjectConfig::SetDouble(const char *key, double value) {
  json_config[key]["double_val"] = std::to_string(value);
}

std::string ObjectConfig::GetString(const char *key) const {
  return json_config[key]["string_val"].get<std::string>();
}

void ObjectConfig::SetString(const char *key, const std::string& value) {
  json_config[key]["string_val"] = value;
}

std::string ObjectConfig::GetClassName() const {
  return json_config["class_name"].get<std::string>();
}

std::string ObjectConfig::GetModuleName() const {
  return json_config["module_name"].get<std::string>();
}

bool ObjectConfig::GetBoolean(const char *key) const {
  std::string bool_representation = json_config[key]["boolean_val"].get<std::string>();
  if (bool_representation == "True") {
    return true;
  }
  return false;
}

void ObjectConfig::SetBoolean(const char* key, bool value) {
  json_config[key]["boolean_val"] = value;
}

std::string ObjectConfig::ToString() const {
  return json_config.dump();
}
