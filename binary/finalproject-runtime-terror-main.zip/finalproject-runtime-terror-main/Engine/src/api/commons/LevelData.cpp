//
// Created by psx95 on 4/19/21.
//

#include <iostream>
#include "api/LevelData.hpp"

LevelData::LevelData(int *arr, int row, int col) : m_tiles(arr), m_row(row), m_col(col) {
}

LevelData::~LevelData() {
  delete[] m_tiles;
}

int LevelData::GetTileType(int x, int y) {
  return m_tiles[y * m_col + x];
}

void LevelData::PrintMap() {
  for (int y = 0; y < m_row; ++y) {
    for (int x = 0; x < m_col; ++x) {
      std::cout << GetTileType(x, y) << ' ';
    }
    std::cout << std::endl;
  }
}