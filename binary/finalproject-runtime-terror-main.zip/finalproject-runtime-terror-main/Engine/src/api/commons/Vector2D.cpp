//
// Created by psx95 on 4/8/21.
//

#include "api/Vector2D.hpp"
Vector2D::Vector2D(float x, float y) : x(x), y(y) {
}

Vector2D::Vector2D(int x, int y) {
  this->x = static_cast<float>(x);
  this->y = static_cast<float>(y);
}

Vector2D Vector2D::operator+(const Vector2D &other_position) const {
  return Vector2D(this->x + other_position.x, this->y + other_position.y);
}

Vector2D &Vector2D::operator+=(const Vector2D &other_position) {
  this->x += other_position.x;
  this->y += other_position.y;
  return *this;
}

Vector2D Vector2D::operator*(float scalar_multiplier) const {
  return Vector2D(this->x * scalar_multiplier, this->y * scalar_multiplier);
}