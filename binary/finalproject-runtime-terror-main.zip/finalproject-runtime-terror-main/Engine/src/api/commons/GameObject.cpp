//
// Created by psx95 on 4/8/21.
//

#include "algorithm"
#include "api/ResourceManager.hpp"
#include "api/GameObject.hpp"

#include <utility>
#include <GameRunner.hpp>

GameObject::GameObject(std::string object_id) {
  this->object_id = std::move(object_id);
  attached_components = new std::vector<Component *>();
}

void GameObject::UpdateFromEvent(Event &event) {
  if (is_deleted) {
    return;
  }
  std::for_each(attached_components->begin(), attached_components->end(), [&event](Component *attached_component) {
    if (attached_component != nullptr) {
      attached_component->Update(event);
    }
  });
}

void GameObject::Update(float delta_time) {
  if (is_deleted) {
    return;
  }
  std::for_each(std::begin(*attached_components),
                std::end(*attached_components),
                [&delta_time](Component *attached_component) {
                  if (attached_component != nullptr) {
                    attached_component->ProcessUpdate(delta_time);
                  }
                });
}

void GameObject::Render() {
  if (is_deleted) {
    return;
  }
  std::for_each(attached_components->begin(), attached_components->end(), [](Component *attached_component) {
    if (attached_component != nullptr) {
      attached_component->Render();
    }
  });
}

void GameObject::AddComponent(Component *component) {
  if (is_deleted) {
    return;
  }
  if (component == nullptr) {
    throw std::runtime_error("Unable to add a null component");
  }
  if (component->GetComponentCardinality() == ComponentCardinality::SINGLE) {
    ReplaceUniqueComponents(component);
  } else {
    attached_components->push_back(component);
  }
}

void GameObject::RemoveComponent(Component *component) {
  // TODO: Need a better way than this
}

void GameObject::RemoveComponentType(ComponentType component_type) {
  if (is_deleted) {
    return;
  }
  if (attached_components != nullptr) {
    attached_components->erase(std::remove_if(attached_components->begin(),
                                              attached_components->end(),
                                              [component_type](Component *component) {
                                                return component->GetComponentType() == component_type;
                                              }), attached_components->end());
  }
}

void GameObject::DeleteAllComponents() {
  if (is_deleted) {
    return;
  }
  if (attached_components != nullptr) {
    std::for_each(attached_components->begin(), attached_components->end(), [](Component *attached_component) {
      if (attached_component != nullptr) {
        attached_component = nullptr;
        delete attached_component;
      }
    });
    delete attached_components;
  }
}

GameObject::~GameObject() {
  DeleteAllComponents();
}

void GameObject::ReplaceUniqueComponents(Component *component) {
  if (is_deleted) {
    return;
  }
  // game objects could be maintained as a map instead - to aid in lookups
  // for now, using vectors as per lab requirements
  bool replaced = false;
  for (int i = 0; i < attached_components->size(); i++) {
    if (attached_components->at(i)->GetComponentType() == component->GetComponentType()) {
      // replace
      replaced = true;
      attached_components->at(i) = component;
    }
  }
  if (!replaced) {
    // it did not exist earlier
    attached_components->push_back(component);
  }
}

void GameObject::Init() {
  if (is_deleted) {
    return;
  }
  std::for_each(attached_components->begin(), attached_components->end(), [](Component *attached_component) {
    attached_component->Init();
  });
}

void GameObject::MarkObjectForDestruction() {
  if (is_deleted) {
    return;
  }
  DeleteAllComponents();
  is_deleted = true;
}

bool GameObject::IsDeleted() {
  return is_deleted;
}

const std::string &GameObject::GetObjectId() const {
  return object_id;
}

void GameObject::OnCollisionStart(GameObject *collided_with) {
  /*
  * https://github.com/pybind/pybind11/issues/1552
  * This method is not being called from the extending classes in python code. This is an open issue in pybind11.
  * As a workaround, this proxy method is being exposed to python and is manually called from here.
  * Since ConveyCollisionXXXXX method manually goes through all python objects currently present and calls corresponding
  * ProcessCollisionXXXX method on the appropriate GameObject, this approach works.
  * */
  GameRunner::GetInstance()->ConveyCollisionStartEvent(object_id, collided_with->GetObjectId());
}

void GameObject::OnCollisionEnd(GameObject *collided_with) {
  /*
  * https://github.com/pybind/pybind11/issues/1552
  * This method is not being called from the extending classes in python code. This is an open issue in pybind11.
  * As a workaround, this proxy method is being exposed to python and is manually called from here.
  * Since ConveyCollisionXXXXX method manually goes through all python objects currently present and calls corresponding
  * ProcessCollisionXXXX method on the appropriate GameObject, this approach works.
  * */
  GameRunner::GetInstance()->ConveyCollisionEndEvent(object_id, collided_with->GetObjectId());
}

void GameObject::ProcessCollisionStart(const std::string &collided_with_id) {
  // To be overridden by the user in the python script
}

void GameObject::ProcessCollisionEnd(const std::string &collided_with_id) {
  // To be overridden by the user in the python script
}

void GameObject::OnPause() {
  // To be overridden by the user in the python script
}

void GameObject::OnResume() {
  // To be overridden by the user in the python script
}
