#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICS_PHYSICSMODULEPYTHONNBINDINS_CPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICS_PHYSICSMODULEPYTHONNBINDINS_CPP_

#include "api/GameObject.hpp"
#include "api/Component.hpp"
#include "api/PhysicsComponent.hpp"
#include "api/PhysicsManager.hpp"
#include <pybind11/pybind11.h>

namespace py = pybind11;

void init_physics(py::module &core) {
  //core.doc() = "The physics APIs for the Terror Engine";

  //================================================================================
  // Bindings for PHYSICS_BODY_MOVEMENT const int
  //================================================================================
  core.def("PHYSICS_BODY_MOVEMENT_STOP", [](){ return PHYSICS_BODY_MOVEMENT_STOP; });
  core.def("PHYSICS_BODY_MOVEMENT_LEFT", [](){ return PHYSICS_BODY_MOVEMENT_LEFT; });
  core.def("PHYSICS_BODY_MOVEMENT_RIGHT", [](){ return PHYSICS_BODY_MOVEMENT_RIGHT; });
  core.def("PHYSICS_BODY_MOVEMENT_UP", [](){ return PHYSICS_BODY_MOVEMENT_UP; });
  core.def("PHYSICS_BODY_MOVEMENT_DOWN", [](){ return PHYSICS_BODY_MOVEMENT_DOWN; });
  core.def("PHYSICS_BODY_MOVEMENT_JUMP", [](){ return PHYSICS_BODY_MOVEMENT_JUMP; });

  //================================================================================
  // Bindings for PhysicsBodyType struct
  //================================================================================
  py::enum_<PhysicsBodyType>(core, "PhysicsBodyType")
      .value("PHYSICS_BODY_STATIC", PhysicsBodyType::PHYSICS_BODY_STATIC)
      .value("PHYSICS_BODY_DYNAMIC", PhysicsBodyType::PHYSICS_BODY_DYNAMIC)
      .export_values();

  //================================================================================
  // Bindings for PhysicsBodyConfig struct
  //================================================================================
  py::class_<PhysicsBodyConfig>(core, "PhysicsBodyConfig")
      .def(py::init())
      .def_readwrite("type", &PhysicsBodyConfig::type)
      .def_readwrite("pos_x", &PhysicsBodyConfig::pos_x)
      .def_readwrite("pos_y", &PhysicsBodyConfig::pos_y)
      .def_readwrite("width", &PhysicsBodyConfig::width)
      .def_readwrite("height", &PhysicsBodyConfig::height)
      .def_readwrite("polygon_shape", &PhysicsBodyConfig::polygon_shape)
      .def_readwrite("circle_shape", &PhysicsBodyConfig::circle_shape)
      .def_readwrite("density", &PhysicsBodyConfig::density)
      .def_readwrite("friction", &PhysicsBodyConfig::friction)
      .def_readwrite("restitution", &PhysicsBodyConfig::restitution)
      .def("SetShapeAsBox", &PhysicsBodyConfig::SetShapeAsBox, py::arg("width"), py::arg("height"))
      .def("SetShapeAsCircle", &PhysicsBodyConfig::SetShapeAsCircle, py::arg("radius"));

  //================================================================================
  // Bindings for PhysicsComponent class
  //================================================================================
  py::class_<PhysicsComponent, Component>(core, "PhysicsComponent")
      .def(py::init<GameObject *, PhysicsBodyConfig *>(),
           py::arg("game_object"),
           py::arg("config"))
      .def("ProcessUpdate", &PhysicsComponent::ProcessUpdate)
      .def("Render", &PhysicsComponent::Render)
      .def("Update", &PhysicsComponent::Update, py::arg("event"))
      .def("GetComponentCardinality", &PhysicsComponent::GetComponentCardinality)
      .def("GetComponentType", &PhysicsComponent::GetComponentType)
      .def("MoveBody", &PhysicsComponent::MoveBody, py::arg("move_flag"), py::arg("vel"))
      .def("GetBodyPosition", &PhysicsComponent::GetBodyPosition)
      .def("GetBodyVelocity", &PhysicsComponent::GetBodyVelocity)
      .def("GetBodySpeed", &PhysicsComponent::GetBodySpeed)
      .def("SetBodyVelocity", &PhysicsComponent::SetBodyVelocity, py::arg("vel"))
      .def_static("SDLPositionToPhysicsPosition", &PhysicsComponent::SDLPositionToPhysicsPosition, py::arg("position"))
      .def_static("PhysicsPositionToSDLPosition", &PhysicsComponent::PhysicsPositionToSDLPosition, py::arg("position"));
};

#endif
