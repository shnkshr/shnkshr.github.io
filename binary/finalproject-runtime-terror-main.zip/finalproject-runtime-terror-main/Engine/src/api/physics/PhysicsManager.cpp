#include "api/PhysicsManager.hpp"

PhysicsManager *PhysicsManager::instance = nullptr;

PhysicsManager *PhysicsManager::GetInstance() {
  if (instance == nullptr) {
    instance = new PhysicsManager();
  }
  return instance;
}

void PhysicsManager::Initialize(float gravity) {
  m_gravity = gravity;

  b2Vec2 gravity_vec(0.0f, -m_gravity);
  m_world = new b2World(gravity_vec);
  world_contact_listener = new WorldCollisionListener();
  m_world->SetContactListener(world_contact_listener);
}

void PhysicsBodyConfig::SetShapeAsBox(float width, float height) {
  // shape.SetAsBox(width / (2 * PIXEL_PER_METER), height / (2 * PIXEL_PER_METER));
  float corner = 0.95;
  width /= 2 * PIXEL_PER_METER;
  height /= 2 * PIXEL_PER_METER;
  b2Vec2 vertices[8];
  vertices[0].Set(-width * corner, height);
  vertices[1].Set(-width, height * corner);
  vertices[2].Set(-width, -height * corner);
  vertices[3].Set(-width * corner, -height);
  vertices[4].Set(width * corner, -height);
  vertices[5].Set(width, -height * corner);
  vertices[6].Set(width, height * corner);
  vertices[7].Set(width * corner, height);
  shape_type = PhysicsBodyShape::PHYSICS_BODY_POLYGON;
  polygon_shape.Set(vertices, 8);
}

void PhysicsBodyConfig::SetShapeAsCircle(float radius) {
  circle_shape.m_p.Set(0, 0);
  circle_shape.m_radius = radius / PIXEL_PER_METER;
  shape_type = PhysicsBodyShape::PHYSICS_BODY_CIRCLE;
}

void PhysicsBodyConfig::SetShapeAsArray(b2Vec2 *vecs, int count) {
  polygon_shape.Set(vecs, count);
  shape_type = PhysicsBodyShape::PHYSICS_BODY_POLYGON;
}

bool PhysicsManager::HaveBody(const std::string &id) {
  return m_body_map.find(id) == m_body_map.end();
}

b2Body *PhysicsManager::CreateBody(const std::string& id, PhysicsBodyConfig *config) {
  if (m_world == nullptr || config == nullptr || !HaveBody(id)) {
    return nullptr;
  }

  b2BodyDef bodyDef;
  bodyDef.type = config->type == PHYSICS_BODY_STATIC ? b2_staticBody : b2_dynamicBody;
  bodyDef.position.Set(config->pos_x, config->pos_y);
  b2Body *body = m_world->CreateBody(&bodyDef);

  if (config->type == PHYSICS_BODY_STATIC) {
    if (config->shape_type == PhysicsBodyShape::PHYSICS_BODY_POLYGON) {
      body->CreateFixture(&config->polygon_shape, 0.0f);
    } else if (config->shape_type == PhysicsBodyShape::PHYSICS_BODY_CIRCLE) {
      body->CreateFixture(&config->circle_shape, 0.0f);
    }
  } else {
    b2FixtureDef fixtureDef;
    if (config->shape_type == PhysicsBodyShape::PHYSICS_BODY_POLYGON) {
      fixtureDef.shape = &config->polygon_shape;
    } else if (config->shape_type == PhysicsBodyShape::PHYSICS_BODY_CIRCLE) {
      fixtureDef.shape = &config->circle_shape;
    }
    fixtureDef.density = config->density;
    fixtureDef.friction = config->friction;
    fixtureDef.restitution = config->restitution;
    body->CreateFixture(&fixtureDef);
    body->SetFixedRotation(true);
  }

  m_body_map.insert(std::make_pair(id, body));
  return body;
}

b2Body *PhysicsManager::GetBody(const std::string& id) {
  auto body = m_body_map.find(id);
  return body != m_body_map.end() ? body->second : nullptr;
}

void PhysicsManager::DestroyBody(const std::string &id) {
  auto body = m_body_map.find(id);
  if (body != m_body_map.end()) {
    m_world->DestroyBody(body->second);
    m_body_map.erase(body);
  }
}

void PhysicsManager::Update(float step_time) {
  if (m_world != nullptr) {
    m_world->Step(step_time, VELOCITY_ITERATIONS, POSITION_ITERATIONS);
  }
}

void PhysicsManager::Shutdown() {
  // do not destroy bodies here, since it is handled individually PhysicsComponent
  // doing this will essentially wait till a shutdown call to PhysicsManager before bodies can be destroyed
  /*for (auto &entry: m_body_map) {
    m_world->DestroyBody(entry.second);
  }*/
  delete world_contact_listener;
  delete m_world;
  instance = nullptr;
}