#include "api/PhysicsComponent.hpp"
#include "api/GameObject.hpp"

PhysicsComponent::PhysicsComponent(GameObject *game_object, PhysicsBodyConfig *config)
    : Component(game_object), m_width(config->width), m_height(config->height) {
  Vector2D vec(0, 0);
  vec.x = config->pos_x + config->width / 2;
  vec.y = config->pos_y + config->height / 2;
  vec = PhysicsComponent::SDLPositionToPhysicsPosition(vec);
  config->pos_x = vec.x;
  config->pos_y = vec.y;
  this->m_body = PhysicsManager::GetInstance()->CreateBody(game_object->GetObjectId(), config);
  this->m_body->SetUserData(game_object);
}

void PhysicsComponent::ProcessUpdate(float delta_time) {
}

void PhysicsComponent::Render() {
}

void PhysicsComponent::Update(Event &event) {
}

ComponentCardinality PhysicsComponent::GetComponentCardinality() {
  return ComponentCardinality::SINGLE;
}

ComponentType PhysicsComponent::GetComponentType() {
  return ComponentType::PHYSICS;
}

void PhysicsComponent::MoveBody(unsigned int move_flag, Vector2D &velocity) {
  if (m_body == nullptr) {
    return;
  }

  b2Vec2 vel = m_body->GetLinearVelocity();
  if (move_flag & PHYSICS_BODY_MOVEMENT_LEFT) {
    vel.x = -velocity.x;
  } else if (move_flag & PHYSICS_BODY_MOVEMENT_RIGHT) {
    vel.x = velocity.x;
  }

  if (move_flag & PHYSICS_BODY_MOVEMENT_UP) {
    vel.y = velocity.y;
  } else if (move_flag & PHYSICS_BODY_MOVEMENT_DOWN) {
    vel.y = -velocity.y;
  } else if (move_flag & PHYSICS_BODY_MOVEMENT_JUMP) {
    vel.y = velocity.y;
  }

  if (move_flag & PHYSICS_BODY_MOVEMENT_STOP) {
    vel.x = vel.y = 0;
  }

  m_body->SetLinearVelocity(vel);
}

Vector2D PhysicsComponent::GetBodyPosition() {
  Vector2D result{0, 0};
  b2Vec2 vec = m_body->GetPosition();
  // TODO: maybe need to transfer b2world position to screen postion
  // Unit of Box2D axis is meter, need to convert to pixel level position.
  // Also Box2D has opposite y axis direction as SDL2's.
  // In Box2D, y position is becoming smaller when falling down.
  result.x = vec.x;
  result.y = vec.y;
  result = PhysicsComponent::PhysicsPositionToSDLPosition(result);
  result.x -= m_width / 2;
  result.y -= m_height / 2;
  return result;
}

Vector2D PhysicsComponent::GetBodyVelocity() {
  Vector2D res(0, 0);
  res.x = m_body->GetLinearVelocity().x;
  res.y = m_body->GetLinearVelocity().y;
  return res;
}

void PhysicsComponent::SetBodyVelocity(Vector2D &vel) {
  b2Vec2 vec;
  vec.x = vel.x;
  vec.y = vel.y;
  m_body->SetLinearVelocity(vec);
}

Vector2D PhysicsComponent::PhysicsPositionToSDLPosition(Vector2D &vec) {
  Vector2D res(static_cast<int>(vec.x * PIXEL_PER_METER), SCREEN_HEIGHT - static_cast<int>(vec.y * PIXEL_PER_METER));
  return res;
}

Vector2D PhysicsComponent::SDLPositionToPhysicsPosition(Vector2D &vec) {
  Vector2D
      res(static_cast<float>(vec.x / PIXEL_PER_METER), static_cast<float>((SCREEN_HEIGHT - vec.y) / PIXEL_PER_METER));
  return res;
}

PhysicsComponent::~PhysicsComponent() {
  // destroy the associated physics body here since it is created by this component
  if (m_body != nullptr)
    m_body->GetWorld()->DestroyBody(m_body);
}

float PhysicsComponent::GetBodySpeed() {
  return m_body->GetLinearVelocity().Length();
}
