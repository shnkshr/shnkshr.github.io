//
// Created by psx95 on 4/20/21.
//

#include "api/WorldCollisionListener.hpp"
#include <Box2D/Dynamics/Contacts/b2Contact.h>
#include <api/GameObject.hpp>

void WorldCollisionListener::BeginContact(b2Contact *contact) {
  b2ContactListener::BeginContact(contact);
  // check if fixture A was a game object
  void *game_object = contact->GetFixtureA()->GetBody()->GetUserData();
  void *game_object_collided_with = contact->GetFixtureB()->GetBody()->GetUserData();
  if (game_object && game_object_collided_with) {
    static_cast<GameObject *>(game_object)->OnCollisionStart(static_cast<GameObject *>(game_object_collided_with));
  }
}

void WorldCollisionListener::EndContact(b2Contact *contact) {
  b2ContactListener::EndContact(contact);
  void *game_object = contact->GetFixtureA()->GetBody()->GetUserData();
  void *game_object_collided_with = contact->GetFixtureB()->GetBody()->GetUserData();
  if (game_object && game_object_collided_with) {
    static_cast<GameObject *>(game_object)->OnCollisionEnd(static_cast<GameObject *>(game_object_collided_with));
  }
}
