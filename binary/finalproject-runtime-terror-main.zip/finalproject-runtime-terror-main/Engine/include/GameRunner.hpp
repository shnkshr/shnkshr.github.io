//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_GAMERUNNER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_GAMERUNNER_HPP_

#include <vector>
#include <map>
#include <pybind11/pytypes.h>
#include <api/GlobalConfig.hpp>
#include <api/ObjectConfig.hpp>
#include <pybind11/pybind11.h>
#include "InternalGraphicsEngineRenderer.hpp"

namespace py = pybind11;
/*!
 * @brief This class is responsible for running the main game loop
 * @details The game built by this game engine will still be a C++ game at its core, the only difference is that the
 * game engine allows user to add game objects via GUI and its associated logic using python scripts, the resource
 * management, memory management, rendering is all handled by the game engine
 */
class GameRunner {
 private:
  /*!
 * @brief Private constructor to prevent instantiation from outside.
 */
  GameRunner() = default;
  GameRunner(GameRunner const &); // Prevent access to copy constructor
  void operator=(GameRunner const &); // Prevent access to assignment operator
  static GameRunner *instance;

  InternalGraphicsEngineRenderer *graphics_subsystem{};
  std::map<std::string, py::object> python_game_objects;
  bool quit{};
  bool pause{};
  bool callOnPause{};
  bool callOnResume{};
  std::string object_config_content;
  GlobalConfig *global_config{};

  void Input(bool *quit);
  /**
   * Per frame update
   * @param dt The delta time between 2 consecutive frames
   */
  void Update(float dt);
  /**
   * Per frame render. Renders everything
   */
  void Render();

  void InitGameObjects();

  void PreparePythonGameObjectsFromConfig();

  void RemoveObjectsMarkedForDeletion();

  static std::string GetConfigFileContent(std::string &file_path);

 public:
  /**
   * Method to get the singleton instance of GameRunner that drives the main game loop.
   * @return The singleton instance.
   */
  static GameRunner *GetInstance();

  /**
   * Method to pause the game.
   * @param pause Boolean to pause or unpause.
   */
  void PauseGame(bool pause);

  /**
   * Checks if the the game is paused.
   * @return Boolean flag that denotes if the game is paused.
   */
  bool IsPause() const;
  /**
   * Main Game Loop that runs forever
   */
  void MainGameLoop();
  /**
   * Initialization and shutdown pattern
   * Explicitly call 'Start' to launch the engine
   */
  void Start();
  /**
   * Initialization and shutdown pattern
   * Explicitly call 'Shutdown' to terminate the engine
   */
  void Shutdown();

  /**
   * Request to startup the Graphics Subsystem
   */
  void InitializeGraphicsSubSystem(const std::string &object_config_path);

  /**
   * Finds and returns the PyBind Game Object with the given object_id.
   * @param object_id ID of the game object.
   * @return PyBind object.
   */
  py::object *FindGameObject(const std::string &object_id);

  void ConveyCollisionStartEvent(const std::string &object_collided_id, const std::string &object_collided_with);

  void ConveyCollisionEndEvent(const std::string &object_collided_id, const std::string &object_collided_with);

  /**
   * Adds Game object from the input python script.
   * @param object_id Game object ID identified as a key in the script.
   * @param module_name Module name of the game object belongs to.
   * @param class_name Class name of the game object.
   * @param config Object configuration.
   */
  void AddGameObjectFromScript(const std::string &object_id,
                               const std::string &module_name,
                               const std::string &class_name,
                               const ObjectConfig& config);

  ~GameRunner();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_GAMERUNNER_HPP_
