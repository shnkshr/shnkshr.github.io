//
// Created by psx95 on 4/12/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_INTERNALGRAPHICSENGINERENDERER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_INTERNALGRAPHICSENGINERENDERER_HPP_

#include <SDL.h>
#include <api/Event.hpp>

/*!
 * @brief This class represents an abstraction over the internal engine renderer.
 * @details This class initializes the ResourceManager class with the correct renderer, which in this case is SDL_Renderer.
 * Currently just provides a reference to the main Game window and renderer to simplify code in GameRunner class.
 * Basically this class deals with all SDL (the internal graphics engine used) related functionality.
 */
class InternalGraphicsEngineRenderer {
 public:
  /**
   * Constructor.
   */
  InternalGraphicsEngineRenderer(int w, int h);

  /**
   * Get Pointer to Window.
   */
  SDL_Window *GetWindow() const;

  /**
   * Get Pointer to Renderer.
   */
  SDL_Renderer *GetRenderer() const;

  /**
   * Sets the color of the renderer.
   * @param r Red value of the color model.
   * @param g Green value of the color model.
   * @param b Blue value of the color model.
   * @param a Opacity value of the color model.
   */
  void SetRenderDrawColor(int r, int g, int b, int a);

  /**
   * Clears the renderer.
   */
  void RenderClear();

  /**
   * Updates the screen with any rendering performed since the previous call.
   */
  void RenderPresent();

  /**
   * Enables vsync to synchronise frame rate.
   * @param enable
   */
  static void EnableVSync(bool enable = true);

  /**
   * Shuts down the internal graphics renderer.
   */
  void ShutdownInternalGraphicsRenderer();

  /**
   * Toglles SDL text input from the user.
   * @param accept_input Boolean flag to toggle the SDL text input.
   */
  static void ToggleUserInputAccept(bool accept_input);

  bool PollUserEvents(Event *user_event);

  /**
   * Destructor
   */
  ~InternalGraphicsEngineRenderer();

 private:
  // Screen dimension constants
  int m_screenHeight;
  int m_screenWidth;
  // SDL Window
  SDL_Window *m_window;
  // SDL Renderer
  SDL_Renderer *m_renderer = nullptr;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_INTERNALGRAPHICSENGINERENDERER_HPP_
