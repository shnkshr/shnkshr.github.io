//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_INCLUDE_API_CORESTRUCTS_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_INCLUDE_API_CORESTRUCTS_HPP_

#include <SDL_stdinc.h>
#include "ResourceManager.hpp"

/*!
 * @brief A struct to represent 2D position.
 */
struct Position {
  int x;
  int y;
};

/*!
 * @brief A struct to represent Colors used in this Engine.
 */
struct GraphicsColor {
  Uint8 r;
  Uint8 g;
  Uint8 b;
  Uint8 a;
};

struct BasicShapes {

  static void RenderRectangle(int x, int y, int w, int h, GraphicsColor color) {
    SDL_SetRenderDrawColor(ResourceManager::GetInstance()->GetEngineRenderer(), color.r, color.g, color.b, color.a);
    SDL_Rect rect = {x, y, w, h};
    SDL_RenderFillRect(ResourceManager::GetInstance()->GetEngineRenderer(), &rect);
  }

  static void RenderPoint(int x, int y, GraphicsColor color) {
    SDL_SetRenderDrawColor(ResourceManager::GetInstance()->GetEngineRenderer(), color.r, color.g, color.b, color.a);
    SDL_RenderDrawPoint(ResourceManager::GetInstance()->GetEngineRenderer(), x, y);
  }

  static void RenderCircle(int radius, int cx, int cy, GraphicsColor color) {
    for (int dy = 1; dy <= radius; dy += 1) {
      double dx = floor(sqrt((2.0 * radius * dy) - (dy * dy)));
      SDL_SetRenderDrawColor(ResourceManager::GetInstance()->GetEngineRenderer(), color.r, color.g, color.b, color.a);
      SDL_RenderDrawLine(ResourceManager::GetInstance()->GetEngineRenderer(),
                         cx - dx,
                         cy + dy - radius,
                         cx + dx,
                         cy + dy - radius);
      SDL_RenderDrawLine(ResourceManager::GetInstance()->GetEngineRenderer(),
                         cx - dx,
                         cy - dy + radius,
                         cx + dx,
                         cy - dy + radius);
    }
  }
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_INCLUDE_API_CORESTRUCTS_HPP_
