//
// Created by psx95 on 4/20/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICS_WORLDCOLLISIONLISTENER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICS_WORLDCOLLISIONLISTENER_HPP_

#include <Box2D/Dynamics/b2WorldCallbacks.h>
/*!
 * @brief A custom collision listener for the box 2d API.
 * @details This class allows for injecting custom logic during collisions that take place throughout the program.
 */
class WorldCollisionListener : public b2ContactListener {
 public:
  /*!
   * @brief This method is called when a collision begins between two physics bodies created using the box 2d API.
   * @param contact A pointer to data structure that holds information about this collision.
   */
  void BeginContact(b2Contact *contact) override;

  /*!
   * @brief This method is called when a collision ends between two physics bodies created using the box 2d API.
   * @param contact A pointer to data structure that holds information about this collision.
   */
  void EndContact(b2Contact *contact) override;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICS_WORLDCOLLISIONLISTENER_HPP_
