//
// Created by psx95 on 4/23/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GLOBALCONFIG_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GLOBALCONFIG_HPP_

#include <string>
#include "CoreStructs.hpp"
#include "json.hpp"

/*!
 * @brief This class represents the configuration part from the Engine editor that corresponds to the Game wide settings.
 */
class GlobalConfig {
 private:
  nlohmann::json global_config;
  std::string background_image_res;
  std::string background_music_res;
  std::string camera_follows_object;
  GraphicsColor background_color{};
  float gravity{};
  int screen_width{};
  int screen_height{};

  // private setters
  void SetScreenDimensions();
  void SetBackgroundImageRes();
  void SetBackgroundMusicRes();
  void SetCameraFollowObject();
  void SetBackgroundColor();
  void SetGravity();

 public:
  /**
   * Constructor.
   * @param global_config_json Global configuration JSON of the game.
   */
  explicit GlobalConfig(const std::string &global_config_json);

  /**
   * Returns the background image resolution.
   * @return background image resolution.
   */
  const std::string &GetBackgroundImageRes() const;

  /**
   * Returns the background music resolution.
   * @return background music resolution.
   */
  const std::string &GetBackgroundMusicRes() const;

  /**
   * Returns the ID of the game object for which the camera component is attached to.
   * @return ID of the game object.
   */
  const std::string &GetCameraFollowsObject() const;

  /**
   * Returns the background color of the game.
   * @return background graphics color
   */
  const GraphicsColor &GetBackgroundColor() const;

  /**
   * Returns the width of the game screen.
   * @return game screen width.
   */
  int GetScreenWidth() const;

  /**
   * Returns the height of the game screen.
   * @return game screen height.
   */
  int GetScreenHeight() const;

  /**
   * Returns the gravity value that is applied in the game.
   * @return gravity float value.
   */
  float GetGravity() const;

  /**
   * Overriding toString.
   * @return String representing the config.
   */
  std::string ToString() const;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GLOBALCONFIG_HPP_
