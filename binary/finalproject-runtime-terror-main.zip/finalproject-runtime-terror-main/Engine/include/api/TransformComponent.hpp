//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TRANSFORMCOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TRANSFORMCOMPONENT_HPP_

#include "CoreStructs.hpp"
#include "Component.hpp"

/*!
 * @brief This class represents a transform component that defines a game object's position in the world.
 */
class TransformComponent : public Component {
 public:
  /*!
   * @brief Public constructor for the class.
   * @param game_object The associated game object.
   * @param position The initial position for the transform.
   * @param x_margin The x-margin from the position. Not used.
   * @param y_margin The y-margin from the position. Not used.
   */
  explicit TransformComponent(GameObject *game_object, Position position, int x_margin = 0, int y_margin = 0);

  /*!
   * @brief Overridden implementation for process update that updates the transform per frame.
   * @param delta_time The time difference between 2 consecutive frames.
   */
  void ProcessUpdate(float delta_time) override;

  /*!
   * @brief Overridden implementation for user based update to update the transform based on user update.
   * @details Currently empty implementation.
   * @param event The user based event that occurred.
   */
  void Update(Event &event) override;

  /*!
   * @brief Overridden implementation for render that is used to render transform.
   * @details Currently empty implementation.
   */
  void Render() override;

  /*!
   * @brief  Overridden implementation to get the ComponentType for transform component.
   * @return The ComponentType of the TransformComponent.
   */
  ComponentType GetComponentType() override;

  /*!
   * @brief  Overridden implementation to get the cardinality of transform component.
   * @return The ComponentCardinality for TransformComponent.
   */
  ComponentCardinality GetComponentCardinality() override;

  /*!
   * @brief Getter to get the current transform position.
   * @details The transform position is relative to the world dimensions.
   * @return A Position reference that contains the transform position.
   */
  Position &GetTransformPosition();

  /*!
   * @brief Getter to get the current visual position.
   * @details Visual position is relative to the screen dimensions.
   * @return A Position reference that contains the visual position for the transform component.
   */
  Position &GetVisualPosition();

  /*!
   * @brief A method to update the visual position of the transform.
   * @param x The x-axis coordinate for the visual position.
   * @param y The y-axis coordinate for the visual position.
   */
  void UpdateVisualPosition(int x, int y);

  /*!
   * @brief A method to update the actual position of the transform component.
   * @param x The x-axis coordinate for the transform position.
   * @param y The y-axis coordinate for the transform position.
   */
  void UpdateTransformPosition(int x, int y);

  ~TransformComponent() = default;

 private:
  Position position{}; // this is the transform position - to be used with camera components
  Position visual_position{}; // this is the adjusted position with respect to camera (always fixed) - represents the actual player

  int x_boundary_margin{}; // this is the x-axis margin that must be left from the screen
  int y_boundary_margin{}; // this is the y-axis margin that must be left from the screen

};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TRANSFORMCOMPONENT_HPP_
