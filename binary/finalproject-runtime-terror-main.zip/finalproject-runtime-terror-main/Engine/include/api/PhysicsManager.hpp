#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_PHYSICSMANAGER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_PHYSICSMANAGER_HPP_

#include <Box2D/Box2D.h>
#include <string>
#include <map>
#include "../GlobalConstants.hpp"
#include "WorldCollisionListener.hpp"

const int32 VELOCITY_ITERATIONS = 8;
const int32 POSITION_ITERATIONS = 3;

const float GRAVITY_DEFAULT = 10.0f;

enum PhysicsBodyType {
  PHYSICS_BODY_STATIC,
  PHYSICS_BODY_DYNAMIC,
};

enum PhysicsBodyShape {
  PHYSICS_BODY_POLYGON = 0,
  PHYSICS_BODY_CIRCLE
};

struct PhysicsBodyConfig {
  PhysicsBodyType type{};
  float pos_x{};
  float pos_y{};
  float width{};
  float height{};
  PhysicsBodyShape shape_type{};
  b2PolygonShape polygon_shape{};
  b2CircleShape circle_shape{};
  float density{};
  float friction{};
  float restitution{};

  void SetShapeAsBox(float width, float height);
  void SetShapeAsCircle(float radius);
  void SetShapeAsArray(b2Vec2* vecs, int count);
};

/*!
 * @brief This class provides an abstraction to conveniently access the box 2d APIs.
 */
class PhysicsManager {
 private:
  PhysicsManager() = default;
  PhysicsManager(PhysicsManager const &);
  void operator=(PhysicsManager const &);

  static PhysicsManager* instance;

  b2World* m_world = nullptr;
  WorldCollisionListener *world_contact_listener{};
  float m_gravity{};
  std::map<std::string, b2Body *> m_body_map{};

 public:
  static PhysicsManager* GetInstance();

  void Initialize(float gravity = GRAVITY_DEFAULT);
  void Shutdown();

  bool HaveBody(const std::string& id);
  b2Body* CreateBody(const std::string& id, PhysicsBodyConfig* config);
  b2Body* GetBody(const std::string& id);
  void DestroyBody(const std::string& id);

  void Update(float step_time);

  ~PhysicsManager() = default;
};

#endif
