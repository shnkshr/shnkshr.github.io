#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILEMAP_OBJECT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILEMAP_OBJECT_HPP_

#include "GameObject.hpp"
#include "TileMapComponent.hpp"
#include "LevelData.hpp"

/*!
 * @brief Special game object representing the tile map.
 * @details This can be useful in collision detection as well since the updates will need to be handled differently
 * than other objects and components.
 */
class TileMapObject : public GameObject {
 private:
  std::string object_id;
  TileMapComponent *tile_map_component{};

 public:
  /*!
   * @brief Public constructor for the TileMapObject.
   * @param object_id The unique ID assigned to this object.
   * @param texture_res File path to the texture resource for this tile map.
   * @param tile_map_res File path to the actual text based tile map.
   * @param camera_attached_object The id of the object to which the camera is attached.
   * @param tile_type_definer The TileTypeDefiner that is used to map interger representation of tiles to their source position in spritesheets.
   * @param rows number of rows [deprecated]
   * @param cols number of cols [deprecated]
   * @param tile_width The source width of individual tile in the sprite sheet.
   * @param tile_height The source height of individual tile in the sprite sheet.
   * @param dest_tile_width The destination width of individual tile in the sprite sheet.
   * @param dest_tile_height The destination width of individual tile in the sprite sheet.
   * @param _mapX The number of columns in the text-based tilemap.
   * @param _mapY The number of rows in the text-based tilemap.
   */
  TileMapObject(std::string &object_id,
                const std::string &texture_res,
                const std::string &tile_map_res,
                const std::string &camera_attached_object,
                const TileTypeDefiner *tile_type_definer,
                int rows,
                int cols,
                int tile_width,
                int tile_height,
                int dest_tile_width,
                int dest_tile_height,
                int _mapX,
                int _mapY);

  /*!
   * @brief This method returns the current tile map that is being displayed as a 2D array of integers.
   * @return The current tilemap layout as a two dimensional array of ints.
   */
  std::vector<int> GetTileMapLayout() const;
  ~TileMapObject();
  void Init() override;
};

#endif
