//
// Created by psx95 on 4/17/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_OBJECTCONFIG_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_OBJECTCONFIG_HPP_

#include <string>
#include "json.hpp"
#include "CoreStructs.hpp"
#include "Vector2D.hpp"
#include "Rect2D.hpp"

/*!
 * @brief This class is used to pass data to the python object (in the python scripts) from the Engine's Game Editor.
 * @details This class basically acts as a configuration for the game objects created by the user.
 */
class ObjectConfig {
 private:
  nlohmann::json json_config;

 public:
  /*!
   * @brief Public constructor for the class.
   * @param object_id The id of the object to which this configuration is to be passed.
   * @param json_text The Json text through which the user specifies this cnfiguration.
   */
  ObjectConfig(const std::string &object_id, const std::string &json_text);
  ObjectConfig() = default;

  Position GetPosition(const char *key) const;
  void SetPosition(const char *key, Position position);

  Vector2D GetVector(const char *key) const;
  void SetVector(const char *key, const Vector2D &vector_2d);

  GraphicsColor GetColor(const char *key) const;
  void SetColor(const char *key, GraphicsColor color);

  Rect2D GetRect(const char *key) const;
  void SetRect(const char *key, Rect2D rect_2d);

  //================================================================================
  // Support for primitive types
  //================================================================================
  int GetInt(const char *key) const;
  void SetInt(const char *key, int value);

  float GetFloat(const char *key) const;
  void SetFloat(const char *key, float value);

  double GetDouble(const char *key) const;
  void SetDouble(const char *key, double value);

  std::string GetString(const char *key) const;
  void SetString(const char *key, const std::string &value);

  bool GetBoolean(const char *key) const;
  void SetBoolean(const char *key, bool value);

  std::string GetClassName() const;
  std::string GetModuleName() const;
  std::string ToString() const;
  ~ObjectConfig() = default;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_OBJECTCONFIG_HPP_
