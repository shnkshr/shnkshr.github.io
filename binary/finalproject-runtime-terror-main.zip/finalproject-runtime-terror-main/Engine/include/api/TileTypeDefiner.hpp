//
// Created by psx95 on 4/19/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILETYPEDEFINER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILETYPEDEFINER_HPP_

#include "CoreStructs.hpp"
/*!
 * @brief This class allows users to define the location of a particular tile represented with a particular number in the tilemap.
 * @details A default implementation for this class is provided, but in most cases, it is supposed to be overridden.
 */
class TileTypeDefiner {
 public:
  /*!
   * @brief Default constructor
   */
  explicit TileTypeDefiner() = default;

  /*!
   * @brief The method that defines mapping between a tile type (int number) and its source position in a spritesheet.
   * @param tile_number The number with which a particular tile is defined in a tile map.
   * @param tile_width The width of the tile in pixels (in the source image)
   * @param tile_height The height of the tile in pixels (in the source image)
   * @return The XY position of the tile in the spritesheet.
   */
  virtual Position GetTilePos(int tile_number, int tile_width, int tile_height) const = 0;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILETYPEDEFINER_HPP_
