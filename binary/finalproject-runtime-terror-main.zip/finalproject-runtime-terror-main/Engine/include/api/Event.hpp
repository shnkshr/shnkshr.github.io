//
// Created by psx95 on 4/11/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_EVENTS_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_EVENTS_HPP_

#include <SDL_events.h>
#include <iostream>

/*!
 * @brief A class to represent user events. This class is really for supporting the bindings to the SDL_Event object
 * in the user's python code.
 */
class Event {
 public:
  enum SupportedKey {
    NONE,
    KEY_W,
    KEY_A,
    KEY_S,
    KEY_D,
    KEY_ESC,
    KEY_UP,
    KEY_DOWN,
    KEY_LEFT,
    KEY_RIGHT,
    KEY_SPACE,
  };

  enum SupportedEventType {
    UNSUPPORTED,     /*!< The event occurred is not supported by the Engine API. */
    APP_QUIT,        /*!< The user intended to quit the application. */
    KEY_RELEASE,     /*!< The user released a pressed key. */
    KEY_PRESS        /*!< The user pressed a released key. */
  };

  /*!
   * @brief A constructor for the Event class
   * @param event_type The type of event.
   * @param event_key A key pressed by user, in case event was a key based event.
   */
  explicit Event(SupportedEventType event_type, SupportedKey event_key);
  Event() = default;

  /*!
   * @brief This method returns any supported key that was pressed by the user.
   * @return The SupportedKey that was pressed by the user.
   */
  SupportedKey GetKeyEvent() const;

  /*!
   * @brief This method returns the type of event the user just performed.
   * @return A SupportedEventType that was just performed by the user.
   */
  SupportedEventType GetEventType() const;

  /*!
   * @brief A static method used to map an SDL_Event to a Event that is natively supported by this Engine.
   * @param sdl_event The SDL_Event that needs to be mapped to internal Event class.
   * @return The mapped event.
   */
  static Event GetFromSDLEvent(SDL_Event &sdl_event);

 private:
  SupportedKey key_event;
  SupportedEventType event_type;
  static SupportedKey GetMappedKey(SDL_Event &event);
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_EVENTS_HPP_
