//
// Created by psx95 on 4/19/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILEDATA_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILEDATA_HPP_

#include <SDL_rect.h>
#include "GameObject.hpp"
#include "PhysicsComponent.hpp"

/*!
 * @brief This class represents meta-data for an individual tile that gets rendered.
 * @details This meta data is useful in collision detection and rendering.
 */
class TileData : public GameObject {
 private:
  SDL_Rect dest_tile_rect{};
  SDL_Rect src_tile_rect{};
  PhysicsComponent* physics_component{};

 public:
  /*!
   * @brief The public constructor for TileData.
   * @param dest_tile_rect The rectangle which specifies the dimension where the tile is rendering.
   * @param src_tile_rect The rectangle which specifies the dimensions from where the texture for tile is extracted.
   */
  explicit TileData(const std::string &object_id, SDL_Rect dest_rect);

  void Init() override;

  void SetDestTileRect(SDL_Rect& dest);
  void SetSrcTileRect(SDL_Rect& src);

  /*!
   * @brief A getter for the SDL_Rect where the texture for the tile data is rendered.
   * @return The destination rectangle for the texture used in the TileData.
   */
  const SDL_Rect &GetDestTileRect() const;

  /*!
   * @brief A getter for the SDL_Rect that is used to snap the tile texture.
   * @return The source rectangle for the texture used in the TileData.
   */
  const SDL_Rect &GetSrcTileRect() const;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_TILEDATA_HPP_
