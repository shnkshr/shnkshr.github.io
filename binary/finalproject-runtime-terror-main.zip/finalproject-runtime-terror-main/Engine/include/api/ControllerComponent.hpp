//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_CONTROLLERCOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_CONTROLLERCOMPONENT_HPP_

#include "Component.hpp"

const float GRAVITY = 0.8f;
const float MAX_Y_VELOCITY = 2.0f;
const float DOUBLE_JUMP_THRESHOLD = 0.75f;

/*!
 * @brief This class represents the controller component that will allow user to move the game object to which this
 * component is attached.
 */
class ControllerComponent : public Component {
 public:
  /*!
   * @brief Public constructor for the class.
   * @param game_object The associated game object.
   * @param x_velocity The x-velocity force on movement.
   * @param y_velocity The y-velocity force on movement.
   */
  explicit ControllerComponent(GameObject *game_object, float x_velocity = 1.0f, float y_velocity = 1.0f);

  /*!
   * @brief Overridden implementation for process update that make update to game objects once per frame.
   * @param delta_time The time difference between two consecutive updates.
   */
  void ProcessUpdate(float delta_time) override;

  /*!
   * @brief Overridden implementation for render that can be used to render this component once per frame.
   * @details Currently empty implementation.
   */
  void Render() override;

  /*!
   * @brief Overridden implementation for update that is used to update this controller with lates inputs from the user.
   * @param event The user event that has occurred.
   */
  void Update(Event &event) override;

  /*!
   * @brief This method is used to return the cardinality of this component.
   * @return The ComponentCardinality for ControllerComponent.
   */
  ComponentCardinality GetComponentCardinality() override;

  /*!
   * @brief This method is used to get the type of component for current component.
   * @return The ComponentType for ControllerComponent.
   */
  ComponentType GetComponentType() override;
  ~ControllerComponent() = default;

  /*!
   * @brief Getter for X-velocity.
   * @return Return the current x-velocity force.
   */
  virtual float GetXVelocity() const;

  /*!
   * @brief Getter for Y-velocity.
   * @return Return the current y-velocity force.
   */
  virtual float GetYVelocity() const;

 private:
  bool move_left{};
  bool move_right{};
  bool move_up{};
  bool move_down{};

  float x_velocity{};
  float y_velocity{};

  float current_y_velocity = 0.0f;

  void UpdateMovement(Event &event, bool keydown);
};


#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_INPUT_CONTROLLERCOMPONENT_HPP_
