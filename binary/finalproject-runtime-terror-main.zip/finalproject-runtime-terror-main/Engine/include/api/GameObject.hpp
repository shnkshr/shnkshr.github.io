//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GAMEOBJECT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GAMEOBJECT_HPP_

#include <memory>
#include <iterator>
#include <vector>
#include <SDL.h>

#include "Component.hpp"
#include "Event.hpp"
/*!
 * @brief This is the base class for all game objects. This class can be used to instantiate an object and additional
 * functionality can be added to by means of components.
 */
class GameObject {
 public:
  /*!
   * @brief Default public constructor.
   */
  explicit GameObject(std::string object_id);

  /*!
   * @brief This method should be called one-time and prior to any other method invocations on this object.
   * @details This method initializes the individual components and make the object ready for use.
   */
  virtual void Init();

  /*!
   * @brief This function passes along the user based event to the individual components.
   * @param event The user event that has occurred.
   */
  virtual void UpdateFromEvent(Event &event);

  /*!
   * @brief This function is used to update the game object and its underlying components once per freme.
   * @param delta_time The time difference between two consecutive frames.
   */
  virtual void Update(float delta_time);

  /*!
   * @brief This function is used to render the components contained in this object on-screen.
   */
  virtual void Render();

  /*!
   * @brief This method can be used to add components to a game object.
   * @param component The component that needs to be added.
   * @throws MessageException if component is nullptr.
   */
  virtual void AddComponent(Component *component);
  virtual void RemoveComponent(Component *component); // not sure about this

  /*!
   * @brief This method is used to dynamically remove all components of a particular type from the object.
   * @param component_type The type of component to be removed.
   */
  virtual void RemoveComponentType(ComponentType component_type);

  /*!
   * @brief This method is used to mark this object for destruction.
   * @details Upon calling this method all components attached to this object will be deleted and the object will be
   * marked for deletion. Objects marked for deletion should be periodically removed from the game. This functionality
   * has to be implemented by the user.
   */
  virtual void MarkObjectForDestruction();

  /*!
   * @brief A getter to get the deletion status of the game object.
   * @details If this method returns true, this object should be deleted by the user.
   * @return a bool indicating if this object should be deleted.
   */
  virtual bool IsDeleted();

  virtual void OnCollisionStart(GameObject *collided_with);

  virtual void OnCollisionEnd(GameObject *collided_with);

  virtual void OnPause();

  virtual void OnResume();

  virtual void ProcessCollisionStart(const std::string &collided_with_id);

  virtual void ProcessCollisionEnd(const std::string &collided_with_id);

  const std::string &GetObjectId() const;
  // this function needs to be defined in the header file to avoid linker errors

  /*!
   * @brief A generic function that can get an attached component of a specific type.
   * @details This function should only be used for components that have a SINGLE cardinality.
   * @tparam T The type name of the component.
   * @param component_type The type of the component. Has to be one of ComponentType.
   * @throws MessageException if used with a component type that has a MULTIPLE cardinality.
   * @return The attached component of the required type or nullptr if no such component is attached.
   */
  template<typename T>
  T GetAttachedComponent(ComponentType component_type) {
    for (auto curr : *attached_components) {
      if (curr->GetComponentType() == component_type) {
        if (curr->GetComponentCardinality() == SINGLE) {
          T found_component = dynamic_cast<T>(curr);
          return found_component;
        } else {
          throw std::runtime_error(
              "Cannot retrieve multiple components with this method. Use GetAttachedComponentMultiple instead.");
        }
      }
    }
    return nullptr;
  }

  /*!
   * @brief A generic function that can get an attached component of a specific type.
   * @details This function should only be used for components that have a MULTIPLE cardinality.
   * @tparam T The type name of the component.
   * @param component_type The type of the component. Has to be one of ComponentType.
   * @throws MessageException if used with a component type that has a SINGLE cardinality.
   * @return The attached components of the required type or nullptr if no such component is attached.
   */
  template<typename T>
  std::vector<T> GetAttachedComponentMultiple(ComponentType component_type) {
    std::vector<T> components;
    for (auto curr : *attached_components) {
      if (curr->GetComponentType() == component_type) {
        if (curr->GetComponentCardinality() == MULTIPLE) {
          T found_component = dynamic_cast<T>(curr);
          components.push_back(found_component);
        } else {
          throw std::runtime_error(
              "Cannot retrieve single components with this method. Use GetAttachedComponent instead.");
        }
      }
    }
    return components;
  }
  ~GameObject();

  // Note: You may want to add member functions like 'Update' or 'Render'
  // Note: You may want to add member functions like "AddComponent" or "RemoveComponent"

 protected:
  std::vector<Component *> *attached_components{};
  bool is_deleted{};
  std::string object_id;
 private:
  void DeleteAllComponents();
  void ReplaceUniqueComponents(Component *component);
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_GAMEOBJECT_HPP_
