//
// Created by psx95 on 4/16/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_CAMERA2D_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_CAMERA2D_HPP_

#include "GameObject.hpp"
#include "TransformComponent.hpp"
#include "Rect2D.hpp"

/*!
 * @brief There will only be one camera for the 2D world, which can follow a single game object.
 */
class Camera2D {
 private:
  GameObject *object_to_follow{};
  SDL_Rect camera{};
  TransformComponent *attached_transform{};

  Camera2D() = default;
  Camera2D(Camera2D const &); // Prevent access to copy constructor
  void operator=(Camera2D const &); // Prevent access to assignment operator
  static Camera2D *instance;
  void FindAttachedTransform();

 public:
  /**
   * Returns the singleton Camera2D instance.
   * @return Singleton instance.
   */
  static Camera2D *GetInstance();

  /**
   * Checks if the singleton instance is initialised or not.
   * @return Boolean denoting the existence of Singleton instance.
   */
  static bool IsInitialized();

  /**
   * Initialises camera component to follow the game object with the given ID.
   * @param game_object_to_follow_id ID of the game object to follow.
   */
  void InitializeCamera(const std::string& game_object_to_follow_id);

  /**
   * Updates the camera frame for each frame.
   */
  void UpdateCameraPerFrame();

  /**
   * Returns the bounding box of the camera component.
   * @return
   */
  Rect2D GetCameraBounds() const;

  /**
   * Updates the position of the gaem object that the camera component is attached to by the given offset.
   * @param position offset by which the position is updated.
   */
  void UpdateOffset(Position *position) const;

  /**
   * Updates the center of the camera position to given x,y value.
   * @param x x co-ordinate of the camera position.
   * @param y y co-ordinate of the camera position.
   */
  void UpdateCameraPosition(int x, int y);

  /**
   * Destroys the singleton Camera component in the game.
   */
  void DestroyCamera();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_CAMERA2D_HPP_
