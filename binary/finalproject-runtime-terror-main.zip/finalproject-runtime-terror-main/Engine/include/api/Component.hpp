//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_COMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_COMPONENT_HPP_

#include <SDL.h>
#include "Event.hpp"
class GameObject;

/*!
 * @brief This enum contains various types of components that can be attached to a game object.
 */
enum ComponentType {
  TRANSFORM,    /*!< This component is responsible for giving position in a 2D space to a game object. */
  SPRITE,       /*!< This component is responsible for adding a sprite to a game object. */
  INPUT,        /*!< This component if attached, allows user input to control the associated game object. */
  TILE_MAP,     /*!< This component is responsible for giving position in a 2D space to a game object */
  COLLIDER,     /*!< This component is responsible for making an object collidable. */
  CAMERA,       /*!< This component attaches a camera to a game object which follows the object. */
  AI,           /*!< This component allows game objects to move autonomously. */
  TEXT,        /*!< This component is responsible rendering text in the game. */
  LIVES,        /*!< This component when attached, associates life to a game object. */
  GAME_RESULT,  /*!< This component is responsible for checking game result based on PlayerObject. */
  PHYSICS
};

/*!
 * @brief This enum represents cardinality of a Component.
 */
enum ComponentCardinality {
  SINGLE,   /*!< Only a single component of the type can be attached to a game object */
  MULTIPLE, /*!< Multiple components of this type can be attached to a game object */
};

/*!
 * @brief This class represents the base Component class.
 * @details An instance of this class can be added to a game object. Components should have many to 1 relationship
 * with the GameObject. although this is not enforced. This class should not directly be attached to a game object, since
 * default implementation will throw MessageException for each virtual method.
 */
class Component {
 public:
  /*!
   * @brief The base constructor for Component.
   * @param game_object The game object to which this component needs to be attached.
   */
  explicit Component(GameObject *game_object);

  /*!
   * @brief Optional Init method to perform one-time initialization for a component.
   */
  virtual void Init();

  /*!
   * @brief This method should be used to perform per-frame updates to the component.
   * @details This method must be overridden in concrete implementations.
   * @param delta_time The time passed between two frames.
   */
  virtual void ProcessUpdate(float delta_time);

  /*!
   * @brief This method updates component based on any user based events.
   * @param event The event initiated by the user.
   */
  virtual void Update(Event &event);

  /*!
   * @brief This method renders the component every frame.
   */
  virtual void Render();

  /*!
   * @brief Getter method to get a pointer to the  game object to which this component is attached.
   * @return The GameObject to which this component is attached.
   */
  virtual GameObject *GetGameObject();

  /*!
   * @brief Getter method to retrieve the type of component.
   * @return One of the supported component from ComponentType enum that represents this component.
   */
  virtual ComponentType GetComponentType();

  /*!
   * @brief Getter method to get the cardinality for the component.
   * @return One of the supported cardinality type from the ComponentCardinality enum that represents cardinality.
   */
  virtual ComponentCardinality GetComponentCardinality();

  /*!
   * @brief Use this method to set the disabled status for a component. Calling this method will temporarily disable
   * all functionality of the component.
   * @details To make this method useful, you need to be using disabled field to check if component is disabled or not.
   */
  virtual void DisableComponent() {
    disabled = true;
  };

  /*!
   * @brief Use this method to set the disabled status for a component. Calling this method will re-enable all the
   * all functionality of the component.
   * @details To make this method useful, you need to be using disabled field to check if component is disabled or not.
   */
  virtual void EnableComponent() {
    disabled = false;
  };
  ~Component();
  GameObject *game_object;
 private:
  ComponentType component_type;
  ComponentCardinality component_cardinality;
 protected:
  bool disabled = false;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_COMPONENT_HPP_
