//
// Created by psx95 on 4/19/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TILEMAPCOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TILEMAPCOMPONENT_HPP_

#include <vector>
#include "Component.hpp"
#include "TileData.hpp"
#include "LevelData.hpp"
#include "TileTypeDefiner.hpp"

class TileMapComponent : public Component {
 private:
  // Dimensions of our TileMapComponent and individual tiles.
  // Used for spiltting up the sprite sheet
  int number_rows;
  int number_columns;
  // How big each tile is.
  int m_TileWidth;
  int m_TileHeight;
  // How big each tile should be rendered
  int dest_tile_width;
  int dest_tile_height;
  // size of our tilemap
  int m_MapX;
  int m_MapY;
  SDL_Texture *m_Texture{};
  // Stores our tile types
  int *m_Tiles{}; // 2D array of tiles
  std::vector<TileData *> visible_tiles{}; // on stack since will be limited number of visible tiles
  std::vector<std::vector<TileData *>> m_tiles;
  LevelData *levelData{};
  const TileTypeDefiner *tile_type_definer;

  void SetupLevelData(const std::string &level_map_res, const std::string &camera_object_id);

 public:
  /*!
  * Constructor to construct an AI component to be used by enemy objects.
  * @param game_object Main character game object.
  * @param texture_res Resource for sprite-sheet that contains the tiles.
  * @param tile_map_res Resource for text file that contains tile positioning.
  * @param camera_attached_object The ID for game object which the camera follows.
  * @param rows Row size of a tile map.
  * @param cols Column size of a tile map.
  * @param tile_width Width of each tile taken from the source image.
  * @param tile_height Height of each tile taken from the source image.
  * @param dest_tile_width Width of each tile to be drawn on screen.
  * @param dest_tile_height Height of each tile to be drawn on screen.
  * @param _mapX size of map containing row size of tile map.
  * @param _mapY size of map containing column size of tile map.
  */
  TileMapComponent(GameObject *game_object,
                   const std::string &texture_res,
                   const std::string &tile_map_res,
                   const std::string &camera_attached_object,
                   const TileTypeDefiner* tile_type_definer,
                   int rows,
                   int cols,
                   int tile_width,
                   int tile_height,
                   int dest_tile_width,
                   int dest_tile_height,
                   int _mapX,
                   int _mapY);

  /*!
   * @brief This method updates component based on any user based events.
   * @details This method is overridden.
   * @param event The event initiated by the user.
   */
  void Update(Event &event) override;

  /*!
 * @brief This method is used to perform per-frame updates to the AI component.
 * @details This method is overridden.
 * @param delta_time The time passed between two frames.
 */
  void ProcessUpdate(float delta_time) override;
  /*!
   * @brief This method renders the component every frame.
   * @details This method is overridden.
   * @param renderer The renderer that is actually used to draw objects on screen.
   */
  void Render() override;
  /*!
 * @brief Getter method to get the cardinality for the component.
  * @details This method is overridden.
 * @return One of the supported cardinality type from the ComponentCardinality enum that represents cardinality.
 */
  ComponentCardinality GetComponentCardinality() override;
  /*!
 * @brief Getter method to retrieve the type of component.
  * @details This method is overridden.
 * @return One of the supported component from ComponentType enum that represents this component.
 */
  ComponentType GetComponentType() override;

  std::vector<int> GetMTiles() const;

  const std::vector<TileData *> &GetVisibleTiles() const;

  /*!
   * @brief Destructor for TileMapComponent
   */
  ~TileMapComponent();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TILEMAPCOMPONENT_HPP_
