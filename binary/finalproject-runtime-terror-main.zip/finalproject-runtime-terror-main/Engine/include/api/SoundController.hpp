//
// Created by psx95 on 4/16/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_SOUND_SOUNDCONTROLLER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_SOUND_SOUNDCONTROLLER_HPP_

#include <string>
#include <chrono>

/*!
 * @brief Convenience class that provides simple bindings to play sound effects and background music to the end user.
 */
class SoundController {
 private:
  explicit SoundController() = default;
  static std::chrono::time_point<std::chrono::high_resolution_clock> last_sound_effect_time;

 public:
  /*!
   * @brief A static method that internally uses the SDL APIs to play sound effects.
   * @param sound_effect_res The path to the sound effect resource.
   * @param loops The number of loops.
   */
  static void PlaySoundEffect(std::string &sound_effect_res, int loops = 0);

  /*!
   * @brief A static method that internally uses SDL APIs to play a music track on repeat.
   * @param music_res The path to the music file resource.
   */
  static void PlayBackgroundMusicTrack(std::string &music_res);
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_SOUND_SOUNDCONTROLLER_HPP_
