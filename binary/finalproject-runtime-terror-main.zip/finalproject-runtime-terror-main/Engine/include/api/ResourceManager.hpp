//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RESOURCEMANAGER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RESOURCEMANAGER_HPP_

#include <string>
#include <SDL.h>
#include <SDL_mixer.h>
#include <map>
#include <utility>
#include <SDL_ttf.h>
#include <api/LevelData.hpp>

/*!
 * @brief This class handles all the requests by the game objects that involve external resource acquisition.
 * @details This class handles all image, fonts & sound based resources.
 */
class ResourceManager {
 private:
  /*!
   * @brief Private constructor to prevent instantiation from outside.
   */
  ResourceManager();
  ResourceManager(ResourceManager const &); // Prevent access to copy constructor
  void operator=(ResourceManager const &); // Prevent access to assignment operator

  static ResourceManager *instance;
  SDL_Renderer *engine_renderer{};
  std::map<std::string, SDL_Texture *> *textures_map{}; // a mapping of image resource and corresponding texture
  std::map<std::string, SDL_Surface *> *resources_map{}; // a mapping of image resource and corresponding surafces.
  std::map<std::string, Mix_Chunk *> *sound_effects_map{}; // a mapping of the sound effects and corresponding chunks.
  std::map<std::string, Mix_Music *> *music_map{}; // a mapping of the music files and corresponding music.
  std::map<std::string, TTF_Font *> *font_map{}; // a mapping of the open fonts files and their corresponding files.
  std::map<std::string, LevelData *> *level_map; // a mapping of the level map files and corresponding array.

 public:
  /*!
   * @brief The static method that returns an instance of the game manager. If the instance is not created yet, this
   * method also instantiates it.
   * @return The singleton instance of the class.
   */
  static ResourceManager *GetInstance();

  /*!
   * @brief This method is used to setup all the necessary resources that may be required as soon as the game starts.
   * @details This method should be called as early as possible, to ensure that the resources are available.
   * @param language The language in which the user should see the user interface for the game.
   */
  void Initialize(SDL_Renderer *renderer);

  /*!
   * @brief This method is used to retrieve the image resources available in the game. The resources are loaded in a
   * lazy fashion.
   * @details Since only a pointer to the image resource is passed, it is ensured that requesting the same resource
   * multiple times will not flood the memory with redundant copies. This method is optimized for BMP files.
   * @param resource_id The unique resource ID for the asset. This ID is mostly the location of the corresponding file
   *                    from which the resource is loaded.
   * @param renderer A pointer to the SDL_Renderer* that is used to create texture for the image resource (if the
   *                 resource is not loaded into memory yet.
   * @return A pointer to the SDL_Texture of the rendered image resource as a SDL_Texture.
   */
  SDL_Texture *GetImageResourceBMP(const std::string &resource_id);

  /*!
   * @brief This method is used to retrieve the image resources available in the game. The resources are loaded in a
   * lazy fashion.
   * @details Since only a pointer to the image resource is passed, it is ensured that requesting the same resource
   * multiple times will not flood the memory with redundant copies. This method is optimized for PNG files.
   * @param resource_id The unique resource ID for the asset. This ID is mostly the location of the corresponding file
   *                    from which the resource is loaded.
   * @param renderer A pointer to the SDL_Renderer* that is used to create texture for the image resource (if the
   *                 resource is not loaded into memory yet.
   * @return A pointer to the SDL_Texture of the rendered image resource as a SDL_Texture.
   */
  SDL_Texture *GetImageResourcePNG(const std::string &resource_id);

  /*!
   * @brief This method is used to retrieve the sound effects available in the game. The resources are loaded in a
   * lazy fashion.
   * @details Since only a pointer to the resource is passed, it is ensured that requesting the same resource
   * multiple times will not flood the memory with redundant copies.
   * @param resource_id The unique resource ID for the asset. This ID is mostly the location of the corresponding file
   *                    from which the resource is loaded.
   * @return A pointer to the Mix_Chunk of the loaded sound effect resource.
   */
  Mix_Chunk *GetSoundEffectResource(const std::string &resource_id);

  /*!
   * @brief This method is used to retrieve the audio tracks available in the game. The resources are loaded in a
   * lazy fashion.
   * @details Since only a pointer to the resource is passed, it is ensured that requesting the same resource
   * multiple times will not flood the memory with redundant copies.
   * @param resource_id The unique resource ID for the asset. This ID is mostly the location of the corresponding file
   *                    from which the resource is loaded.
   * @return A pointer to the Mix_Music of the loaded audio track resource.
   */
  Mix_Music *GetMusicResource(const std::string &resource_id);

  /*!
   * @brief This method is used to retrieve the level maps available in the game. The resources are loaded in a
   * lazy fashion.
   * @details Since only a pointer to the resource is passed, it is ensured that requesting the same resource
   * multiple times will not flood the memory with redundant copies.
   * @param resource_id The unique resource ID for the asset. This ID is mostly the location of the corresponding file
   *                    from which the resource is loaded.
   * @param row The number of rows in the level map that is being attempted to load.
   * @param col The number of columns in the level map that is being attempted to load.
   * @return A pointer to the Mix_Music of the loaded audio track resource.
   */
  LevelData *GetLevelMapResource(const std::string &resource_id, unsigned int row, unsigned int col);

  TTF_Font *GetFontResource(const std::string &resource_id, int font_size);

  SDL_Renderer *GetEngineRenderer() const;

  /*!
   * @brief This method is used to shutdown the resource manner in a proper way and should be called whenever the user
   * exits the game.
   * @details This method clears all the mapping of the loaded resources and deletes all dynamically allocated memory.
   * Calling this method will nullify the current instance of GameResourceManager.
   */
  void Shutdown();

  ~ResourceManager() = default;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RESOURCEMANAGER_HPP_
