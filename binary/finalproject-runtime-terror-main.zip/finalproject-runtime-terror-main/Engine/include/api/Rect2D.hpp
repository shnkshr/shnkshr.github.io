//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RECT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RECT_HPP_
#include "SDL.h"

class Rect2D {
 private:
  SDL_Rect rect{};

 public:
  explicit Rect2D(int x, int y, int w, int h);
  virtual int GetXPos();
  virtual int GetYPos();
  virtual int GetWidth();
  virtual int GetHeight();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_RECT_HPP_
