//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_VECTOR2D_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_VECTOR2D_HPP_

/*!
 * @brief This class represents a Two Dimensional Vector along the X & Y axis in the Game Engine.
 */
class Vector2D {
 public:
  float x{};
  float y{};
  /*!
   * @brief Constructor for the Vector2D class, that uses float values.
   * @param x The value along the x-axis.
   * @param y The value along the y-axis.
   */
  explicit Vector2D(float x, float y);

  /*!
   * @brief Constructor for the Vector2D class, that uses integer values.
   * @param x The value along the x-axis.
   * @param y The value along the y-axis.
   */
  explicit Vector2D(int x, int y);
  virtual Vector2D operator+(const Vector2D &other_position) const;
  virtual Vector2D &operator+=(const Vector2D &other_position);
  virtual Vector2D operator*(float scalar_multiplier) const;
  virtual ~Vector2D() = default;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_VECTOR2D_HPP_
