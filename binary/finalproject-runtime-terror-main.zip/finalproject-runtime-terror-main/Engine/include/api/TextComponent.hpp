//
// Created by psx95 on 4/13/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TEXTCOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TEXTCOMPONENT_HPP_

#include <SDL_ttf.h>
#include "Component.hpp"
#include "CoreStructs.hpp"

/*!
 * @brief A generic component that can be used to display text through a game object.
 */
class TextComponent : public Component {
 public:
  /*!
   * @brief Public constructor for the TextComponent.
   * @param game_object The object to which this component is attached.
   * @param font_res_path The string resource path for the font file that will be used to render the text.
   * @param font_size The size of the rendered font.
   * @param color The color in which the text needs to be rendered.
   * @param destination_rect A boundary that depicts the text area.
   */
  explicit TextComponent(GameObject *game_object,
                         std::string &font_res_path,
                         int font_size,
                         GraphicsColor color,
                         Rect2D destination_rect);

  void Init() override;
  void Update(Event &event) override;
  void ProcessUpdate(float delta_time) override;
  void Render() override;
  void UpdateText(const std::string &updated_text);
  ComponentCardinality GetComponentCardinality() override;
  ComponentType GetComponentType() override;
  ~TextComponent();

 private:
  // dimensions of the rendered text
  int text_width{};
  int text_height{};
  SDL_Rect text_boundary{}; // a rectangle around the rendered text
  SDL_Rect dest{}; // destination for rendering text
  GraphicsColor text_color{}; // color for the text

  TTF_Font *text_font{};
  SDL_Texture *texture{};
  SDL_Surface *surface{};
  std::string text;

  // Methods to help render the score text
  void LoadFontFromRes(std::string &font_res, int font_size);
  void InitSurface();
  void InitTexture();
  void FreeMemory();
  void UpdateComponent();
  void SetDestinationRectangle(Rect2D destination_rect);
  void SetFontColor(GraphicsColor color);
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_TEXTCOMPONENT_HPP_
