#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICSCOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_PHYSICSCOMPONENT_HPP_

#include <Box2D/Box2D.h>
#include "PhysicsManager.hpp"
#include "Component.hpp"
#include "../GlobalConstants.hpp"
#include "Vector2D.hpp"

const int PHYSICS_BODY_MOVEMENT_STOP = 0x1;
const int PHYSICS_BODY_MOVEMENT_LEFT = 0x2;
const int PHYSICS_BODY_MOVEMENT_RIGHT = 0x4;
const int PHYSICS_BODY_MOVEMENT_UP = 0x8;
const int PHYSICS_BODY_MOVEMENT_DOWN = 0x10;
const int PHYSICS_BODY_MOVEMENT_JUMP = 0x20;

class PhysicsComponent : public Component {
 public:
  PhysicsComponent(GameObject *game_object, PhysicsBodyConfig* config);
  void ProcessUpdate(float delta_time) override;
  void Render() override;
  void Update(Event &event) override;
  ComponentCardinality GetComponentCardinality() override;
  ComponentType GetComponentType() override;

  void MoveBody(unsigned int move_flag, Vector2D& vel);

  Vector2D GetBodyPosition();
  Vector2D GetBodyVelocity();
  float GetBodySpeed();
  void SetBodyVelocity(Vector2D& vel);
  ~PhysicsComponent();

  static Vector2D PhysicsPositionToSDLPosition(Vector2D& vec);
  static Vector2D SDLPositionToPhysicsPosition(Vector2D& vec);

 private:
  b2Body* m_body;
  int m_width;
  int m_height;
};

#endif
