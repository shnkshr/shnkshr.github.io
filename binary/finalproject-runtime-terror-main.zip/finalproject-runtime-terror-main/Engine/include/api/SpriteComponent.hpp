//
// Created by psx95 on 4/8/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_SPRITECOMPONENT_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_SPRITECOMPONENT_HPP_

#include <string>
#include <chrono>

#include "Component.hpp"
#include "TransformComponent.hpp"

/*!
 * @brief A small class to demonstrate loading sprites.
 * SpriteComponent sheets are often used for loading characters,
 * environments, icons, or other images in a game.
 */
class SpriteComponent : public Component {
 public:

  /*!
   * @brief Public constructor for sprite component.
   * @param game_object The associated game object.
   * @param texture_res The location to the image resource from which texture is created and displayed for this sprite.
   * @param src_sprite_width The source width of the sprite image.
   * @param src_sprite_height The source height of the sprite image.
   * @param max_frames The maximum number of frames this sprite supports.
   * @param sprite_width The destination width of the sprite image.
   * @param sprite_height The destination height of the sprite image.
   * @param fps The FPS at which this sprite should animate.
   * @param sprite_x_start The initial x position for the sprite.
   * @param sprite_y_start The initial y position for the sprite.
   * @param src_sprite_x_start The start x-position for the sprite in a sprite-sheet (0 by default, only required if loading a bmp sprite-sheet)
   * @param src_sprite_y_start The start y-position for the sprite in a sprite-sheet (0 by default, only required if loading a bmp sprite-sheet)
   * @param src_bmp To specify if the source provided is a bmp image or not. BMPs are treated as sprite-sheet.
   * @param sync_position_with_transform if true the sprites position is synced with the attached transform component.
   */
  explicit SpriteComponent(GameObject *game_object,
                           std::string &texture_res,
                           int src_sprite_width,
                           int src_sprite_height,
                           int max_frames,
                           int sprite_width,
                           int sprite_height,
                           int fps = 30,
                           int sprite_x_start = 0,
                           int sprite_y_start = 0,
                           int src_sprite_x_start = 0,
                           int src_sprite_y_start = 0,
                           bool src_bmp = false,
                           bool sync_position_with_transform = true);

  ~SpriteComponent() = default;

  /*!
   * @brief A method to set the x and y position of the sprite.
   * @param x The x coordinate of the new position.
   * @param y The y coordinate of the new position.
   */
  void SetPosition(int x, int y);

  /*!
   * @brief Overridden implementation to render the sprite on screen.
   */
  void Render() override;

  /*!
   * @brief Overridden implementation to initialize a sprite.
   */
  void Init() override;

  /*!
   * @brief Overridden implementation to update the sprite based on user events.
   * @param event The user event that occurred.
   */
  void Update(Event &event) override;

  /*!
   * @brief  Overridden implementation to update the sprite per frame.
   * @details This function implements animating sprites based on fps.
   * @param delta_time the time difference between two consecutive frame updates.
   */
  void ProcessUpdate(float delta_time) override;

  /*!
   * @brief  Overridden implementation to get the ComponentType for sprite component.
   * @return The ComponentType of the SpriteComponent.
   */
  ComponentType GetComponentType() override;

  /*!
   * @brief  Overridden implementation to get the cardinality of sprite component.
   * @return The ComponentCardinality for SpriteComponent.
   */
  ComponentCardinality GetComponentCardinality() override;

  /*!
   * @brief A getter to get the current sprite destination width.
   * @return Destination width at which the sprite is rendered,
   */
  int GetSpriteWidth() const;

  /*!
   * @brief A getter to get the current sprite destination height.
   * @return Destination height at which the sprite is rendered,
   */
  int GetSpriteHeight() const;

  /*!
   * @brief A setter to set the horizontal flip status for the sprite.
   * @details This method can be used to render the sprite in a flipped way about the x-axis.
   */
  void SetHorizontalFlip(bool flip);
  bool IsHorizontalFlip() const;

  /*!
   * @brief A setter to set the vertical flip status for the sprite.
   * @details This method can be used to render the sprite in a flipped way about the x-axis.
   */
  void SetVerticalFlip(bool flip);

  void SetSpriteRotateAngle(float sprite_rotate_angle);
  float GetSpriteRotateAngle() const;

  void SetSpriteTargetFps(int sprite_target_fps);

  /*!
   * @brief This method is used to get the max frames in the sprite,
   * @return The max number of frames supported by the sprite.
   */
  unsigned int GetMaxFrames() const;

  /*!
   * @brief A getter to get the current frame in the sprite that is being rendered.
   * @return The current frame number that is being rendered by the sprite component.
   */
  unsigned int GetCurrentFrame() const;

 private:
  int m_xPos{};
  int m_yPos{};
  bool horizontal_flip{};
  bool vertical_flip{};
  float sprite_rotate_angle{};
  int sprite_target_fps{};
  unsigned int max_frames{};
  unsigned int current_frame{};
  // An SDL Surface contains pixel data to draw an image
  SDL_Texture *m_texture{};
  std::chrono::time_point<std::chrono::high_resolution_clock> last_frame_update;

  SDL_Rect m_src{};
  SDL_Rect m_dest{};
  bool sync_position_with_transform;
  TransformComponent *game_object_transform{};

  void FindAttachedTransformComponent();
  void UpdateSpriteFrame();
};
#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_CORE_SPRITECOMPONENT_HPP_
