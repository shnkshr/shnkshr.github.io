//
// Created by psx95 on 4/19/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_LEVELDATA_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_LEVELDATA_HPP_

/*!
 * @brief This class represents meta-data for an the level that gets rendered on screen.
 * @details This meta data is useful in rendering tile maps.
 */
class LevelData {
 public:
  /*!
   * @brief Public constructor for the LevelData.
   * @param arr An array of integers representing various tiles in the level.
   * @param row The number of rows in the 2D array of ints passed as arr.
   * @param col The number of columns in the 2D array of ints passed as arr.
   */
  LevelData(int *arr, int row, int col);
  ~LevelData();

  /*!
   * @brief This method returns the value of a tile at a given row and column in the 2D array.
   * @param x The row dimension value in the 2D array.
   * @param y The column dimension value in the 2D array.
   * @return The tile type at the given location in the 2D array.
   */
  int GetTileType(int x, int y);

  /*!
   * @brief Function to print the tile map as as a string to console.
   */
  void PrintMap();

 private:
  int *m_tiles{};
  int m_row;
  int m_col;
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_API_COMMONS_LEVELDATA_HPP_
