//
// Created by psx95 on 4/22/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORAPP_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORAPP_HPP_

#include <SDL.h>
#include "TileRenderer.hpp"
class TileEditorApp {
 private:
  SDL_Window *window{};
  SDL_Renderer *renderer{};
  SDL_Surface *surface{};
  struct sdlsurface_context *context{};
  SDL_Texture *texture{};
  SDL_Rect camera{};
  bool app_running{};
  char proposed_tile_map[2000]{};
  SupportedTileFormats selected_format{};
  TileRenderer *tile_renderer{};

  bool move_up{};
  bool move_down{};
  bool move_left{};
  bool move_right{};

  void HandleUserInputEvents(SDL_Event &event, struct nk_vec2 &vec);
  void Init(int screen_width, int screen_height);
  static void InitSDLImage();
  int nk_sdl_handle_event(SDL_Event *event);
  void SetupBackgroundColorSelectionUpdate();
  void SetupTileSaveDialogUI(std::string &tile_io_result);
  void SetupBMPTileConfigUI();
  void UpdateMovement(SDL_Event &event, bool keydown);
  void UpdateCameraPosition();

 public:
  explicit TileEditorApp() = default;
  virtual void StartTileEditorApp(int window_width, int window_height);
  virtual void ShutdownTileEditorApp();
  ~TileEditorApp();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORAPP_HPP_
