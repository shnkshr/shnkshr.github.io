//
// Created by psx95 on 4/22/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORRUNNER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORRUNNER_HPP_

#include "string"

class TileEditorRunner {
 private:
  static std::string png_tiles_location;
  static std::string bmp_tile_map_location;
 public:
  static void RunApp(int screen_width,
                     int screen_height,
                     const std::string &bmp_tile_map,
                     const std::string &png_tiles_location_path);

  static const std::string &GetPngTilesLocation();
  static const std::string &GetBmpTileMapLocation();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEEDITORRUNNER_HPP_
