//
// Created by psx95 on 4/22/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEMAP_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEMAP_HPP_

#include <string>
class TileMap {
 private:
  int num_rows{};
  int num_cols{};
  int *tiles{};

 public:
  TileMap(int num_rows, int num_cols, int *tiles);
  bool SaveTileMapToAssets(const std::string &complete_file_path);
  static std::string LoadTileMapFromAssets(const std::string &complete_file_path);
  int GetNumRows() const;
  int GetNumCols() const;
  int *GetTiles() const;

};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILEMAP_HPP_
