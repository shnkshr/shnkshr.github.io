//
// Created by psx95 on 4/22/21.
//

#ifndef FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILERENDERER_HPP_
#define FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILERENDERER_HPP_

#include <string>
#include <vector>
#include <SDL.h>

enum SupportedTileFormats {
  PNG,
  BMP,
};

class TileRenderer {
 private:
  // think of way to get this from UI as well
  // currently each tile would be of the same size.
  int max_tile_rows_visible{};
  int max_tile_columns_visible{};
  std::string png_tiles_location;
  std::string bmp_tiles_location;
  int num_rows{};
  int max_columns{};
  int tile_height{};
  int tile_width{};
  int tile_dest_height{};
  int tile_dest_width{};
  int *tiles{};
  int bmp_num_rows{};
  int bmp_num_cols{};
  SDL_DisplayMode dm{};
  /*!
   * @brief A function to validate user inputted tile map config
   * @param proposed_tile_map The tile map that needs to be validated
   * @param [out] message parameter to store failure success messages
   * @return A boolean indicating if the verification was successful or not.
   */
  bool VerifyTileMapFormatOK(char proposed_tile_map[], std::string &message);
  bool RenderTileFromPng(SDL_Renderer *renderer, SDL_Surface *window_surface, SDL_Rect *camera);
  bool RenderTileFromBmp(SDL_Renderer *renderer, SDL_Surface *window_surface, SDL_Rect *camera);
  void PopulateTiles(std::vector<std::vector<int>> &int_map);
  /**
 * Function for printing text to console
 */
  void PrintMap();
 public:
  TileRenderer();
  TileRenderer(int max_tile_rows_visible, int max_tile_columns_visible);
  /*!
   * @brief Renders tiles on to the screen from the proposed tile map
   * @param proposed_tile_map The char array representing the tile map values as a basic string
   * @return a message which can be directly displayed to the user regarding success/failure of the render.
   */
  virtual std::string RenderTiles(SDL_Renderer *renderer,
                                  SDL_Surface *window_surface,
                                  char proposed_tile_map[],
                                  SupportedTileFormats tile_format,
                                  SDL_Rect *camera);

  /**
     * Set the 'type' of tile at an x and y position
     */
  void SetTile(int x, int y, int type);
  /**
   * Return the tile type at an x and y position
   */
  int GetTileType(int x, int y);

  bool SaveTileMapToAssets(const std::string &name);

  // methods for setting tile dimensions - useful when dealing with bmps
  void SetTileHeight(int updated_tile_height);
  void SetTileWidth(int updated_tile_width);
  void SetTileDestHeight(int bmp_dest_height);
  void SetTileDestWidth(int bmp_dest_width);

  // switch back to PNG
  void SwitchTileConfigToPng();
};

#endif //FINALPROJECT_RUNTIME_TERROR_ENGINE_SRC_SUPPORTING_TOOLS_TILE_EDITOR_TILERENDERER_HPP_
