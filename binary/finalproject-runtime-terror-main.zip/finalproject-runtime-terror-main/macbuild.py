import os

COMPILER = "g++"

SOURCE_COMMON = "./Engine/src/api/commons/*.cpp "
SOURCE_CORE = SOURCE_COMMON + "./Engine/src/api/core/*.cpp ./Engine/src/api/input/*.cpp ./Engine/src/api/physics/*.cpp ./Engine/src/api/sound/*.cpp"
SOURCE_INPUT = SOURCE_COMMON + "./Engine/src/api/input/*.cpp"
SOURCE_PHYSICS = SOURCE_COMMON + "./Engine/src/api/physics/*.cpp"
SOURCE_SOUND = SOURCE_COMMON + "./Engine/src/api/sound/*.cpp"

ARGUMENTS = "-D MAC -std=c++14 -shared -fPIC -undefined dynamic_lookup"

INCLUDE_DIR = "-I ./Engine/include/ -I ./Engine/ThirdParty/Json `python3.8 -m pybind11 --includes` -I/Library/Frameworks/SDL2.framework/Headers -I/Library/Frameworks/SDL2_ttf.framework/Headers -I/Library/Frameworks/SDL2_image.framework/Headers -I/Library/Frameworks/SDL2_mixer.framework/Headers"

LIBRARIES = "-F/Library/Frameworks -framework SDL2 -framework SDL2_mixer -framework SDL2_image -framework SDL2_ttf `python3.8-config --ldflags` -lbox2d"

EXECUTABLE_CORE = "terror_core.so"

compileString_core = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE_CORE + " " + " " +INCLUDE_DIR + " " + SOURCE_CORE + " " + LIBRARIES + " -rpath /Library/Frameworks"
# Print out the compile string
print(compileString_core)
# Run our command
os.system(compileString_core)

