import faulthandler
import sys
from Engine.src.editor.mainwindow import MainWindow
from PyQt5.QtWidgets import QApplication

faulthandler.enable()
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    run = app.exec_()
    del window
    del app
    sys.exit(run)