import os

COMPILER = "g++"

SOURCE_TILE_EDITOR = "Engine/src/supporting_tools/tile_editor/*.cpp Engine/src/api/commons/LevelData.cpp Engine/src/api/core/ResourceManager.cpp"
INCLUDE_DIR_TILE_EDITOR = "-I ./Engine/include/ -I ./Engine/ThirdParty/nuklear -I./pybind11/include/ `python3.8 -m pybind11 --includes` -I/usr/include/SDL2"
EXECUTABLE_TILE_EDITOR = "tile_editor.so"
# You can can add other arguments as you see fit.
# What does the "-D LINUX" command do?
ARGUMENTS = "-D LINUX -std=c++14 -shared -fPIC"

# What libraries do we want to include
LIBRARIES = "-lSDL2 -ldl -lSDL2_ttf -lSDL2_mixer -lSDL2_image `python3.8-config --ldflags` -lBox2D"

# Build Core module
compileString_tileEditor = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE_TILE_EDITOR + " " + " " + INCLUDE_DIR_TILE_EDITOR + " " + SOURCE_TILE_EDITOR + " " + LIBRARIES
# Print out the compile string
print(compileString_tileEditor)
# Run our command
os.system(compileString_tileEditor)