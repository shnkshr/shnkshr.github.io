import os

COMPILER = "g++"

SOURCE_COMMON = "./Engine/src/api/commons/*.cpp "
SOURCE_CORE = SOURCE_COMMON + "./Engine/src/api/core/*.cpp ./Engine/src/api/input/*.cpp ./Engine/src/api/physics/*.cpp ./Engine/src/api/sound/*.cpp"
SOURCE_INPUT = SOURCE_COMMON + "./Engine/src/api/input/*.cpp"
SOURCE_PHYSICS = SOURCE_COMMON + "./Engine/src/api/physics/*.cpp"
SOURCE_SOUND = SOURCE_COMMON + "./Engine/src/api/sound/*.cpp"
# You can can add other arguments as you see fit.
# What does the "-D LINUX" command do?
ARGUMENTS = "-D LINUX -std=c++14 -shared -fPIC"

# Which directories do we want to include.
INCLUDE_DIR = "-I ./Engine/include/ -I ./Engine/ThirdParty/Json -I./pybind11/include/ `python3.8 -m pybind11 --includes` -I/usr/include/SDL2"

# What libraries do we want to include
LIBRARIES = "-lSDL2 -ldl -lSDL2_ttf -lSDL2_mixer -lSDL2_image `python3.8-config --ldflags` -lBox2D"

# The name of our module
EXECUTABLE_CORE = "terror_core.so"
EXECUTABLE_INPUT = "input.so"
EXECUTABLE_PHYSICS = "terror_physics.so"
EXECUTABLE_SOUND = "sound.so"
# Build Core module
compileString_core = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE_CORE + " " + " " + INCLUDE_DIR + " " + SOURCE_CORE + " " + LIBRARIES
# Print out the compile string
print(compileString_core)
# Run our command
os.system(compileString_core)

# Build input module
# compileString_input = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE_INPUT + " " + " " + INCLUDE_DIR + " " + SOURCE_INPUT + " " + LIBRARIES
# # Print out the compile string
# print(compileString_input)
# # Run our command
# os.system(compileString_input)
#
# # Build physics module
# compileString_physics = COMPILER + " " + ARGUMENTS + " -o " + EXECUTABLE_PHYSICS + " " + " " + INCLUDE_DIR + " " + SOURCE_PHYSICS + " " + LIBRARIES
# # Print out the compile string
# print(compileString_physics)
# # Run our command
# os.system(compileString_physics)

# # Build sound module
# compileString_sound=COMPILER+" "+ARGUMENTS+" -o "+EXECUTABLE_SOUND+" "+" "+INCLUDE_DIR+" "+SOURCE_SOUND+" "+LIBRARIES
# # Print out the compile string
# print(compileString_sound)
# # Run our command
# os.system(compileString_sound)
